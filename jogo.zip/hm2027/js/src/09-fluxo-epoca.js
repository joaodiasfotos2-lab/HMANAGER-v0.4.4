  // ============================= 09-fluxo-epoca.js =============================
  // Avanço de calendário, jogador provisório, convocatória/escalação
  // Continuar: advances the calendar day by day; triggers jornadas and
  // occasional flavor news along the way.
  // =================================================================
  function renderHubDate(){
    document.getElementById("hubDateVal").textContent = fmtDateLong(state.currentDate);
    updateContinuarBtnLabel();
    const lbl = document.getElementById("hubNextEvent");
    if(state.inDefeso){
      lbl.textContent = state.isPreSeasonDefeso
        ? "🏖️ Pré-época — mercado aberto a transferências. Negoceia no Mercado e clica em \"Iniciar a Época\" quando estiveres pronto."
        : "🏖️ Fim de Época — mercado aberto a transferências. Negoceia no Mercado e clica em \"Avançar para a nova época\" quando estiveres pronto.";
      return;
    }
    if(state.playoffActive){
      const daysLeft = Math.round((state.playoff.nextGameDate - state.currentDate)/86400000);
      lbl.textContent = daysLeft<=0 ? `📅 Dia de jogo do playoff! (${state.playoff.phase})` : `Próximo jogo do playoff em ${daysLeft} dia${daysLeft>1?'s':''} (${fmtDateShort(state.playoff.nextGameDate)})`;
      return;
    }
    // Correção: só considerava a jornada da liga do utilizador, nunca a Taça de Portugal — se o
    // próximo jogo do utilizador fosse da Taça, o campo ficava vazio ou mostrava informação da
    // liga sem sentido. Recolhe os dois candidatos conhecidos com antecedência (liga e Taça) e
    // escolhe o mais próximo, identificando sempre a competição a que se refere.
    const candidatos = [];
    const nextRound = state.currentRound < state.fixtures.length ? state.fixtures[state.currentRound] : null;
    if(nextRound) candidatos.push({ date: nextRound.date, label: `Jornada ${state.currentRound+1} de ${competitionLabel(state.userCompetitionId)}` });
    const minhaTaca = tacaMyTieForCurrentDate();
    if(minhaTaca) candidatos.push({ date: minhaTaca.date, label: TACA_FASE_LABEL[state.tacaPortugal.fase] });
    const minhaSupertaca = supertacaMyFixtureForCurrentDate();
    if(minhaSupertaca) candidatos.push({ date: minhaSupertaca.date, label: "Supertaça António Livramento" });
    { const amig = typeof preSeasonNextFriendlyRow==="function" ? preSeasonNextFriendlyRow() : null; if(amig) candidatos.push(amig); }
    // Correção (pedido do utilizador, 2026-09-12): faltavam aqui a Elite Cup, a Copa del Rey/
    // Coppa Italia, as Supercopas e — sobretudo — a Europa (Champions/Cup/Trophy/Qualificação):
    // um jogo europeu do próprio utilizador nunca aparecia nesta contagem, que ficava presa à
    // liga doméstica mesmo com um jogo europeu mais próximo já agendado. Reaproveita a mesma
    // função que preenche "Calendário & Resultados" (10-estatisticas.js), filtrada aos jogos
    // ainda não disputados.
    if(typeof otherCompetitionsScheduleRows==="function"){
      otherCompetitionsScheduleRows().forEach(r=>{ if(!r.played) candidatos.push({ date:r.date, label:r.competicao }); });
    }
    // Correção (2026-10-16): entre o início da época nova e o fim da Elite Cup, state.seasonOver
    // ainda é herdado da época anterior (finalizeNewSeasonTail só o repõe no fim) — o texto
    // "Playoff terminado" ficava preso na época nova. Nessa janela mostra-se o próximo evento real.
    const janelaEpocaNova = state.seasonOver && (state.presEpocaNovaDesde === state.season || state.eliteCupPostSequence==="newSeasonTail"); // eliteCupPostSequence sobrevive a gravar/carregar
    if(janelaEpocaNova){
      if(candidatos.length){
        candidatos.sort((a,b)=>new Date(a.date)-new Date(b.date));
        const proximo = candidatos[0];
        const daysLeft = Math.round((new Date(proximo.date) - state.currentDate)/86400000);
        lbl.textContent = daysLeft<=0 ? "📅 Dia de jogo!" : `${proximo.label} em ${daysLeft} dia${daysLeft>1?'s':''} (${fmtDateShort(proximo.date)})`;
      } else lbl.textContent = "🏆 Época nova a arrancar — clica em Continuar";
    } else if(state.seasonOver){
      lbl.textContent = PLAYOFF_DIVISION_CONFIG[currentCompetition().divisionId] ? "🏆 Playoff terminado — clica em Continuar para avançar de época" : "✓ Fase regular concluída — clica em Continuar para avançar de época";
    } else if(candidatos.length){
      candidatos.sort((a,b)=>new Date(a.date)-new Date(b.date));
      const proximo = candidatos[0];
      const daysLeft = Math.round((new Date(proximo.date) - state.currentDate)/86400000);
      lbl.textContent = daysLeft<=0 ? "📅 Dia de jogo!" : `${proximo.label} em ${daysLeft} dia${daysLeft>1?'s':''} (${fmtDateShort(proximo.date)})`;
    } else {
      lbl.textContent = "";
    }
  }

  function maybeGenerateFlavorNews(){
    if(Math.random() > 0.18) return;
    const allEntries = [];
    Object.values(state.teams).filter(t=>t.divisaoAtual===myTeam().divisaoAtual).forEach(t => t.players.forEach(p => allEntries.push({p, t})));
    if(!allEntries.length) return;
    const { p, t } = allEntries[rnd(0, allEntries.length-1)];
    let text;
    const nomeFlavor = playerLinkHtml(t.id,p);
    if((p.suspensoJogos||0) > 0) text = `${nomeFlavor} (${teamLinkHtml(t.id)}) continua a cumprir suspensão.`;
    else if((p.diasLesao||0) > 0) text = (p.lesaoInfo && p.lesaoInfo.diagnosticoPendente) ? `${nomeFlavor} (${teamLinkHtml(t.id)}) aguarda o diagnóstico do departamento médico.` : `${nomeFlavor} (${teamLinkHtml(t.id)}) continua a recuperar de lesão.`;
    else if(p.moral < 30) text = `${nomeFlavor} (${teamLinkHtml(t.id)}) mostra sinais de descontentamento com a falta de minutos de jogo.`;
    else if(p.moral > 85) text = `${nomeFlavor} (${teamLinkHtml(t.id)}) atravessa um excelente momento de forma e confiança.`;
    else return; // keep noise low — only publish notable moods
    pushNews(state.currentDate, text, "geral");
  }

  // =================================================================
  // Jogador provisório "Henrique Dias" — criado apenas quando as suspensões impedem uma
  // equipa (do utilizador ou da IA) de completar uma convocatória mínima. Existe só para
  // essa partida; nunca fica no plantel, carreira, histórico ou save.
  // =================================================================
  function makeHenriqueDias(teamId, pos){
    // 0.2.9: OVR muito baixo (pedido do utilizador) — o provisório é o último recurso e nunca devia
    // ser melhor que o plantel que substitui: atributos = metade do OVR médio do plantel real (3 a 6).
    const _t = state.teams && state.teams[teamId];
    const _real = _t ? _t.players.filter(p=>!p.__provisional) : [];
    const _avg = _real.length ? _real.reduce((a,p)=>a+overall(p),0)/_real.length : 8;
    const v = clamp(Math.round(_avg*0.5), 3, 6), w = Math.max(2, v-1);
    const attrs = pos==="GR"
      ? { reflexos:v, umParaUm:v, agilidade:v, concentracao:v, meiaDistancia:v, forca:v, agressividade:w, determinacao:w, lideranca:w, resistencia:v }
      : { habilidade:v, drible:v, criatividade:v, finalizacao:v, bolasParadas:v, meiaDistancia:v, posicionamento:v, desarme:v, forca:v, velocidade:v, aceleracao:v, agressividade:w, determinacao:w, lideranca:w, resistencia:v };
    return {
      id: "provisorio-"+teamId+"-"+pos+"-"+uid(),
      num: 0, name: "Henrique Dias", pos, age: 25, attrs, potential: v,
      contrato: { salarioMensal: 500, anos: 0, dataInicio: isoDate(state.currentDate||new Date()), dataFim: isoDate(state.currentDate||new Date()), papel: "Rotacao" },
      preContrato: null,
      temperamento: "Calmo",
      moral: 60, titular:false, suspensoJogos:0, diasLesao:0, condicao:100,
      season: createEmptyStats("season"),
      career: createEmptyStats("career"),
      historico: [],
      __provisional: true, provisionalCategory:"match-only",
    };
  }
  // Reforço de emergência entre Equipa A e Equipa B (2026-10-03, pedido do utilizador: "A IA
  // também" deve poder trocar jogadores entre A e B no dia do jogo) — usado por ensureMinimumSquad
  // logo abaixo, para QUALQUER clube (do utilizador ou da IA) que tenha as duas equipas: antes de
  // inventar um "Henrique Dias", tenta chamar um jogador real e disponível da equipa irmã, desde
  // que essa equipa irmã não tenha, ela própria, um jogo nesse mesmo dia (nunca o mesmo jogador em
  // dois jogos ao mesmo tempo). O jogador regressa à equipa de origem logo a seguir à partida —
  // ver removeProvisionalPlayers — nunca é uma transferência interna permanente (essa continua a
  // ser só pela Ficha do Jogador / Mercado Interno, transferPlayerBetweenAandB).
  function siblingTeamFor(team){
    if(team.equipaBId && state.teams[team.equipaBId]) return state.teams[team.equipaBId];
    if(team.equipaPrincipalId && state.teams[team.equipaPrincipalId]) return state.teams[team.equipaPrincipalId];
    return null;
  }
  // Responde "esta equipa tem um jogo agendado (e por disputar) para a data atual, nalguma
  // competição em que participa?" — basta para decidir se é seguro ir buscar-lhe um jogador
  // emprestado por um dia: todas as competições (incluindo a 2.ª/3.ª Divisão, onde jogam as
  // equipas B) correm sobre o mesmo calendário global (state.currentDate), cada uma com a data da
  // sua própria jornada pendurada na própria ronda (round.date — ver rebuildGlobalAgenda/
  // 03-calendario.js). As Taças/Supertaças/Europa nunca incluem equipas B (Artigo 43.º, ponto 9 do
  // RGHP e equivalentes), por isso não é preciso verificá-las aqui.
  function teamHasFixtureToday(teamId){
    return Object.values(state.competitions).some(comp => {
      if(!comp.teamIds || !comp.teamIds.includes(teamId)) return false;
      // 2026-10-16: qualquer jogo HOJE, já disputado ou não — a 2.ª Divisão é processada antes do
      // Placard no mesmo domingo, e um jogador da B que já jogou hoje não pode ir reforçar a A.
      return (comp.fixtures||[]).some(round => round && round.date && sameDay(round.date, state.currentDate) &&
        round.some(fx => fx.home===teamId || fx.away===teamId));
    });
  }
  function tryBorrowFromSibling(team, pos){
    const sibling = siblingTeamFor(team);
    if(!sibling || teamHasFixtureToday(sibling.id)) return null;
    const candidate = sibling.players
      .filter(p=>p.pos===pos && !p.__provisional && !p.emprestimo && playerAvailableForMatch(p))
      .sort((a,b)=>overall(b)-overall(a))[0];
    if(!candidate) return null;
    sibling.players = sibling.players.filter(p=>p.id!==candidate.id);
    candidate.__loanedForMatchFrom = sibling.id;
    candidate.titular = false;
    return candidate;
  }
  // Garante 1+ GR e 5+ jogadores de campo disponíveis (não suspensos), indo primeiro buscar
  // reforços reais à equipa irmã (tryBorrowFromSibling) e só criando Henrique Dias quando isso não
  // chega ou não é possível. Devolve a lista de jogadores adicionados, para remover/devolver depois
  // da partida (ver removeProvisionalPlayers).
  // Regulamento de hóquei em patins: toda a convocatória (também nos jogos simulados entre
  // clubes IA, que passam por aqui) tem de ter 2 guarda-redes disponíveis.
  function ensureMinimumSquad(team){
    const added = [];
    // Equipa B como campo de experiência sénior (08zb-b-experiencia.js): sub-19 da academia e
    // jogadores da A a regressar de lesão são chamados ao jogo oficial da B (regressam depois).
    if(typeof bxReforcosParaB==="function") bxReforcosParaB(team, added);
    const realGR=realGoalkeeperCount(team);
    const unavailableGR=team.players.filter(p=>p.pos==="GR"&&!p.__provisional&&!playerAvailableForMatch(p)).length;
    let availableGR = team.players.filter(p=>p.pos==="GR" && playerAvailableForMatch(p)).length;
    while(availableGR < 2){
      const p = tryBorrowFromSibling(team, "GR") || makeHenriqueDias(team.id, "GR");
      team.players.push(p); added.push(p); availableGR++;
    }
    let availableJ = team.players.filter(p=>p.pos==="J" && playerAvailableForMatch(p)).length;
    while(availableJ < 5){
      const p = tryBorrowFromSibling(team, "J") || makeHenriqueDias(team.id, "J");
      team.players.push(p); added.push(p); availableJ++;
    }
    const provisionalAdded = added.filter(p=>p.__provisional);
    if(provisionalAdded.length){
      if(!Array.isArray(state.provisionalUsageHistory))state.provisionalUsageHistory=[];
      provisionalAdded.forEach(p=>state.provisionalUsageHistory.push({season:state.season,teamId:team.id,position:p.pos,fixtureId:state.pendingFixture&&state.pendingFixture.id||null,reason:p.pos==="GR"?(realGR<STRUCTURAL_MIN_GOALKEEPERS?"structural-shortage":"unavailability"):"outfield-unavailability",realGoalkeepers:realGR,unavailableGoalkeepers:unavailableGR}));
      // Correção (pedido do utilizador, 2026-09-17: "não quero ver esta notícia"): é um detalhe
      // de bastidores da IA (o próprio historial fica registado acima, em
      // state.provisionalUsageHistory, para quem quiser investigar), sem interesse de jogo para
      // o utilizador — deixa de gerar notícia, mesmo quando é o próprio clube do utilizador a
      // precisar (o utilizador já vê isso diretamente na convocatória do seu jogo).
    }
    const borrowedAdded = added.filter(p=>p.__loanedForMatchFrom);
    if(borrowedAdded.length){
      if(!Array.isArray(state.siblingLoanUsageHistory))state.siblingLoanUsageHistory=[];
      borrowedAdded.forEach(p=>state.siblingLoanUsageHistory.push({season:state.season,teamId:team.id,fromTeamId:p.__loanedForMatchFrom,position:p.pos,fixtureId:state.pendingFixture&&state.pendingFixture.id||null}));
    }
    return added;
  }
  function removeProvisionalPlayers(team, added){
    if(!added || !added.length) return;
    const ids = new Set(added.map(p=>p.id));
    team.players = team.players.filter(p=>{
      if(!ids.has(p.id)) return true;
      if(p.__academyLoanFrom){
        bxDevolverParaAcademia(p);
        return false;
      }
      if(p.__loanedForMatchFrom){
        if(p.__bxRodagem) bxAposRodagem(p);
        // Reforço real emprestado só para esta partida (tryBorrowFromSibling acima) — regressa à
        // equipa de origem assim que a partida termina. Se, entretanto, o utilizador tiver feito
        // uma transferência interna A/B manual e permanente sobre este mesmo jogador (Ficha do
        // Jogador / Mercado Interno), ele já não consta de team.players (saiu por essa via) — este
        // filtro não lhe toca, e transferPlayerBetweenAandB já limpou a marca __loanedForMatchFrom.
        const origin = state.teams[p.__loanedForMatchFrom];
        delete p.__loanedForMatchFrom;
        if(origin && !origin.players.some(x=>x.id===p.id)) origin.players.push(p);
        return false;
      }
      return !p.__provisional;
    });
  }

  function processRound(round){
    const myFixture = round.find(f=>f.home===state.userTeamId || f.away===state.userTeamId);
    round.forEach(fx => {
      if(fx===myFixture || fx.played) return;
      const servingHome = getSuspendedIds(fx.home);
      const servingAway = getSuspendedIds(fx.away);
      const addedHome = ensureMinimumSquad(state.teams[fx.home]);
      const addedAway = ensureMinimumSquad(state.teams[fx.away]);
      const res = simulateMatchToCompletion(fx.home, fx.away, false, false, state.userCompetitionId);
      recordFixtureResult(state.currentRound, fx.home, fx.away, res.home, res.away, res.soWinner, res.attendance);
      applyStandings(fx.home, fx.away, res.home, res.away, res.soWinner);
      finalizeSuspensions(fx.home, servingHome); finalizeSuspensions(fx.away, servingAway);
      removeProvisionalPlayers(state.teams[fx.home], addedHome);
      removeProvisionalPlayers(state.teams[fx.away], addedAway);
    });
    // Nota: a notícia da jornada (resultados) já é gerada por buildJornadaResultsNews, chamada em
    // maybeAdvanceRound() mais abaixo, depois de o jogo do próprio utilizador também terminar —
    // não duplicar aqui.
    renderStandings(); renderFixtures(); renderTeams(); renderStats();

    if(!myFixture){ maybeAdvanceRound(); return; }

    const oppId = myFixture.home===state.userTeamId ? myFixture.away : myFixture.home;
    state.pendingProvisional = {
      mine: ensureMinimumSquad(myTeam()),
      opp: ensureMinimumSquad(state.teams[oppId]),
    };
    if(state.convocadosSelecionados) state.pendingProvisional.mine.forEach(p => { state.convocadosSelecionados[p.id] = true; });

    state.pendingFixture = myFixture;
    // Nota: o relatório pré-jogo é normalmente gerado 1 dia antes (ver o "aviso de véspera" no
    // continuarBtn) — esta chamada aqui é só uma rede de segurança, caso essa véspera tenha sido
    // saltada por algum motivo (ex.: cargar um save a meio da semana); generatePreGameReport já
    // tem proteção própria contra duplicação (fixture.__preGameReportDone).
    generatePreGameReport(myFixture, `${competitionLabel(state.userCompetitionId)} — Jornada ${state.currentRound+1} de ${state.fixtures.length}`, state.userCompetitionId, round.date);
    state.pendingSuspensionServing = { home: getSuspendedIds(myFixture.home), away: getSuspendedIds(myFixture.away) };
    // Correção: ao chegar ao dia de jogo, o utilizador entrava logo na convocatória, sem
    // nenhuma paragem — não dava para ver o resumo do dia primeiro. Passa a só marcar que o
    // jogo está pronto a começar; o botão "Continuar" muda de texto e só abre a convocatória
    // quando for clicado de novo (ver updateContinuarBtnLabel e o topo do seu click handler).
    state.matchDayReady = true;
  }

  // ============================= Fase 2: relatórios do treinador adjunto =============================
  // Relatório pré-jogo (secção 5 do documento) — gerado uma única vez por confronto (marcado no
  // próprio objeto do jogo, para não repetir se a convocatória for reaberta), a partir do
  // histórico tático real do adversário e do perfil médio do seu plantel. Aparece nas notícias.
  function generatePreGameReport(fixture, competitionText, competitionIdForStandings, dataJogo){
    if(!fixture || fixture.__preGameReportDone) return;
    fixture.__preGameReportDone = true;
    const oppId = fixture.home===state.userTeamId ? fixture.away : fixture.home;
    const opp = state.teams[oppId]; if(!opp) return;
    const isHome = fixture.home===state.userTeamId;
    const meuTeam = myTeam();
    const hist = (opp.historicoTatico||[]).slice(0,10);
    const sistemaCounts = {};
    hist.forEach(h=>{ sistemaCounts[h.sistema]=(sistemaCounts[h.sistema]||0)+1; });
    const sistemaMaisUsado = Object.keys(sistemaCounts).sort((a,b)=>sistemaCounts[b]-sistemaCounts[a])[0] || opp.identidadeSistemaPrincipal || "3-1";
    const pctSistema = hist.length ? Math.round((sistemaCounts[sistemaMaisUsado]||0)/hist.length*100) : null;
    const topScorer = opp.players.slice().sort((a,b)=>(b.season.golos||0)-(a.season.golos||0))[0];
    const bestForm = opp.players.filter(p=>p.season.notas&&p.season.notas.length)
      .sort((a,b)=>avg(b.season.notas.slice(-5))-avg(a.season.notas.slice(-5)))[0];
    const outfield = opp.players.filter(p=>p.pos==="J");
    const avgDesarme = outfield.length?avg(outfield.map(p=>p.attrs.desarme!=null?p.attrs.desarme:10)):10;
    const avgCriatividade = outfield.length?avg(outfield.map(p=>p.attrs.criatividade!=null?p.attrs.criatividade:10)):10;
    const avgVelocidade = outfield.length?avg(outfield.map(p=>p.attrs.velocidade!=null?p.attrs.velocidade:10)):10;
    const pontosFortes=[], pontosFracos=[];
    if(avgDesarme>=13) pontosFortes.push("organização defensiva"); else pontosFracos.push("fragilidade defensiva");
    if(avgCriatividade>=13) pontosFortes.push("posse de bola"); else pontosFracos.push("pouca criatividade ofensiva");
    if(avgVelocidade>=13) pontosFortes.push("transições rápidas");
    const avcs = outfield.filter(p=>p.linha==="Avancado");
    if(avcs.length<2) pontosFracos.push("pouca profundidade ofensiva");
    const titularesOrdenados = outfield.filter(p=>p.titular).sort((a,b)=>overall(b)-overall(a));
    const suplentes = outfield.filter(p=>!p.titular).sort((a,b)=>overall(b)-overall(a));
    if(titularesOrdenados.length && suplentes.length && overall(titularesOrdenados[0])-overall(suplentes[0])>=3) pontosFracos.push("dependência dos titulares");
    const sugestaoSistema = meuTeam ? SISTEMAS_TAC.slice().sort((a,b)=>systemFitScore(meuTeam,b)-systemFitScore(meuTeam,a))[0] : "3-1";
    const sugestaoPressao = opp.identidadeMentalidadePreferencial==="ofensivo" ? "alta" : opp.identidadeMentalidadePreferencial==="defensivo" ? "media" : "media";
    const pressaoLabel = {baixa:"Baixa",media:"Média",alta:"Alta"};
    const mentalidadeLabel = {defensivo:"Defensiva",equilibrado:"Equilibrada",ofensivo:"Ofensiva"};

    // Pedido explícito: o relatório tem de dizer a competição, a classificação do adversário,
    // golos marcados/sofridos, e mais estatísticas — antes só tinha sistema/pressão/mentalidade
    // e pontos fortes/fracos, sem contexto nenhum da própria competição ou do momento de forma.

    // Classificação do adversário: só faz sentido em competições de liga (a Taça é eliminação
    // direta, sem tabela) — competitionIdForStandings vem null nesse caso.
    let classificacaoTxt = "", chipClass = null;
    if(competitionIdForStandings){
      const tabela = standingsForCompetition(competitionIdForStandings);
      const posOpp = tabela.findIndex(t=>t.id===oppId)+1;
      const posMeu = tabela.findIndex(t=>t.id===state.userTeamId)+1;
      const rowOpp = tabela.find(t=>t.id===oppId);
      // Na Jornada 1 (e outras jornadas iniciais) todas as equipas estão empatadas a 0 pontos —
      // só mostra classificação depois de o adversário já ter pelo menos 3 jogos.
      if(posOpp>0 && rowOpp && rowOpp.stats && rowOpp.stats.J>=3){
        const distancia = posMeu>0 ? posMeu-posOpp : null;
        const distanciaTxt = distancia==null ? "" : distancia===0 ? " — mesma posição que a tua" : distancia>0 ? ` — ${distancia} posiç${distancia>1?'ões':'ão'} acima de ti` : ` — ${Math.abs(distancia)} posiç${Math.abs(distancia)>1?'ões':'ão'} abaixo de ti`;
        classificacaoTxt = `<b>${posOpp}.º lugar</b>, ${rowOpp.stats.Pts||0} pontos${distanciaTxt}`;
        chipClass = `${posOpp}.º lugar`;
      }
    }

    // Forma recente (últimos 5 jogos, mais recente primeiro) e golos marcados/sofridos por
    // jogo esta época (a partir do historicoTatico, filtrado pela data de início da época atual).
    const formaLista = hist.slice(0,5).map(h=>h.resultado);
    const inicioEpoca = new Date(2026+(state.season-1), 9, 1);
    const histEpoca = (opp.historicoTatico||[]).filter(h=>h.date && new Date(h.date)>=inicioEpoca);
    const jogosEpoca = histEpoca.length;
    const mediaMarcados = jogosEpoca ? (histEpoca.reduce((s,h)=>s+(h.golosMarcados||0),0)/jogosEpoca).toFixed(1) : null;
    const mediaSofridos = jogosEpoca ? (histEpoca.reduce((s,h)=>s+(h.golosSofridos||0),0)/jogosEpoca).toFixed(1) : null;

    // Disciplina acumulada da equipa esta época.
    const amarelos = opp.players.reduce((s,p)=>s+(p.season.amarelos||0),0);
    const azuis = opp.players.reduce((s,p)=>s+(p.season.azuis||0),0);
    const vermelhos = opp.players.reduce((s,p)=>s+(p.season.vermelhos||0),0);

    // Histórico direto: o último confronto entre as duas equipas.
    const ultimoConfronto = (opp.historicoTatico||[]).find(h=>h.opponentId===state.userTeamId);
    let confrontoTxt = "sem confrontos anteriores registados";
    if(ultimoConfronto){
      const empate = ultimoConfronto.resultado==="E";
      const oppGanhou = ultimoConfronto.resultado==="V";
      const vencedor = empate ? "Empate" : (oppGanhou ? teamLinkHtml(opp.id) : (meuTeam?teamLinkHtml(meuTeam.id):"O teu clube"));
      confrontoTxt = `<b>${ultimoConfronto.golosMarcados}-${ultimoConfronto.golosSofridos}</b> (${vencedor}${empate?'':' venceu'}, ${fmtDateShort(new Date(ultimoConfronto.date))})`;
    }

    // Jogadores em dúvida do lado do adversário (suspensos ou lesionados para este jogo).
    const suspensos = opp.players.filter(p=>(p.suspensoJogos||0)>0).map(p=>`${playerLinkHtml(opp.id,p)} (suspenso)`);
    const lesionadosOpp = opp.players.filter(p=>(p.diasLesao||0)>0).map(p=>`${playerLinkHtml(opp.id,p)} (lesionado)`);
    const desfalquesOpp = suspensos.concat(lesionadosOpp);

    // Assistência/palco: nota de textura, com base na dimensão do clube visitado.
    const apelo = clubAppeal ? clubAppeal(opp) : 60;
    const palcoTxt = apelo>=78 ? "pavilhão deve encher — jogo de grande cartaz." :
      apelo>=60 ? "boa adesão do público prevista." :
      "adesão modesta, como é habitual neste recinto.";

    const arbTxt = repLimpaBr(arbitroLinhaAdjunto(fixture.home, fixture.away, isHome)).replace(/^Árbitro nomeado:\s*/,"");
    const sugestaoTxt = `utilizar o sistema <b>${sugestaoSistema}</b> com pressão <b>${pressaoLabel[sugestaoPressao].toLowerCase()}</b>.`;
    const chips = [repChip(isHome?"Em casa":"Fora")];
    if(chipClass) chips.push(repChip(chipClass));
    chips.push(repChip(`Sistema ${sistemaMaisUsado}${pctSistema!=null?` (${pctSistema}%)`:''}`));
    chips.push(repChip(`Pressão ${(pressaoLabel[opp.identidadePressaoPreferencial]||'—').toLowerCase()}`));
    if(desfalquesOpp.length) chips.push(repChip(`${desfalquesOpp.length} desfalque${desfalquesOpp.length>1?'s':''}`, "aviso"));
    const ehAmig = !!fixture.amigavel || competitionText === "Jogo de preparação";
    const secRot = ehAmig && typeof amigSecaoRotacaoHtml === "function" ? amigSecaoRotacaoHtml(meuTeam) : null;
    const html = repDoc({
      teamId: state.userTeamId, org: "Departamento técnico", titulo: "Relatório do Treinador Adjunto",
      sub: `${competitionText?escapeHtml(competitionText)+" · ":""}${(()=>{ const dj = new Date(fixture.date || dataJogo || state.currentDate); return isNaN(dj.getTime()) ? "" : fmtDateLong(dj); })()}`,
      vsId: opp.id, vsTexto: isHome?"recebes":"visitas",
      chips,
      resumo: ehAmig ? `Jogo de preparação: aproveita para rodar o plantel e experimentar (ver rotação sugerida). ${pontosFracos.length?`Pontos fracos do adversário: ${pontosFracos.join(", ")}.`:""}`
        : `${sugestaoTxt.charAt(0).toUpperCase()+sugestaoTxt.slice(1)} ${pontosFracos.length?`Pontos fracos do adversário: ${pontosFracos.join(", ")}.`:""}`,
      secoes: [
        ...(secRot ? [secRot] : []),
        ...((typeof lesSecaoSaudeHtml === "function" && lesSecaoSaudeHtml(meuTeam)) ? [Object.assign({}, lesSecaoSaudeHtml(meuTeam), { cheia:true })] : []),
        { icone:"📊", titulo:"Momento do adversário", linhas:[
          ["Classificação", classificacaoTxt || "ainda por definir (poucos jogos)"],
          ["Forma recente", formaLista.length ? repFormaHtml(formaLista)+' <span style="color:#8a9097;font-size:12px;">(mais recente à esquerda)</span>' : "sem histórico ainda"],
          ["Golos por jogo", mediaMarcados!=null ? `<b>${mediaMarcados}</b> marcados, <b>${mediaSofridos}</b> sofridos (${jogosEpoca} jogo${jogosEpoca!==1?'s':''})` : "sem dados ainda"],
          ["Último confronto", confrontoTxt],
        ]},
        { icone:"🧩", titulo:"Como joga", linhas:[
          ["Sistema", `<b>${sistemaMaisUsado}</b>${pctSistema!=null?` (${pctSistema}%)`:' (sem histórico ainda)'}`],
          ["Pressão", `<b>${pressaoLabel[opp.identidadePressaoPreferencial]||'—'}</b>`],
          ["Mentalidade", `<b>${mentalidadeLabel[opp.identidadeMentalidadePreferencial]||'—'}</b>`],
          ["Pontos fortes", pontosFortes.length?pontosFortes.join(", "):"—"],
          ["Pontos fracos", pontosFracos.length?pontosFracos.join(", "):"—"],
        ]},
        { icone:"🎯", titulo:"Jogadores a vigiar", linhas:[
          ["Melhor marcador", topScorer&&topScorer.season.golos?`${playerLinkHtml(opp.id,topScorer)} (${topScorer.season.golos} golos)`:'ainda sem golos esta época'],
          ["Em melhor forma", bestForm?playerLinkHtml(opp.id,bestForm):'ainda sem avaliações suficientes'],
          ["Desfalques", desfalquesOpp.length?desfalquesOpp.join(", "):"nenhum conhecido de momento"],
        ]},
        { icone:"🏟️", titulo:"Contexto do jogo", linhas:[
          ["Árbitro", arbTxt || ""],
          ["Assistência", palcoTxt],
        ]},
      ],
      detalhes: [{ titulo:"Disciplina do adversário", html: (amarelos+azuis+vermelhos)>0 ? `Esta época: ${amarelos} amarelo${amarelos!==1?'s':''}, ${azuis} ${azuis===1?'azul':'azuis'}, ${vermelhos} vermelho${vermelhos!==1?'s':''}.` : "Sem cartões registados ainda." }],
      rodape: "Relatório pré-jogo · treinador adjunto",
    });
    pushNews(state.currentDate, html, "tatica", `Relatório pré-jogo vs ${opp.name}`);
  }
  // Relatório tático mensal (secção 7) — agregando o histórico do próprio clube nesse mês.
  function generateMonthlyTacticalReport(){
    if(!state.userTeamId || !state.currentDate) return;
    const monthKey = `${state.currentDate.getFullYear()}-${String(state.currentDate.getMonth()+1).padStart(2,"0")}`;
    if(state.lastMonthlyTacticalReport===monthKey) return;
    state.lastMonthlyTacticalReport = monthKey;
    const team = myTeam(); if(!team) return;
    // 2026-10-16: o relatório é do mês que ACABOU — corre no 1.º dia do mês novo, quando ainda não há
    // jogos desse mês (filtrava pelo mês atual e nunca publicava nada).
    const dPrev = new Date(state.currentDate.getFullYear(), state.currentDate.getMonth()-1, 15);
    const prevKey = `${dPrev.getFullYear()}-${String(dPrev.getMonth()+1).padStart(2,"0")}`;
    const hist = (team.historicoTatico||[]).filter(h=>h.date && h.date.slice(0,7)===prevKey);
    if(!hist.length) return;
    const bySystem = {"3-1":[], "2-2":[], "1-2-1":[]};
    hist.forEach(h=>{ if(bySystem[h.sistema]) bySystem[h.sistema].push(h); });
    const stats = {};
    SISTEMAS_TAC.forEach(s=>{
      const arr = bySystem[s];
      const pontos = arr.reduce((sum,h)=>sum+(h.resultado==="V"?3:h.resultado==="E"?1:0),0);
      stats[s] = {
        jogos: arr.length,
        pontosPorJogo: arr.length?roundDecimal(pontos/arr.length):0,
        golosMarcados: arr.reduce((s2,h)=>s2+h.golosMarcados,0),
        golosSofridos: arr.reduce((s2,h)=>s2+h.golosSofridos,0),
      };
    });
    const totalJogos = hist.length;
    const usados = SISTEMAS_TAC.filter(s=>stats[s].jogos>0);
    const sistemaMaisUsado = SISTEMAS_TAC.slice().sort((a,b)=>stats[b].jogos-stats[a].jogos)[0];
    const pctMaisUsado = totalJogos?Math.round((stats[sistemaMaisUsado].jogos/totalJogos)*100):0;
    const melhorRendimento = (usados.length?usados:SISTEMAS_TAC).slice().sort((a,b)=>stats[b].pontosPorJogo-stats[a].pontosPorJogo)[0];
    const listaSis = (fn) => SISTEMAS_TAC.filter(s=>stats[s].jogos>0 || s===team.sistema).map(s=>`${s}: ${fn(s)}`).join(" · ");
    const html = repDoc({
      teamId: team.id, org: "Departamento técnico", titulo: "Relatório Tático Mensal",
      sub: `${MONTHS[state.currentDate.getMonth()]} de ${state.currentDate.getFullYear()} · ${totalJogos} jogo${totalJogos!==1?'s':''} analisado${totalJogos!==1?'s':''}`,
      chips: [repChip(`Mais usado: ${sistemaMaisUsado} (${pctMaisUsado}%)`), repChip(`Melhor rendimento: ${melhorRendimento}`, "ok")],
      resumo: `Continuar a desenvolver o <b>${melhorRendimento}</b>.`,
      secoes: [
        { icone:"📈", titulo:"Rendimento por sistema", cheia:true, linhas:[
          ["Pontos por jogo", listaSis(s=>`<b>${stats[s].pontosPorJogo}</b>`)],
          ["Golos marcados", listaSis(s=>stats[s].golosMarcados)],
          ["Golos sofridos", listaSis(s=>stats[s].golosSofridos)],
          ["Familiaridade", SISTEMAS_TAC.map(s=>`${s}: ${Math.round(famOf(team,s))}`).join(" · ")],
        ]},
      ],
      rodape: "Relatório tático mensal · treinador adjunto",
    });
    pushNews(state.currentDate, html, "tatica", "Relatório tático mensal");
  }

  function dailyConditionRecovery(){
    // Setas de evolução (08-evolucao-jogadores.js): ponto único que corre todos os dias, em todos os ramos do calendário.
    trackUserSquadEvolution();
    // Adeptos (08f-adeptos.js): reação diária a saídas de ídolos / reforços sonantes do clube do utilizador.
    if(state.userTeamId && state.teams[state.userTeamId]) adeptosSyncIdolos(state.teams[state.userTeamId]);
    // Jogadores à experiência (08h-experiencia.js): fecha as experiências que chegam ao fim e entrega o relatório do adjunto.
    resolverExperienciasDiarias();
    // Empréstimos (08i-emprestimos.js): utilização mínima, chamada de volta, alertas e relatório mensal dos emprestados.
    processarEmprestimosDiario();
    // Carga de trabalho (08l-carga.js): decaimento diário da carga de todos os jogadores + aviso de rotação do adjunto.
    cargaDiario();
    // Conselho de Disciplina (08k-disciplina.js): decisões, recursos e prazos de todos os clubes. Televisão (08m): escolha dos jogos da jornada seguinte.
    disciplinaDiario();
    tvDiario();
    // Clássicos (08ze-classicos.js): notícias de antevisão e reações pós-jogo dos grandes derbies.
    if(typeof derbyDiario==="function") derbyDiario();
    // Patrocínios (08n-patrocinios.js): propostas que caducam e procura ativa do departamento comercial.
    patrocinioDiario();
    // Pavilhão (08o-pavilhao.js): conclusão das obras.
    pavilhaoDiario();
    arbitroDiario();
    // Clubes satélite (08s-satelites.js): respostas às propostas do utilizador.
    satResolverPedidos(); calAmigDiario();
    // recuperação diária em pontos percentuais absolutos (não proporcional ao que falta):
    // 3,6% ao início da época, a descer ao longo da temporada até ~2,8% no fim, refletindo o
    // desgaste acumulado. Escalado pela qualidade das instalações de treino do clube, e ainda
    // ligeiramente pior para jogadores muito utilizados esta época (carga acumulada individual).
    // Fase 16: reduzido face aos 4,5%-3,5% anteriores — com a curva de fadiga agora mais
    // percetível (fatigueCurve, em 06-motor-jogo.js), uma recuperação tão generosa deixava um
    // titular quase sempre perto de 100% no jogo seguinte (1 jogo/semana ≈ +31% de recuperação),
    // sem qualquer pressão real para rodar o plantel ao longo de uma época normal.
    const seasonProgress = clamp(state.currentRound / Math.max(1, state.fixtures.length), 0, 1);
    const baseAbs = 3.6 - seasonProgress*0.8;
    const christmasRecoveryBonus = isChristmasBreak(state.currentDate) ? 2.0 : 0;
    Object.values(state.teams).forEach(t => {
      const mult = (TREINO_RECOVERY_MULT[t.condicoesTreino] || 1) * medicalRecoveryMult(t); // + departamento médico
      t.players.forEach(p=>{
        refreshPlayerAge(p, state.currentDate);
        const cur = p.condicao!=null ? p.condicao : 100;
        const loadPenalty = clamp(1 - (p.season.jogos||0)*0.003, 0.88, 1);
        const normalRecovery = baseAbs*mult*loadPenalty*cargaRecoveryMult(p);
        p.condicao = roundDecimal(clamp(cur + normalRecovery + christmasRecoveryBonus, 0, 100));
        // Lesões graves (2026-09-14): tempo de paragem contado em dias de calendário, não em
        // jogos (ao contrário de suspensoJogos) — decrementado aqui, no único ponto por onde
        // passa cada dia que o utilizador avança. Ao recuperar, limpa também lesaoInfo (badge/
        // notícia deixam de fazer sentido).
        // 2026-10-16: lesão grave à espera do diagnóstico — fica indisponível até o diagnóstico chegar
        // (antes, ao 2.º dia já podia ser convocado, embora o boletim dissesse "indisponível").
        const aguardaDiagnostico = !!(p.lesaoInfo && p.lesaoInfo.diagnosticoPendente && (state.pendingMedicalEvaluations||[]).some(it=>it&&it.playerId===p.id));
        if((p.diasLesao||0) > 0 && !aguardaDiagnostico){
          p.diasLesao -= 1;
          if(p.diasLesao <= 0){
            p.diasLesao = 0;
            if(p.lesaoInfo && !p.lesaoInfo.diagnosticoPendente){ lesRecuperou(p, t); p.lesaoInfo = null; }
          }
        } else if(p.readapt) lesDiaPassou(p);
      });
    });
    lesMensal(); // relatório mensal do departamento médico (08w-lesoes.js)
    relBMensal(); // relatórios mensais da equipa B: treinador da B + departamento médico (08x-equipa-b.js)
    // Lesões (2026-09-14): resolve os diagnósticos do departamento médico assim que chega a data
    // de resposta — mesmo ponto único de avanço de dia que já resolve scouting/investimentos/
    // carreira do treinador, logo a seguir.
    resolvePendingMedicalEvaluations(state.currentDate);
    // Painel de scouting (2026-09-05): esta função já corre exatamente uma vez por cada dia que
    // o utilizador avança (nos 3 pontos do fluxo que fazem currentDate+=1) — ponto único e seguro
    // para resolver pedidos de scouting pendentes, sem precisar de duplicar a chamada nos 3 sítios.
    resolvePendingScoutingReports(state.currentDate);
    scintDiario(state.currentDate);
    // Investimento em infraestrutura (2026-09-05): mesmo ponto único de avanço de dia, para
    // resolver pedidos de investimento pendentes assim que chega a data de resposta da direção.
    resolvePendingDirectionInvestments(state.currentDate);
    // Carreira do treinador (2026-09-05): mesmo ponto único de avanço de dia, para resolver
    // candidaturas pendentes e expirar propostas de outros clubes.
    resolvePendingManagerCareerEvents(state.currentDate);
    // Mercado de treinadores (2026-09-23): mesmo ponto único de avanço de dia, para preencher
    // vagas de treinador de clubes de IA cujo prazo (algumas semanas) já passou sem o utilizador
    // se ter candidatado — ver resolvePendingTreinadorVacancies (08c-staff-treinadores.js).
    resolvePendingTreinadorVacancies(state.currentDate);
    // Mercado de transferências realista (2026-09-14, pedido do utilizador): propostas de fee
    // entre clubes, termos pessoais (transferência/pré-contrato/livre/renovação) e pedidos de
    // empréstimo já não se resolvem na hora — mesmo ponto único de avanço de dia, para todas as
    // sessões, envolvam ou não o utilizador (é assim que as negociações IA-contra-IA avançam dia
    // a dia sem qualquer intervenção do utilizador). resolvePendingTransferHolds ativa, por fim,
    // as transferências fechadas fora de uma janela real de inscrição (etiqueta TRF) assim que a
    // próxima janela abre.
    resolvePendingClubNegotiations(state.currentDate);
    // Prazo final das inscrições (2026-09-14, pedido do utilizador): logo a seguir a resolver as
    // propostas de fee do dia, caduca os acordos cujo prazo de resposta já passou sem o negócio
    // se ter concretizado — ver resolveExpiredClubAgreements (04-financas.js).
    resolveExpiredClubAgreements(state.currentDate);
    resolvePendingContractNegotiations(state.currentDate);
    // Lembrete de contraproposta (2026-09-16, pedido do utilizador): mesmo ponto único de avanço
    // de dia, logo a seguir a resolver as próprias negociações de termos pessoais.
    resolvePendingContractCounterReminders(state.currentDate);
    resolvePendingLoanNegotiations(state.currentDate);
    resolvePendingTransferHolds(state.currentDate);
    // Ofertas de clubes de IA pelos jogadores do utilizador (2026-09-16, pedido do utilizador:
    // "quando recebo uma proposta por um jogador também deve aparecer um e-mail") — antes só
    // corria quando o ecrã de Mercado era desenhado (renderTransferMarket → generateAiOffersForUser),
    // por isso um avanço de vários dias sem visitar o Mercado nunca gerava propostas nem a notícia
    // "Nova proposta recebida" correspondente. Mesmo ponto único de avanço de dia que já resolve
    // todo o resto do mercado; a própria função já se protege contra duplicação (state.lastAiOfferDate).
    generateAiOffersForUser(false);
    // Contraproposta do utilizador a uma proposta de IA (2026-09-17, pedido do utilizador:
    // "quando faço uma contraproposta a um clube, tem de sair uma notícia e tambem tem de
    // demorar alguns dias. o clube pode recusar a contraproposta e decidir nao continuar com as
    // negociações") — mesmo ponto único de avanço de dia. Logo a seguir, resolve automaticamente
    // uma eventual contraproposta do JOGADOR aos termos pessoais de uma venda iniciada por uma
    // proposta de IA (ver resolvePendingAiOfferContractCounters) — não há utilizador do lado do
    // clube comprador para responder manualmente, tal como tryPurchase já faz sozinho, dia após
    // dia, para compras inteiramente entre clubes de IA.
    resolvePendingAiOfferCounters(state.currentDate);
    resolvePendingAiOfferContractCounters(state.currentDate);
    // Lembrete de proposta por responder (2026-09-17, pedido do utilizador): mesmo ponto único de
    // avanço de dia, logo a seguir a gerar/atualizar as propostas de clubes de IA — ver
    // resolvePendingAiOfferReminders (04-financas.js).
    resolvePendingAiOfferReminders(state.currentDate);
    // Expira propostas por responder quando a janela real de inscrições fecha (2026-09-17, mesma
    // correção): antes só acontecia uma vez, ao sair do ecrã de defeso — passa a verificar-se
    // todos os dias, só expirando de facto quando a janela já fechou (ver expirePendingAiOffers).
    expirePendingAiOffers(state.currentDate);
    // Mercado IA-contra-IA (2026-09-14): agora que compras/livres/empréstimos entre clubes de IA
    // também demoram dias a fechar-se, a passagem que os inicia/continua tem de correr todos os
    // dias (não só uma vez no defeso) — mesmo ponto único de avanço de dia que resolve as
    // negociações acima.
    processAiToAiMarketDaily();
    // Marco S: gestão contínua da IA da própria lista de transferências (ver reviewAllAiTransferListings,
    // 04-financas.js) — corre no mesmo ponto único de avanço de dia, gated por clube (cooldown
    // jitterado), o ano inteiro.
    reviewAllAiTransferListings();
    // Motor de Eventos Narrativos (2026-09-28, ver 09b-eventos-narrativos.js): mesmo ponto único
    // de avanço de dia — uma verificação diária de probabilidade baixa, tal como todo o resto
    // desta função, incluindo durante o defeso.
    processNarrativeEventsForCurrentDate();
  }

  // Correção (bug real, reportado pelo utilizador: vários clubes recorrem a jogadores
  // provisórios logo nos primeiros jogos da nova época, mesmo com plantel completo e 2
  // guarda-redes): beginDefeso() (08-evolucao-jogadores.js) salta state.currentDate diretamente
  // para o início da época seguinte SEM correr dailyConditionRecovery() dia a dia — e é só ali
  // que diasLesao é decrementado. Lesões do fim da época anterior ficavam "congeladas" e
  // continuavam a impedir a convocação de jogadores já recuperados na realidade, depois de
  // meses de defeso. Esta função replica, de uma só vez, o mesmo efeito de
  // dailyConditionRecovery para os dias de defeso saltados: decrementa diasLesao pelo número de
  // dias de calendário entre as duas datas e limpa lesaoInfo quando a lesão fica resolvida.
  function recoverInjuriesDuringDefeso(previousDate, novaData){
    const dias = Math.max(0, Math.round((novaData - previousDate) / 86400000));
    if(dias <= 0) return;
    Object.values(state.teams).forEach(t => t.players.forEach(p => {
      if((p.diasLesao||0) > 0){
        p.diasLesao = Math.max(0, p.diasLesao - dias);
        if(p.diasLesao <= 0 && p.lesaoInfo && !p.lesaoInfo.diagnosticoPendente) p.lesaoInfo = null;
      }
      p.readapt = null; // meses de defeso chegam para a readaptação
    }));
  }

  // Correção: ao chegar ao dia de jogo, entrava-se logo na convocatória, sem paragem — passa a
  // marcar-se apenas "pronto a começar" (matchDayReady) e o botão muda de texto; só ao clicar
  // de novo é que a convocatória abre de facto. Chamada sempre que o estado do botão pode ter
  // mudado, para nunca ficar dessincronizada do texto real.
  function updateContinuarBtnLabel(){
    const btn = document.getElementById("continuarBtn");
    if(!btn) return;
    btn.textContent = state.pendingPostMatchCtx ? "▶ Continuar" : state.matchDayReady ? "▶ Ir para o Jogo" : (state.pendingNarrativeEvent ? "🎬 Ver Evento" : (state.pendingNationalSquadPick ? "🌍 Convocar Selecção" : "▶ Continuar"));
    // Correção (2026-09-17): o botão de encerrar o defeso só aparece mesmo durante o defeso —
    // nos restantes momentos do jogo fica escondido, tal como já acontecia com o próprio texto
    // "Iniciar a Época"/"Avançar para a nova época" (só fazia sentido dentro do modal de resumo).
    const endBtn = document.getElementById("defesoEndBtn");
    if(endBtn){
      endBtn.classList.toggle("hidden", !state.inDefeso);
      endBtn.textContent = state.isPreSeasonDefeso ? "🏁 Iniciar a Época" : "🏁 Avançar para a nova época";
    }
  }
  // Um único avanço de dia (ou de fase, para o defeso/playoff/fim de época) — exatamente a
  // lógica que "Continuar" executava por clique antes do avanço automático de vários dias
  // (2026-09-16, pedido do utilizador: "não quero ter de carregar no botão todos os dias").
  // Cada `return` aqui termina só esta chamada (uma "volta"), não o ciclo que a envolve —
  // ver runContinuarAutoAdvance, logo a seguir.
  function advanceOneDayOrPhaseStep(){
    // Correção (2026-09-17, apontada pelo utilizador: propostas de mercado feitas durante o
    // defeso nunca recebiam resposta): antes, "Continuar" durante o defeso ia direto para
    // finalizePreSeasonDefeso()/finalizeNewSeason() (ver continuarBtn, mais abaixo) sem passar
    // um único dia — dailyConditionRecovery() (onde vivem resolvePendingClubNegotiations,
    // resolvePendingContractNegotiations, resolvePendingLoanNegotiations, etc.) nunca chegava a
    // correr enquanto o utilizador negociava no Mercado. Passa a avançar um dia de cada vez,
    // exatamente como no resto da época — encerrar mesmo a janela de mercado é agora uma ação a
    // parte (botão #defesoEndBtn / "Avançar para a nova época" no modal de resumo).
    if(state.inDefeso){
      // 2026-10-16: o defeso não pode passar da véspera da 1.ª jornada da época — as jornadas ficariam com
      // data anterior ao dia corrente e nunca se jogavam (e o calendário da época nova seria gerado no
      // passado). No último dia, o botão deixa de avançar e a janela fecha-se com "Iniciar a Época".
      const ultimoDiaDefeso = state.isPreSeasonDefeso
        ? (typeof preSeasonWindowEnd==="function" ? preSeasonWindowEnd() : null)
        : addDays(getPlacardOpeningSunday(2025 + state.season + 1), -1);
      if(ultimoDiaDefeso && addDays(state.currentDate, 1) > ultimoDiaDefeso){
        if(state.defesoUltimoDiaAvisado !== state.season){
          state.defesoUltimoDiaAvisado = state.season;
          pushNews(state.currentDate, `🏁 É o último dia possível da janela de mercado — a 1.ª jornada é já a seguir. Clica em "${state.isPreSeasonDefeso ? "Iniciar a Época" : "Avançar para a nova época"}" para fechar o mercado.`, "sistema");
        }
        renderHubDate();
        return;
      }
      state.currentDate = addDays(state.currentDate, 1);
      dailyConditionRecovery(); applyWeeklyTacticalTraining();
      processMonthlyFinances(state.currentDate);
      processAcademyMonthlyDevelopment(state.currentDate); processTreinadorCulturaMonthly(state.currentDate); processTreinadorConfiancaMonthly(state.currentDate);
      // Correção (pedido do utilizador, 2026-09-27: "o jogo tem de começar com a noticia da
      // convocatória... depois vemos as noticias dos jogos"): as duas provas de Seleções caem
      // sempre dentro de uma janela de pré-época (Mundial 16-21/set logo no arranque da
      // carreira, Europeu 1-6/set no início de cada época seguinte) — ou seja, precisamente
      // enquanto state.inDefeso está a true, o ramo que este "if" cobre. Ao contrário das outras
      // provas diárias (Elite Cup/Taça/Europa, que decorrem já dentro da época, fora do defeso,
      // e por isso só precisam de processPhaseFiveFinalsForCurrentDate — chamada mais abaixo,
      // fora deste "if"), sem esta chamada aqui a edição de Seleções ficava parada para sempre
      // enquanto o utilizador demorasse a fechar a janela de mercado (ex.: continuar a negociar
      // depois de 21 de setembro) — as equipas virtuais nunca mais eram apagadas e nenhuma
      // jornada/eliminatória chegava a resolver-se.
      if(typeof processSelecoesForCurrentDate==="function") processSelecoesForCurrentDate();
      if(!processPreSeasonForCurrentDate()) preSeasonPreviewForTomorrow();
      renderHubDate();
      if(state.activeView==="mercado") renderTransferMarket();
      if(state.activeView==="clube") renderClubeView();
      if(state.activeView==="direcao") renderDirectionPanel();
      if(state.activeView==="noticias") renderNews();
      if(state.activeView==="plantel") renderRoster();
      return;
    }
    if(state.playoffActive){
      state.currentDate = addDays(state.currentDate, 1);
      dailyConditionRecovery(); applyWeeklyTacticalTraining();
      processMonthlyFinances(state.currentDate); processAcademyMonthlyDevelopment(state.currentDate); processTreinadorCulturaMonthly(state.currentDate); processTreinadorConfiancaMonthly(state.currentDate); generateMonthlyTacticalReport();
      processGlobalAgendaForCurrentDate();
      processPhaseFiveFinalsForCurrentDate();
      renderHubDate();
      if(state.activeView==="clube") renderClubeView();
      if(state.activeView==="plantel") renderRoster();
      // Correção (bug real, encontrado num teste alargado de 5 épocas): usava sameDay (só
      // dispara exatamente no dia agendado). Se, nesse mesmo dia, outra prova com jogo do
      // próprio utilizador (Taça de Portugal, Supertaça, Liguilha/Final da 2ª Divisão) também
      // reivindicasse o "dia de jogo" (matchDayReady/pendingFixture — só há um de cada vez),
      // o jogo do playoff ficava perdido: nextGameDate nunca mais coincidia com currentDate
      // (que só avança), e o playoff congelava para sempre nessa fase (placardChampion nunca
      // definido, temporada nunca fecha). Passa a "dia chegou ou já passou" — se hoje a vaga já
      // estiver ocupada por outra prova (ver guarda em processPlayoffMatchday), tenta-se de novo
      // no dia seguinte em vez de se perder para sempre.
      if(state.currentDate >= state.playoff.nextGameDate) processPlayoffMatchday();
      else maybeGenerateFlavorNews();
      return;
    }
    if(state.seasonOver){
      if(globalSeasonReadyToClose()){ endOfSeason(); return; }
      // Diagnóstico (pedido do utilizador: "a frase fica presa no fim do playoff"): se a época
      // ficar bloqueada mais de 20 dias seguidos sem fechar, publica-se uma única notícia (não
      // repete, ver seasonCloseStuckWarned) com a lista exata de globalSeasonCloseBlockers() —
      // exatamente o que ainda falta concluir — mais um aviso na consola para diagnóstico. Não
      // força nada nem altera o estado do jogo; só torna visível o que hoje é invisível.
      // 2026-10-16: o aviso disparava em falso — seasonOverSinceDate é marcado no fim da fase REGULAR
      // (antes do playoff) e continua marcado na janela da época nova (Elite Cup). Conta-se agora a
      // partir do 1.º dia em que se está mesmo à espera do fecho, e nunca na janela da época nova.
      const janelaEpocaNovaFecho = state.presEpocaNovaDesde===state.season || state.eliteCupPostSequence==="newSeasonTail";
      if(!janelaEpocaNovaFecho && !state.seasonCloseWaitSince) state.seasonCloseWaitSince = new Date(state.currentDate);
      if(!janelaEpocaNovaFecho && !state.seasonCloseStuckWarned && state.seasonCloseWaitSince && (state.currentDate - state.seasonCloseWaitSince) >= 20*86400000){
        const blockers = globalSeasonCloseBlockers();
        console.warn("HM2027: a época não fecha há mais de 20 dias. Bloqueios:", blockers);
        pushNews(state.currentDate, `⚠️ A época está a demorar invulgarmente a fechar. Em falta: ${blockers.join("; ")}. Se isto persistir, reporta esta mensagem.`, "sistema");
        state.seasonCloseStuckWarned = true;
      }
      state.currentDate=addDays(state.currentDate,1); dailyConditionRecovery(); applyWeeklyTacticalTraining(); processMonthlyFinances(state.currentDate); processAcademyMonthlyDevelopment(state.currentDate); processTreinadorCulturaMonthly(state.currentDate); processTreinadorConfiancaMonthly(state.currentDate); generateMonthlyTacticalReport();
      processGlobalAgendaForCurrentDate(); processPhaseFiveFinalsForCurrentDate(); renderHubDate();
      if(state.activeView==="clube") renderClubeView(); if(state.activeView==="plantel") renderRoster(); return;
    }
    if(state.currentRound >= state.fixtures.length) return;

    state.currentDate = addDays(state.currentDate, 1);
    dailyConditionRecovery(); applyWeeklyTacticalTraining();
    processMonthlyFinances(state.currentDate); processAcademyMonthlyDevelopment(state.currentDate); processTreinadorCulturaMonthly(state.currentDate); processTreinadorConfiancaMonthly(state.currentDate); generateMonthlyTacticalReport();
    const processedAgenda = processGlobalAgendaForCurrentDate();
    processPhaseFiveFinalsForCurrentDate();
    processPreSeasonForCurrentDate();
    renderHubDate();
    if(state.activeView==="clube") renderClubeView();
    if(state.activeView==="plantel") renderRoster();

    const nextRound = state.fixtures[state.currentRound];
    // Correção: a antevisão e o relatório pré-jogo do adjunto só verificavam a jornada da liga,
    // nunca a Taça de Portugal — quando o jogo do dia seguinte era da Taça, nenhum dos dois
    // aparecia. Passa a verificar também a eliminatória da Taça agendada para o clube do
    // utilizador, se houver alguma para amanhã.
    const minhaTaca = tacaMyTieForCurrentDate ? tacaMyTieForCurrentDate() : null;
    const minhaSupertaca = supertacaMyFixtureForCurrentDate();
    if(nextRound && sameDay(state.currentDate, nextRound.date)){
      if(!processedAgenda) console.warn("[HM2027] Jornada sem evento pendente na agenda global.");
    } else if(nextRound && sameDay(addDays(state.currentDate,1), nextRound.date)){
      buildJornadaPreviewNews(state.currentRound);
      generatePreGameReport(nextRound.find(f=>f.home===state.userTeamId || f.away===state.userTeamId), `${competitionLabel(state.userCompetitionId)} — Jornada ${state.currentRound+1} de ${state.fixtures.length}`, state.userCompetitionId, nextRound.date);
    } else if(minhaSupertaca && sameDay(addDays(state.currentDate,1), minhaSupertaca.date)){
      supertacaBuildPreviewNews(minhaSupertaca);
      generatePreGameReport(minhaSupertaca, "Supertaça António Livramento", null);
    } else if(minhaTaca && sameDay(addDays(state.currentDate,1), minhaTaca.date)){
      tacaBuildPreviewNews(minhaTaca);
      generatePreGameReport(minhaTaca, TACA_FASE_LABEL[state.tacaPortugal.fase], null);
    } else if(preSeasonPreviewForTomorrow()){
      // antevisão do jogo de preparação já publicada
    } else {
      maybeGenerateFlavorNews();
    }
  }

  // Suspensões (cartão vermelho, suspensoJogos) nunca geraram notícia própria — ao contrário de
  // lesões, mercado, direção/carreira e scouting, que já têm todas notícia dedicada (ver os
  // pontos que passam {autoAdvanceStop:true} a pushNews). Em vez de inventar aqui uma notícia só
  // para ter algo a detetar, compara-se diretamente o número de jogos de suspensão de cada
  // jogador teu antes/depois do dia — mais simples e sem risco de duplicar o que o relatório
  // pós-jogo (cartões) já mostra.
  function userSuspensionSnapshot(){
    const team = state.userTeamId ? state.teams[state.userTeamId] : null;
    const map = {};
    (team?team.players:[]).forEach(p=>{ map[p.id] = p.suspensoJogos||0; });
    return map;
  }
  function userSuspensionIncreased(before){
    const team = state.userTeamId ? state.teams[state.userTeamId] : null;
    if(!team) return false;
    return team.players.some(p=>(p.suspensoJogos||0) > (before[p.id]||0));
  }

  // Avanço automático de vários dias (2026-09-16, pedido explícito do utilizador: "não quero ter
  // de carregar no botão todos os dias... deve ser um continuar que tem mais dias, mas que deve
  // parar quando há decisões ou notícias importantes"). Em vez de um único dia por clique, corre
  // até CONTINUAR_AUTO_ADVANCE_MAX_DIAS dias seguidos, parando mais cedo assim que: (a) chega um
  // dia de jogo teu (matchDayReady — o botão muda de texto e uma segunda volta manual abre a
  // convocatória, exatamente como já acontecia com o avanço de 1 dia), (b) entra em defeso, (c)
  // o jogo termina (gameOver), (d) alguma notícia publicada neste dia está marcada como
  // importante (news.autoAdvanceStop — mercado que te diz respeito, lesões, direção/carreira,
  // scouting, sorteios/apuramentos/finais das taças e competições europeias), ou (e) uma
  // suspensão nova a um jogador teu. Decisões (lista fechada e limite de 7 dias) confirmadas
  // explicitamente pelo utilizador nesta conversa.
  const CONTINUAR_AUTO_ADVANCE_MAX_DIAS = 7;
  function runContinuarAutoAdvance(){
    for(let dia=1; dia<=CONTINUAR_AUTO_ADVANCE_MAX_DIAS; dia++){
      const newsAntes = new Set(state.news); // por referência: com a caixa no limite (200) o comprimento já não muda
      const dataAntes = state.currentDate ? state.currentDate.getTime() : null;
      const suspensosAntes = userSuspensionSnapshot();

      advanceOneDayOrPhaseStep();

      // (a)/(b)/(c): estas paragens já são, por si só, o suficiente — não vale a pena continuar
      // a verificar notícias ou suspensões se qualquer uma delas aconteceu. Motor de Eventos
      // Narrativos (2026-09-28): um evento épico/lendário pendente (state.pendingNarrativeEvent,
      // ver 09b-eventos-narrativos.js) pára o avanço automático da mesma forma que um dia de
      // jogo — precisa de uma decisão do utilizador antes de continuar.
      if(state.matchDayReady || state.inDefeso || state.gameOver || state.pendingNarrativeEvent || state.pendingNationalSquadPick) break;

      // (d) notícias novas nascidas hoje: state.news cresce por unshift, por isso ficam sempre
      // nas primeiras posições.
      const novas = state.news.filter(n=>!newsAntes.has(n));
      if(novas.some(n=>n.autoAdvanceStop)) break;

      // (e) suspensão nova
      if(userSuspensionIncreased(suspensosAntes)) break;

      // Rede de segurança: se a data não avançou mesmo (ex.: currentRound já esgotado, guarda
      // defensiva em advanceOneDayOrPhaseStep), não continuar às cegas.
      if(dataAntes!=null && state.currentDate && state.currentDate.getTime()===dataAntes) break;
    }
    updateContinuarBtnLabel();
  }

  // Indicador de "a processar" (2026-09-17, pedido do utilizador: "quando carrego para continuar
  // e ele esta a passar dias, tem de aparecer uma animação... ou mudar o cursor") — avançar até 7
  // dias de uma vez (ou fechar o defeso, ou fechar uma época) pode envolver bastante simulação
  // (mercado, finanças, lesões, competições) e ficava sem qualquer sinal visual de que o jogo
  // estava a trabalhar, parecendo "pendurado" por um instante. cursor:wait no body cobre o pedido
  // mínimo (mudar o cursor); o texto do próprio botão passa também a dizer "A processar…" com um
  // spinner (ver .cm3-busy-spinner, styles.css) enquanto isso acontece. Os dois requestAnimationFrame
  // encadeados garantem que o browser chega a pintar este estado ANTES do trabalho síncrono pesado
  // começar (um único rAF pode ainda cair no mesmo frame de pintura em alguns browsers).
  // Cursor de ampulheta (2026-10-15): window.hm2027Pensar(fn) corre fn() com o cursor de ampulheta (classe
  // cm3-busy + data-ampulheta a rodar 0..12) depois de dois rAF, para o browser pintar antes do trabalho
  // síncrono pesado. Aceita chamadas aninhadas (contador). Usado no arranque de carreira, ao carregar,
  // ao guardar e em withBusyIndicator.
  let _pensarN = 0, _pensarTimer = null, _pensarFrame = 0;
  function pensarInicio(){
    if(_pensarN++ === 0){
      document.body.classList.add("cm3-busy"); _pensarFrame = 0; document.body.dataset.ampulheta = "0";
      _pensarTimer = setInterval(() => { _pensarFrame = (_pensarFrame + 1) % 13; document.body.dataset.ampulheta = String(_pensarFrame); }, 110);
    }
  }
  function pensarFim(){
    if(--_pensarN <= 0){
      _pensarN = 0; clearInterval(_pensarTimer); _pensarTimer = null;
      document.body.classList.remove("cm3-busy"); delete document.body.dataset.ampulheta;
    }
  }
  window.hm2027Pensar = function(fn){
    pensarInicio();
    requestAnimationFrame(() => requestAnimationFrame(() => { try{ fn(); } finally{ pensarFim(); } }));
  };
  window.hm2027PensarInicio = pensarInicio; window.hm2027PensarFim = pensarFim;
  function withBusyIndicator(fn){
    const btn = document.getElementById("continuarBtn");
    const endBtn = document.getElementById("defesoEndBtn");
    pensarInicio();
    if(btn){ btn.disabled = true; btn.dataset.busyLabel = btn.textContent; btn.innerHTML = '<span class="cm3-busy-spinner" aria-hidden="true"></span> A processar…'; }
    if(endBtn) endBtn.disabled = true;
    requestAnimationFrame(() => requestAnimationFrame(() => {
      try{ fn(); try{ if(window.hm2027Autosave) window.hm2027Autosave(); }catch(e){ console.error("[HM2027] autosave:", e); } }
      finally{
        pensarFim();
        if(btn) btn.disabled = false;
        if(endBtn) endBtn.disabled = false;
        updateContinuarBtnLabel();
      }
    }));
  }
  document.getElementById("continuarBtn").addEventListener("click", () => {
    if(state.gameOver){showGameOverModal();return;}
    if(!state.userTeamId) return;
    // Jogo ao vivo já terminado: "Continuar" sai da partida e volta ao menu (sem modal de resumo).
    if(state.pendingPostMatchCtx){ concluirPartidaTerminada(); return; }
    if(state.matchDayReady){
      state.matchDayReady = false;
      updateContinuarBtnLabel();
      openConfirmarConvocatoriaModal();
      document.getElementById("continuarBtn").disabled = true;
      return;
    }
    // Motor de Eventos Narrativos (2026-09-28): mesmo padrão de matchDayReady acima — um evento
    // épico/lendário pendente abre o modal de escolha em vez de avançar dias (ver
    // 09b-eventos-narrativos.js).
    if(state.pendingNarrativeEvent){
      openEventoNarrativoModal();
      return;
    }
    // Seleccionador Nacional — Acumulação de Cargo (2026-10-03): mesmo padrão outra vez — a
    // convocatória manual da selecção do utilizador pendente abre o novo modal em vez de avançar
    // dias (ver prepareSelecoesEdicaoForNewSeason, 07h-selecoes.js).
    if(state.pendingNationalSquadPick){
      openSelecaoConvocatoriaManualModal();
      return;
    }

    // Correção (2026-09-17): "Continuar" já não termina o defeso num único clique — passa a
    // avançar um dia (dailyConditionRecovery inclui agora a resolução do mercado, ver
    // advanceOneDayOrPhaseStep) tal como no resto da época, para as propostas feitas no Mercado
    // terem mesmo oportunidade de ser respondidas enquanto o utilizador ainda está a negociar.
    // Encerrar a janela de mercado é uma ação à parte — #defesoEndBtn, ao lado deste botão.
    withBusyIndicator(() => { runContinuarAutoAdvance(); if(typeof rsVoltarAoResumoSemanal==="function") rsVoltarAoResumoSemanal(); });
  });
  const defesoEndBtn = document.getElementById("defesoEndBtn");
  if(defesoEndBtn) defesoEndBtn.addEventListener("click", () => {
    if(!state.inDefeso) return;
    withBusyIndicator(() => { if(state.isPreSeasonDefeso) finalizePreSeasonDefeso(); else finalizeNewSeason(); });
  });

  document.getElementById("speedSelect").addEventListener("change", (e)=>{
    state.speedMs = parseInt(e.target.value,10);
    if(state.match && !state.match.finished){
      clearInterval(state.timer);
      // Correção: reutiliza exatamente a mesma função de tick do arranque do jogo ao vivo
      // (runLiveMatchTimerTick, 06-motor-jogo.js) — esta cópia própria e mais antiga não tinha a
      // pausa/flash de celebração de golo, que só corria no intervalo original criado em
      // startLiveMatchWithLineup. Mudar de velocidade a meio de um jogo (o mais comum sendo logo
      // no início) substituía esse intervalo por este, e os golos deixavam de pausar/piscar.
      state.timer=setInterval(()=>runLiveMatchTimerTick(state.match), state.speedMs);
    }
  });

  // =================================================================
  // Confirmar Convocatória (pre-match) — 2026-10-03
  // =================================================================
  // Pedido do utilizador: "No plantel deve haver uma coluna antes do nome em que se pode escolher
  // o 5 inicial e os substitutos. Antes de ir para o jogo, ao carregar em continuar, ele pergunta
  // se confirmo a convocatória." A convocatória e o 5 inicial deixaram de se escolher aqui —
  // configuram-se de forma persistente na coluna "Conv." do Plantel
  // (ensureSquadSelectionDefaults/convStatusHtml, 05-ui-navegacao.js — reaproveita tal e qual
  // player.titular e state.convocadosSelecionados, que já existiam, só nunca geridos no mesmo
  // sítio). Este ecrã, ao chegar o dia de jogo, só confirma o que já está escolhido — substitui os
  // antigos #convocatoriaModal + #escalacaoModal.
  const confirmarConvocatoriaModal = document.getElementById("confirmarConvocatoriaModal");

  const CONVOCATORIA_MAX_GR = 2;
  const CONVOCATORIA_MAX_J = 8;

  // Pedido explícito: a convocatória tem de dizer sempre qual o adversário e qual a competição —
  // antes eram genéricas, sem nenhuma pista de contra quem ou em que prova se está a jogar.
  // Reaproveita currentMatchContextLabel (já usado no cabeçalho do jogo ao vivo).
  function matchModalContextText(){
    const fx = state.pendingFixture; if(!fx) return "";
    const isHome = fx.home===state.userTeamId;
    const oppId = isHome ? fx.away : fx.home;
    const opp = state.teams[oppId];
    return `${isHome?"Recebes":"Visitas"} ${opp?opp.name:"?"} — ${currentMatchContextLabel()}`;
  }

  // Lê directamente a configuração já feita no Plantel — nunca escolhe nada por omissão aqui, só
  // corrige indisponibilidades de última hora (ensureSquadSelectionDefaults) — e devolve a squad
  // pronta a usar, mais os erros (bloqueiam o "Confirmar") e o aviso (não bloqueia) a mostrar.
  // Regras pedidas pelo utilizador: é obrigatório ter exactamente 1 GR titular e 4 jogadores de
  // campo titulares para poder avançar; é obrigatório convocar 2 GR (ou menos só quando o plantel
  // genuinamente não tem 2 disponíveis); não é obrigatório convocar mais nenhum jogador de campo
  // além dos 4 titulares, mas se o total ficar abaixo de 10 mostra-se um aviso.
  function convocatoriaAtualResumo(){
    const club = myTeam();
    ensureSquadSelectionDefaults();
    const convocados = club.players.filter(p=>state.convocadosSelecionados[p.id] && playerAvailableForMatch(p));
    const grPlayer = convocados.find(p=>p.pos==="GR" && p.titular) || null;
    const jPlayers = convocados.filter(p=>p.pos==="J" && p.titular);
    const bench = convocados.filter(p=>p!==grPlayer && !jPlayers.includes(p));
    const grConvocados = convocados.filter(p=>p.pos==="GR").length;
    const availableGR = club.players.filter(p=>p.pos==="GR" && playerAvailableForMatch(p)).length;
    const minGR = Math.min(CONVOCATORIA_MAX_GR, availableGR);
    const erros = [];
    if(!grPlayer) erros.push('Falta escolher o guarda-redes titular — ajusta na coluna "Conv." do Plantel.');
    if(jPlayers.length!==4) erros.push(`É preciso escolher exactamente 4 jogadores de campo titulares (tens ${jPlayers.length}) — ajusta no Plantel.`);
    if(grConvocados<minGR) erros.push(`É obrigatório convocar ${minGR} guarda-redes (tens ${grConvocados} convocado${grConvocados===1?'':'s'}) — ajusta no Plantel.`);
    const aviso = convocados.length<10 ? `Vais a jogo com apenas ${convocados.length} convocados — o ideal são 10 (2 guarda-redes + 8 jogadores de campo).` : "";
    return { convocados, grPlayer, jPlayers, bench, erros, aviso };
  }

  function openConfirmarConvocatoriaModal(){
    const ctxEl = document.getElementById("confirmarConvocatoriaContext");
    if(ctxEl) ctxEl.textContent = matchModalContextText();
    renderConfirmarConvocatoriaModal();
    confirmarConvocatoriaModal.classList.remove("hidden");
  }
  function renderConfirmarConvocatoriaModal(){
    const { grPlayer, jPlayers, bench, erros, aviso } = convocatoriaAtualResumo();
    document.getElementById("confirmarConvocatoriaResumo").innerHTML = `
      <div><b>Guarda-redes titular</b><br>${grPlayer ? `${playerNameHtml(grPlayer)} (OVR ${overall(grPlayer)})` : '<span style="color:var(--vermelho);">— por escolher —</span>'}</div>
      <div><b>Titulares de campo (${jPlayers.length}/4)</b><br>${jPlayers.length ? jPlayers.map(p=>playerNameHtml(p)).join(", ") : '<span style="color:var(--vermelho);">— por escolher —</span>'}</div>
      <div><b>Suplentes (${bench.length})</b><br>${bench.length ? bench.map(p=>playerNameHtml(p)).join(", ") : 'Nenhum'}</div>
    `;
    const avisoEl = document.getElementById("confirmarConvocatoriaAviso");
    avisoEl.textContent = aviso;
    avisoEl.classList.toggle("hidden", !aviso);
    document.getElementById("confirmarConvocatoriaErr").innerHTML = erros.map(e=>escapeHtml(e)).join("<br>");
    document.getElementById("confirmarConvocatoriaConfirmBtn").classList.toggle("hidden", erros.length>0);
  }
  // Fecha a confirmação e leva o utilizador diretamente ao Plantel para corrigir a convocatória —
  // desfaz o clique em "Continuar" que abriu este ecrã (mesmo padrão de state.matchDayReady já
  // usado no resto do jogo) para que, ao corrigir e voltar a carregar em "Continuar", esta mesma
  // confirmação reabra com os dados já actualizados.
  document.getElementById("confirmarConvocatoriaPlantelBtn").addEventListener("click", () => {
    confirmarConvocatoriaModal.classList.add("hidden");
    state.matchDayReady = true;
    document.getElementById("continuarBtn").disabled = false;
    updateContinuarBtnLabel();
    setView("plantel");
  });
  let pendingMatchSetup = null;
  document.getElementById("confirmarConvocatoriaConfirmBtn").addEventListener("click", () => {
    const { convocados, grPlayer, jPlayers, bench, erros } = convocatoriaAtualResumo();
    if(erros.length){ renderConfirmarConvocatoriaModal(); return; } // defensivo — o botão já fica escondido nestes casos
    state.convocados = convocados;
    confirmarConvocatoriaModal.classList.add("hidden");
    pendingMatchSetup = { grPlayer, jPlayers, bench };
    document.getElementById("watchOrSimModal").classList.remove("hidden");
  });

  // =================================================================
  // Convocatória manual da Selecção Nacional (Seleccionador — Acumulação de Cargo, 2026-10-03)
  // =================================================================
  // Mesmo padrão visual/estrutural da convocatória do clube acima (.conv-row, contador 2/8),
  // mas a pool é playersForNationCode(code) (qualquer jogador real dessa nacionalidade, em
  // qualquer clube — 07h-selecoes.js) em vez do plantel do utilizador, e confirmar com menos de
  // 2+8 jogadores reais é permitido: confirmManualSelecaoSquad preenche o que faltar com
  // makeSelecaoFillerPlayer, exactamente a mesma regra do algoritmo automático
  // (pickNationalSquad). As selecções escolhidas ficam guardadas em
  // state.pendingNationalSquadPick.selecionados, para sobreviverem a um fecho/reabertura do
  // modal (incl. um ciclo de save/load a meio da escolha — ver 11-guardar-carregar.js).
  const SELECAO_MANUAL_MAX_GR = 2;
  const SELECAO_MANUAL_MAX_J = 8;
  function openSelecaoConvocatoriaManualModal(){
    const pending = state.pendingNationalSquadPick;
    if(!pending) return;
    const nation = (typeof SELECAO_NATIONS!=="undefined") ? SELECAO_NATIONS[pending.code] : null;
    if(!pending.selecionados || typeof pending.selecionados!=="object"){
      // Pré-selecção sugerida (os melhores por nationalSquadScore) só para o utilizador não partir
      // de uma lista vazia — fica livre para mudar tudo antes de confirmar.
      const pool = playersForNationCode(pending.code);
      const grs = pool.filter(p=>p.pos==="GR").sort((a,b)=>nationalSquadScore(b)-nationalSquadScore(a)).slice(0,SELECAO_MANUAL_MAX_GR).map(p=>p.id);
      const js = pool.filter(p=>p.pos!=="GR").sort((a,b)=>nationalSquadScore(b)-nationalSquadScore(a)).slice(0,SELECAO_MANUAL_MAX_J).map(p=>p.id);
      pending.selecionados = {};
      [...grs, ...js].forEach(id=>{ pending.selecionados[id] = true; });
    }
    const tituloEl = document.getElementById("selecaoConvocatoriaManualTitulo");
    if(tituloEl) tituloEl.textContent = nation ? nation.nome : pending.code;
    renderSelecaoConvocatoriaManualList();
    document.getElementById("selecaoConvocatoriaManualModal").classList.remove("hidden");
  }
  function renderSelecaoConvocatoriaManualList(){
    const pending = state.pendingNationalSquadPick;
    if(!pending) return;
    const pool = playersForNationCode(pending.code).slice().sort((a,b)=>playerPositionSortKey(a)-playerPositionSortKey(b));
    const list = document.getElementById("selecaoConvocatoriaManualList");
    if(!pool.length){
      list.innerHTML = '<div style="font-size:12px;color:var(--texto-mute);padding:8px;">Não há jogadores reais desta nacionalidade no universo do jogo — a convocatória será composta por jogadores fictícios.</div>';
      const counterElVazio = document.getElementById("selecaoConvocatoriaManualCounter");
      if(counterElVazio) counterElVazio.textContent = `0/${SELECAO_MANUAL_MAX_GR} guarda-redes · 0/${SELECAO_MANUAL_MAX_J} jogadores de campo`;
      return;
    }
    const checkedGR = pool.filter(p=>p.pos==="GR" && pending.selecionados[p.id]).length;
    const checkedJ = pool.filter(p=>p.pos!=="GR" && pending.selecionados[p.id]).length;
    list.innerHTML = pool.map(p => {
      const checked = !!pending.selecionados[p.id];
      const capReached = p.pos==="GR" ? checkedGR>=SELECAO_MANUAL_MAX_GR : checkedJ>=SELECAO_MANUAL_MAX_J;
      const disabled = capReached && !checked;
      const teamId = teamIdForRealPlayer(p.id);
      const clube = teamId && state.teams[teamId] ? state.teams[teamId].name : "";
      return `<div class="conv-row ${disabled?'disabled':''}">
        <label><input type="checkbox" data-id="${p.id}" data-pos="${p.pos}" ${checked?'checked':''} ${disabled?'disabled':''}>
        <span class="pos-badge ${p.pos==='GR'?'gr':'j'}">${linhaAbbrev(p)}</span> ${playerNameHtml(p)}</label>
        <span class="ovr-mini">OVR ${overall(p)}${clube?` · ${escapeHtml(clube)}`:""}</span>
      </div>`;
    }).join("");
    list.querySelectorAll('input[type=checkbox]').forEach(cb=>{
      cb.addEventListener("change", () => {
        pending.selecionados[cb.getAttribute("data-id")] = cb.checked;
        renderSelecaoConvocatoriaManualList();
      });
    });
    const counterEl = document.getElementById("selecaoConvocatoriaManualCounter");
    if(counterEl) counterEl.textContent = `${checkedGR}/${SELECAO_MANUAL_MAX_GR} guarda-redes · ${checkedJ}/${SELECAO_MANUAL_MAX_J} jogadores de campo`;
  }
  const selecaoConvocatoriaManualConfirmBtn = document.getElementById("selecaoConvocatoriaManualConfirmBtn");
  if(selecaoConvocatoriaManualConfirmBtn) selecaoConvocatoriaManualConfirmBtn.addEventListener("click", () => {
    const pending = state.pendingNationalSquadPick;
    if(!pending) return;
    const selectedIds = Object.keys(pending.selecionados||{}).filter(id=>pending.selecionados[id]);
    confirmManualSelecaoSquad(selectedIds);
    const modalEl = document.getElementById("selecaoConvocatoriaManualModal");
    if(modalEl) modalEl.classList.add("hidden");
    updateContinuarBtnLabel();
  });

  // Prémios de fim de época (2026-09-21): resolve o id real da competição do jogo pendente do
  // utilizador, para o motor deixar de registar TODOS os jogos como se fossem da competição
  // principal do utilizador. Mesma ordem de prioridade já usada em finalizeMatchBookkeeping
  // (06-motor-jogo.js) para decidir a que prova pertence o jogo que acabou de terminar.
  function resolvePendingFixtureCompetitionId(){
    if(state.pendingPromotionTieGameIndex!=null) return "liguilha-promocao";
    if(state.pendingPlataTieGameIndex!=null) return "liguilha-plata";
    if(state.pendingSecondDivisionFinalGameIndex!=null) return "final-2div";
    if(state.pendingAmigavel) return "amistoso";
    if(state.pendingSupertaca) return "supertaca";
    if(state.pendingEliteCupFase!=null) return "elite-cup";
    if(state.pendingTacaPortugalFase!=null) return "taca-portugal";
    if(state.pendingCopaDelReyFase!=null) return "copa-del-rey";
    if(state.pendingCoppaItaliaFase!=null) return "coppa-italia";
    if(state.pendingCopaPrincesaFase!=null) return "copa-princesa";
    if(state.pendingSupercopaEspanaFase!=null) return "supercopa-espana";
    if(state.pendingSupercoppaItalianaLeg) return "supercoppa-italiana";
    if(state.pendingEuropaSlot){
      const slot = state.pendingEuropaSlot;
      return (slot.tipo==="grupo" ? slot.grupoId : slot.bracketId) || null;
    }
    if(state.pendingPlayoffSeries) return state.pendingPlayoffSeries.competitionId || null;
    return competitionIdForTeam(state.userTeamId) || state.userCompetitionId || null;
  }

  // Correção (análise de código, 2026-10-16): os jogos do utilizador na Copa del Rey, Coppa Italia
  // e Supercopa de España são eliminatórias a uma mão, mas não forçavam prolongamento/penáltis —
  // um empate deixava a eliminatória sem vencedor e a prova (e o fecho da época) bloqueada.
  function pendingNationalCupKnockout(){
    return state.pendingCopaDelReyFase!=null || state.pendingCoppaItaliaFase!=null || state.pendingCopaPrincesaFase!=null || state.pendingSupercopaEspanaFase!=null;
  }
  function pendingNationalCupNeutral(){
    if(state.pendingSupercopaEspanaFase!=null) return true;
    if(state.pendingCopaDelReyFase!=null) return nationalCupIsNeutral(NATIONAL_CUP_CONFIG["copa-del-rey"], state.pendingCopaDelReyFase);
    if(state.pendingCoppaItaliaFase!=null) return nationalCupIsNeutral(NATIONAL_CUP_CONFIG["coppa-italia"], state.pendingCoppaItaliaFase);
    if(state.pendingCopaPrincesaFase!=null) return nationalCupIsNeutral(NATIONAL_CUP_CONFIG["copa-princesa"], state.pendingCopaPrincesaFase);
    return false;
  }
  document.getElementById("watchMatchBtn").addEventListener("click", () => {
    if(state.gameOver){showGameOverModal();return;}
    document.getElementById("watchOrSimModal").classList.add("hidden");
    const { grPlayer, jPlayers, bench } = pendingMatchSetup;
    const fixture = state.pendingFixture;
    setView("jogo");
    document.getElementById("matchStatus").textContent = "Ao vivo";
    startLiveMatchWithLineup(fixture.home, fixture.away, grPlayer, jPlayers, bench, !!state.pendingPlayoffSeries || state.pendingTacaPortugalFase!=null || state.pendingSupertaca || state.pendingEliteCupFase!=null || europaPendingIsPlayoff() || pendingNationalCupKnockout(), isTacaFinalFourFase(state.pendingTacaPortugalFase) || !!state.pendingSupertaca || state.pendingEliteCupFase!=null || europaPendingIsNeutral() || pendingNationalCupNeutral(), resolvePendingFixtureCompetitionId());
    pendingMatchSetup = null;
  });

  // Simular usa exatamente o mesmo motor (newLiveMatchState + runMatchTicks) do jogo ao vivo —
  // a única diferença é que corre instantaneamente em segundo plano, com a IA a gerir também
  // o lado do utilizador (fadiga, lesões, cartões, substituições, tudo com as mesmas regras).
  document.getElementById("simMatchBtn").addEventListener("click", () => {
    if(state.gameOver){showGameOverModal();return;}
    document.getElementById("watchOrSimModal").classList.add("hidden");
    const { grPlayer, jPlayers, bench } = pendingMatchSetup;
    const fixture = state.pendingFixture;
    const ctx = newLiveMatchState(fixture.home, fixture.away, grPlayer, jPlayers, bench, !!state.pendingPlayoffSeries || state.pendingTacaPortugalFase!=null || state.pendingSupertaca || state.pendingEliteCupFase!=null || europaPendingIsPlayoff() || pendingNationalCupKnockout(), isTacaFinalFourFase(state.pendingTacaPortugalFase) || !!state.pendingSupertaca || state.pendingEliteCupFase!=null || europaPendingIsNeutral() || pendingNationalCupNeutral(), !!state.pendingEuropaSlot, resolvePendingFixtureCompetitionId());
    ctx.simulating = true;
    // Na simulação rápida o assistente pode ajustar a tática do utilizador durante o jogo, mas
    // essa mudança não fica: o sistema, a defesa, a transição, a mentalidade e a pressão que o
    // utilizador escolheu voltam no fim (o ajuste só serve para este jogo).
    const _meuT = state.teams[state.userTeamId];
    const _tacAntes = _meuT ? { sistema:_meuT.sistema, defesa:_meuT.defesa, transicao:_meuT.transicao, mentalidade:_meuT.mentalidade, pressao:_meuT.pressao } : null;
    let guard = 0;
    while(!ctx.finished && guard < 3000){
      runMatchTicks(ctx);
      if(ctx.paused){
        if(ctx.injury){ autoSubAI(ctx, ctx.injury.side, ctx.injury.player); }
        ctx.paused = false; ctx.injury = null; ctx.pendingReturnPrompt = null;
      }
      guard++;
    }
    if(_meuT && _tacAntes) Object.keys(_tacAntes).forEach(k=>{ if(_tacAntes[k]!==undefined) _meuT[k] = _tacAntes[k]; });
    state.match = ctx;
    pendingMatchSetup = null;
    onLiveMatchFinished(ctx);
  });

  // =================================================================
