
// =====================================================================================================
// Ecrã e definições (2026-10-12). Módulo autónomo (só mexe no DOM e na janela, não no estado do jogo).
//  1. Definições: ecrã com idioma (por agora só Português), ecrã inteiro e tamanho da interface.
//  2. Escala automática: na versão desktop (Tauri) aplica um zoom ao webview para que a área útil do jogo
//     tenha sempre um tamanho calibrado (por omissão ≥ 1920×1080 "pixéis do jogo", com um piso para o
//     texto não ficar minúsculo em ecrãs pequenos), qualquer que seja a resolução e o DPI do ecrã.
//  3. Sub-separadores automáticos nas vistas longas (Direção, Táticas, Finanças) para o conteúdo caber
//     sem scroll de página: cada secção (cabeçalho .eyebrow + conteúdo) vai para o separador certo.
// =====================================================================================================
(function(){
  const T = window.__TAURI__ || null;
  const CHAVE = "hm2027_ecra";

  // ------------------------------------------------------------------ preferências
  // ref = tamanho de referência (em píxeis CSS) que a área útil deve ter pelo menos; zMin = piso do zoom.
  const ESCALAS = {
    "compacto":     { label: "Compacto",     refW: 2133, refH: 1200, zMin: 0.70 },
    "normal":       { label: "Normal",       refW: 1920, refH: 1080, zMin: 0.85 },
    "grande":       { label: "Grande",       refW: 1680, refH: 945,  zMin: 0.95 },
    "muito-grande": { label: "Muito grande", refW: 1440, refH: 810,  zMin: 1.00 }
  };
  const Z_MAX = 3;
  let cfg = { escala: "normal", ecraInteiro: null };   // ecraInteiro null = ainda não escolhido (desktop: ligado)
  try{ const s = JSON.parse(localStorage.getItem(CHAVE) || "null"); if(s && typeof s === "object") cfg = Object.assign(cfg, s); }catch(e){}
  if(!ESCALAS[cfg.escala]) cfg.escala = "normal";
  function guardarCfg(){ try{ localStorage.setItem(CHAVE, JSON.stringify(cfg)); }catch(e){} }

  // Zoom calculado a partir do tamanho "base" da janela (em píxeis CSS com zoom 1).
  function calcularZoom(baseW, baseH, chaveEscala){
    const e = ESCALAS[chaveEscala] || ESCALAS.normal;
    if(!(baseW > 0) || !(baseH > 0)) return 1;
    const z = Math.min(baseW / e.refW, baseH / e.refH);
    return Math.round(Math.min(Z_MAX, Math.max(e.zMin, z)) * 100) / 100;
  }

  // ------------------------------------------------------------------ zoom (só na aplicação desktop)
  const temZoom = !!(T && T.webview && T.webview.getCurrentWebview);
  let zAtual = 1, zTimer = null;
  function aplicarEscala(){
    if(!temZoom) { atualizarInfo(); return; }
    const baseW = window.innerWidth * zAtual, baseH = window.innerHeight * zAtual;
    const z = calcularZoom(baseW, baseH, cfg.escala);
    if(Math.abs(z - zAtual) >= 0.01){
      zAtual = z;     // antes da chamada: o "resize" que o zoom provoca já deve ver o valor novo
      try{ Promise.resolve(T.webview.getCurrentWebview().setZoom(z)).catch(e => console.warn("[HM2027] zoom:", e)); }catch(e){ console.warn("[HM2027] zoom:", e); }
    }
    atualizarInfo();
  }
  window.addEventListener("resize", () => { clearTimeout(zTimer); zTimer = setTimeout(aplicarEscala, 120); });

  // ------------------------------------------------------------------ ecrã inteiro
  function janela(){ return T && T.window && T.window.getCurrentWindow ? T.window.getCurrentWindow() : null; }
  async function estaEmEcraInteiro(){
    const w = janela();
    if(w) { try{ return await w.isFullscreen(); }catch(e){ return false; } }
    return !!document.fullscreenElement;
  }
  async function definirEcraInteiro(on){
    const w = janela();
    try{
      if(w) await w.setFullscreen(!!on);
      else if(on && document.documentElement.requestFullscreen) await document.documentElement.requestFullscreen();
      else if(!on && document.fullscreenElement && document.exitFullscreen) await document.exitFullscreen();
    }catch(e){ console.warn("[HM2027] ecrã inteiro:", e); }
    cfg.ecraInteiro = !!on; guardarCfg(); atualizarInfo();
  }
  async function alternarEcraInteiro(){ await definirEcraInteiro(!(await estaEmEcraInteiro())); }
  document.addEventListener("keydown", (e) => {
    if(e.key !== "F11" || !T) return;      // no browser o F11 já é nativo
    e.preventDefault(); alternarEcraInteiro();
  });
  document.addEventListener("fullscreenchange", () => atualizarInfo());

  // ------------------------------------------------------------------ ecrã de Definições
  const $ = (id) => document.getElementById(id);
  function atualizarInfo(){
    const ov = $("settingsOverlay"); if(!ov) return;
    ov.querySelectorAll("[data-escala]").forEach(b => b.classList.toggle("active", b.getAttribute("data-escala") === cfg.escala));
    const baseW = Math.round(window.innerWidth * zAtual), baseH = Math.round(window.innerHeight * zAtual);
    const info = $("setEscalaInfo");
    if(info){
      info.textContent = temZoom
        ? `Janela: ${baseW}×${baseH} · ampliação aplicada: ${Math.round(zAtual * 100)}% · área do jogo: ${window.innerWidth}×${window.innerHeight}. Ajusta-se sozinha a qualquer resolução; muda o tamanho se preferires letras maiores ou mais conteúdo no ecrã.`
        : `No browser o tamanho ajusta-se com Ctrl + / Ctrl − (a ampliação automática só existe na aplicação de desktop). Área do jogo: ${window.innerWidth}×${window.innerHeight}.`;
    }
    ov.querySelectorAll("[data-escala]").forEach(b => { b.disabled = !temZoom; b.style.opacity = temZoom ? "" : "0.5"; });
    estaEmEcraInteiro().then(on => { const c = $("setEcraInteiro"); if(c) c.checked = !!on; });
  }
  function abrirDefinicoes(){
    const ov = $("settingsOverlay"); if(!ov) return;
    const fn = document.querySelector(".footer-note"), sobre = $("setSobre");
    if(fn && sobre) sobre.innerHTML = fn.innerHTML;
    ov.classList.remove("hidden"); atualizarInfo();
  }
  function fecharDefinicoes(){ const ov = $("settingsOverlay"); if(ov) ov.classList.add("hidden"); }
  ["menuSettingsBtn", "settingsBtn"].forEach(id => { const b = $(id); if(b) b.addEventListener("click", abrirDefinicoes); });
  if($("settingsCloseBtn")) $("settingsCloseBtn").addEventListener("click", fecharDefinicoes);
  if($("setEcraInteiro")) $("setEcraInteiro").addEventListener("change", (e) => definirEcraInteiro(e.target.checked));
  if($("settingsOverlay")){
    $("settingsOverlay").addEventListener("click", (e) => {
      if(e.target === $("settingsOverlay")) fecharDefinicoes();
      const b = e.target.closest ? e.target.closest("[data-escala]") : null;
      if(b && !b.disabled){ cfg.escala = b.getAttribute("data-escala"); guardarCfg(); aplicarEscala(); }
    });
    document.addEventListener("keydown", (e) => { if(e.key === "Escape" && !$("settingsOverlay").classList.contains("hidden")) fecharDefinicoes(); });
  }

  // ------------------------------------------------------------------ sub-separadores automáticos
  // inicio: seletor dos filhos diretos que abrem uma nova secção; cada separador apanha as secções cujo
  // texto de abertura (cabeçalho .eyebrow, ou o id) corresponde a re. Secções sem correspondência vão para o 1.º.
  const SEPARADORES = {
    direcao: { alvo: "#directionContent", inicio: ".eyebrow", tabs: [
      { id: "direcao",     label: "Direção",                 re: /saúde|confiança|objetivos|orçamento anual|avaliação anual/i },
      { id: "pavilhao",    label: "Pavilhão e preços",       re: /pavilh|preços|precos/i },
      { id: "patrocinios", label: "Patrocínios",             re: /patroc/i },
      { id: "disciplina",  label: "Disciplina e arbitragem", re: /disciplina|arbitrag/i },
      { id: "satelite",    label: "Satélite e investimentos", re: /satélite|satelite|investimento/i }
    ]},
    taticas: { alvo: "#taticasContent", inicio: ".eyebrow", tabs: [
      { id: "sistema",  label: "Sistema",                re: /^tacpista|^sistema/i },
      { id: "detalhes", label: "Detalhes táticos",       re: /mentalidade|pressão|pressao|defesa|transição|transicao/i },
      { id: "clube",    label: "Clube e treino",         re: /identidade|familiaridade|treino/i },
      { id: "marcadores", label: "Marcadores",            re: /marcadores/i }
    ]},
    financas: { alvo: "#viewFinancas .panel-body", inicio: ".eyebrow, #financeSummary, #financeBudget", tabs: [
      { id: "resumo",     label: "Resumo e projeção",       re: /financesummary|projeção|projecao/i },
      { id: "orcamento",  label: "Orçamento e simulador",   re: /financebudget/i },
      { id: "plantel",    label: "Custos do plantel",       re: /custos do plantel/i },
      { id: "movimentos", label: "Movimentos recentes",     re: /movimentos/i }
    ]}
  };
  const separadorAtivo = {};
  function textoChave(el){
    if(el.classList.contains("eyebrow")) return (el.textContent || "").toLowerCase();
    return (el.id || "").toLowerCase();
  }
  function organizar(chave, cfgv, alvo){
    if(!alvo || alvo.querySelector(":scope > .subtabs-bar")) return;
    const filhos = Array.from(alvo.children);
    if(!filhos.length) return;
    const segmentos = []; let atual = null;
    filhos.forEach(f => {
      if(f.matches(cfgv.inicio) || !atual){ atual = { chave: textoChave(f), nos: [] }; segmentos.push(atual); }
      atual.nos.push(f);
    });
    const porTab = {}; cfgv.tabs.forEach(t => porTab[t.id] = []);
    segmentos.forEach(s => {
      const t = cfgv.tabs.find(t => t.re.test(s.chave)) || cfgv.tabs[0];
      porTab[t.id].push(...s.nos);
    });
    const usados = cfgv.tabs.filter(t => porTab[t.id].length);
    if(usados.length < 2) return;
    let ativo = separadorAtivo[chave];
    if(!usados.some(t => t.id === ativo)) ativo = usados[0].id;
    separadorAtivo[chave] = ativo;
    const barra = document.createElement("div");
    barra.className = "subtabs-bar";
    barra.innerHTML = usados.map(t => `<button class="tactic-btn${t.id === ativo ? " active" : ""}" data-subtab="${t.id}">${t.label}</button>`).join("");
    const paineis = usados.map(t => {
      const p = document.createElement("div");
      p.className = "subtab-pane" + (t.id === ativo ? " active" : "");
      p.setAttribute("data-pane", t.id);
      porTab[t.id].forEach(n => p.appendChild(n));
      return p;
    });
    alvo.appendChild(barra); paineis.forEach(p => alvo.appendChild(p));
    barra.addEventListener("click", (e) => {
      const b = e.target.closest ? e.target.closest("[data-subtab]") : null; if(!b) return;
      const id = b.getAttribute("data-subtab"); separadorAtivo[chave] = id;
      barra.querySelectorAll("[data-subtab]").forEach(x => x.classList.toggle("active", x === b));
      alvo.querySelectorAll(":scope > .subtab-pane").forEach(p => p.classList.toggle("active", p.getAttribute("data-pane") === id));
    });
  }
  Object.keys(SEPARADORES).forEach(chave => {
    const c = SEPARADORES[chave], alvo = document.querySelector(c.alvo);
    if(!alvo) return;
    const obs = new MutationObserver(() => organizar(chave, c, alvo));
    obs.observe(alvo, { childList: true });
    organizar(chave, c, alvo);
  });

  // ------------------------------------------------------------------ arranque
  window.hm2027Ecra = { calcularZoom, aplicarEscala, alternarEcraInteiro, abrirDefinicoes, fecharDefinicoes, config: () => cfg, ESCALAS };
  if(T){
    // Desktop: por omissão o jogo abre em ecrã inteiro (a menos que o utilizador tenha escolhido o contrário).
    if(cfg.ecraInteiro === false) definirEcraInteiro(false); else if(cfg.ecraInteiro === null){ cfg.ecraInteiro = true; guardarCfg(); }
    aplicarEscala();
  }
})();
