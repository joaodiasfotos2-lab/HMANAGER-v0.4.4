  // ============================= 07e-copas-nacionais.js =============================
  // Copa del Rey (Espanha) e Coppa Italia — "Final a Oito"/quartos+Final Four disputados a meio
  // da época, apurados pelos 8 primeiros classificados da 1ª volta da OK Liga/Serie A1 (jornada
  // 13 de 26 — ambas as ligas têm 14 clubes, por isso a metade é sempre a mesma). Motor único,
  // parametrizado por país (NATIONAL_CUP_CONFIG), pelo mesmo princípio já usado no playoff
  // (PLAYOFF_DIVISION_CONFIG, 07-playoff.js): a Copa del Rey é sempre em campo neutro, em TODAS
  // as fases (regulamento real da RFEP — Final a Oito, um só recinto, 4 dias); a Coppa Italia tem
  // os quartos em casa do melhor classificado (regulamento real da FISR/Lega Nazionale Hockey —
  // não é campo neutro) e só a Final Four (meias-finais + final, um só recinto) é neutra.
  //
  // Datas: por simplicidade (mesmo princípio já usado na Elite Cup — todas as eliminatórias de
  // uma fase partilham uma única data, mesmo havendo várias em simultâneo), cada fase tem uma
  // única data-alvo, calculada a partir da época (mesmo padrão de tacaTargetDateForFase/
  // eliteCupFaseDates). Como a final de ambas as provas cai sempre a um domingo (para respeitar a
  // janela real de cada uma) e a liga joga sempre a domingo, essa data é protegida com
  // avoidLeagueCollisionsOnDate — a mesma lógica já usada para o Final Four da Taça de Portugal
  // (avoidFinalFourCollisions, 07b-taca-portugal.js), generalizada aqui para qualquer data única.
  //
  // Estudo/fontes reais: claude/HM2027_Estudo_TacasEspanhaItalia_2026-09-12.md.
  // =================================================================
  const NATIONAL_CUP_CONFIG = {
    "copa-del-rey": {
      label: "Copa del Rey", stateField: "copaDelRey",
      leagueCompetitionId: "ok-liga-2026-27",
      pendingFaseField: "pendingCopaDelReyFase", pendingIndexField: "pendingCopaDelReyIndex",
      neutralQuartos: true,
    },
    "coppa-italia": {
      label: "Coppa Italia", stateField: "coppaItalia",
      leagueCompetitionId: "serie-a1-2026-27",
      pendingFaseField: "pendingCoppaItaliaFase", pendingIndexField: "pendingCoppaItaliaIndex",
      neutralQuartos: false,
    },
    // Copa de S.A.R. La Princesa — copa da OK Liga Plata (RFEP): Final Four de 4 equipas, um só
    // recinto, sábado e domingo de março (13-14 de março de 2027, Bases 2026-27). Apuramento (edição
    // 2026): 1.º de cada grupo à 1.ª volta, melhor 2.º, e o clube organizador (da Plata). Formato dos
    // jogos não detalhado nas Bases — assume-se meias-finais no sábado e final no domingo.
    "copa-princesa": {
      label: "Copa de la Princesa", stateField: "copaPrincesa",
      leagueCompetitionId: null,
      pendingFaseField: "pendingCopaPrincesaFase", pendingIndexField: "pendingCopaPrincesaIndex",
      neutralQuartos: true, soPlata: true,
      prizes: { winner: 3000, runnerUp: 1500, semifinalist: 600 }, prestigeWinner: 0.4,
    },
  };
  const NATIONAL_CUP_PRIZE_WINNER = 15000;
  const NATIONAL_CUP_PRIZE_RUNNERUP = 7000;
  const NATIONAL_CUP_PRIZE_SEMIFINALIST = 2500;
  const NATIONAL_CUP_PRESTIGE_WINNER = 0.8;
  const NATIONAL_CUP_FASE_LABEL = { quartos: "1/4 de Final", semifinal: "Meia-Final", final: "Final" };

  // Datas-alvo real (edição 2026): Copa del Rey 19-22 de março (Final a Oito); Coppa Italia,
  // quartos a meados de fevereiro (2 jornadas reais comprimidas numa só data, ver nota acima) e
  // Final Four no início de março.
  function nationalCupTargetDates(cupId, season){
    const y = 2026 + (season - 1);
    if(cupId==="copa-princesa"){
      const sat = nextWeekday(new Date(y+1,2,13), 6); // sábado a partir de 13 de março (2027: 13 e 14)
      return { semifinal: new Date(sat), final: addDays(sat,1) };
    }
    if(cupId==="copa-del-rey"){
      const thu = nextWeekday(new Date(y+1,2,19), 4); // quinta-feira, meados de março
      return { quartos: new Date(thu), semifinal: addDays(thu,2), final: addDays(thu,3) }; // qui/sáb/dom
    }
    const quartos = nextWeekday(new Date(y+1,1,11), 3); // quarta-feira, meados de fevereiro
    const semifinal = nextWeekday(new Date(y+1,2,7), 6); // sábado, início de março
    return { quartos: new Date(quartos), semifinal: new Date(semifinal), final: addDays(semifinal,1) };
  }
  // Salvaguarda: se a 1ª volta da OK Liga/Serie A1 só terminar depois da data-alvo real (ex.:
  // calendário muito comprimido por pausas), agenda a partir de hoje com a mesma folga relativa
  // já usada pelo playoff (addDays(state.currentDate,4), ver startPlayoffs) em vez de arriscar
  // uma data já passada.
  function nationalCupSafeDates(cupId, season){
    const target = nationalCupTargetDates(cupId, season);
    if(cupId==="copa-princesa"){
      if(state.currentDate && target.semifinal.getTime() <= state.currentDate.getTime()){
        const semifinal = addDays(state.currentDate, 4);
        return { semifinal, final: addDays(semifinal,1) };
      }
      return target;
    }
    if(state.currentDate && target.quartos.getTime() <= state.currentDate.getTime()){
      const quartos = addDays(state.currentDate, 4);
      return { quartos, semifinal: addDays(quartos,2), final: addDays(quartos,3) };
    }
    return target;
  }
  // Generalização de avoidFinalFourCollisions (07b-taca-portugal.js): reagenda qualquer jornada
  // de qualquer competição que caia exatamente numa data protegida, avançando-a para a terça-
  // feira seguinte (evita tanto o domingo, dia fixo da liga, como o resto da semana já ocupado
  // por outras provas). Usada aqui para a final de cada copa (a única fase que pode calhar a um
  // domingo); as restantes fases caem sempre em dias úteis, nunca usados pela liga.
  //
  // Correção (verificação pedida pelo utilizador: "confirma que não há jogos das várias
  // competições dos vários países agendados para o mesmo dia"): esta função só verificava
  // colisões com as LIGAS domésticas (state.competitions) — nunca com as outras provas de
  // eliminação direta (Taça de Portugal, Copa del Rey, Coppa Italia, Elite Cup, Supertaça,
  // Supercopa de España, Supercoppa Italiana, competições europeias). Isso permitia, na prática,
  // que duas provas diferentes atribuíssem a mesma data ao MESMO clube sem que nenhuma das duas
  // alguma vez soubesse da outra — confirmado com um clube (Oeiras) escalado ao mesmo tempo para
  // os 32 avos da Taça de Portugal e os quartos-de-final da WSE Trophy, no mesmo dia. A partir de
  // agora, percorre-se genericamente TODA a árvore de estado à procura de qualquer "jogo"
  // (objeto com home/away/date, em qualquer prova) que caia exatamente na data protegida — em
  // vez de replicar à mão a forma exata de cada ficheiro 07*.js (o que deixaria sempre alguma
  // prova nova, ou uma já existente, por cobrir por engano).
  // `exclude` (opcional): Set com os próprios objetos "jogo"/"mão" que estão a ser protegidos
  // nesta chamada — necessário porque algumas provas (as eliminatórias europeias, via
  // europaMakeTie/europaAssignTiesCollisionCheck) já guardam a data no próprio objeto ANTES de
  // pedir a verificação de colisão (ao contrário da Taça/copas nacionais/Supertaça/Supercopas,
  // reordenadas para verificar primeiro e só depois atribuir a data). Sem esta exclusão, o
  // percurso genérico por state.europa encontrava o PRÓPRIO jogo que estava a proteger — já
  // sentado exatamente na data pedida — e reagendava-o para longe de si mesmo por engano (falsa
  // colisão consigo próprio, confirmada num caso real: um jogo da WSE Cup a ser empurrado para
  // uma data ainda mais cedo ocupada pela Taça de Portugal, só porque a verificação corria depois
  // de a data já estar atribuída).
  // Correção (2026-09-16, bug real reportado pelo utilizador: "muitos jogos nao aconteceram por
  // estarem no mesmo dia" — confirmado com um teste dedicado de época completa: várias jornadas do
  // Campeonato Placard do próprio clube do utilizador ficavam PARA SEMPRE por jogar, porque duas
  // jornadas diferentes acabavam com a EXATA mesma data). Causa raiz encontrada através do rasto de
  // notícias "foi reagendada para" — a mesma jornada aparecia reagendada 7 VEZES SEGUIDAS, sempre
  // +2 dias: 22/11→24/11→26/11→...→06/12. A recursão desta função (mais abaixo, "reagendamento em
  // cadeia") verifica sempre a NOVA data depois de reagendar algo — mas nunca excluía dessa
  // verificação seguinte a própria jornada que ACABADA de ser colocada lá por ELA PRÓPRIA: a
  // jornada aparecia "sentada" exatamente na nova data a verificar, e era confundida com uma
  // colisão nova, sendo reagendada outra vez, indefinidamente, até ao limite de profundidade (8
  // saltos = 14 dias com o passo de 2 em 2) — 14 dias é exatamente 2 intervalos semanais entre
  // jornadas do Placard, por isso a jornada deslocada ia region ATERRAR exatamente em cima da data
  // original de OUTRA jornada mais à frente no calendário, criando a duplicação real. `justShifted`
  // guarda o que foi reagendado NESTA passagem, e é somado a `exclude` na chamada recursiva — a
  // verificação da nova data passa a ignorar as próprias jornadas que acabaram de ser colocadas
  // ali, só continuando a cascata se algo GENUINAMENTE OUTRO já lá estivesse.
  // Ponto 3.3 da auditoria externa: até aqui, esta função protegia uma DATA inteira — qualquer
  // jornada/jogo de QUALQUER competição a cair no mesmo dia era reagendado, mesmo que não
  // envolvesse nenhum dos clubes do evento que estava a ser protegido (ex.: a final da Taça
  // reagendava sem necessidade uma jornada da 3.ª Divisão Sul entre clubes que nunca poderiam
  // colidir de facto, porque nenhum deles joga a Taça). O problema real é sempre a
  // DISPONIBILIDADE DE UM CLUBE — só interessa saber se algum clube que vai jogar o evento a
  // proteger já tem outro jogo marcado nesse dia. `involvedTeamIds` (opcional, array/Set de IDs
  // de clube) restringe a verificação a essa disponibilidade real: só reagenda uma jornada/jogo
  // que PARTILHE pelo menos um clube com o evento protegido. Quando omitido (ficam por omissão
  // os chamadores que ainda não conhecem os clubes participantes no momento da chamada — ex.:
  // avoidFinalFourCollisions e a proteção antecipada da final da Copa del Rey/Coppa Italia, feita
  // antes de qualquer eliminatória ser jogada), mantém-se o comportamento anterior (protege a
  // data inteira), por segurança — nunca corre o risco de deixar passar uma colisão real só por
  // não se saber ainda quem vai jogar.
  function avoidLeagueCollisionsOnDate(date, sourceLabel, involvedTeamIds, _depth, exclude){
    const depth = _depth||0;
    const involvedSet = involvedTeamIds ? new Set(involvedTeamIds) : null;
    const justShifted = new Set();
    let algoFoiReagendado = false;
    Object.values(state.competitions).forEach(comp=>{
      (comp.fixtures||[]).forEach(round=>{
        if(exclude && exclude.has(round)) return;
        if(!round.date || !sameDay(round.date, date)) return;
        if(involvedSet && !round.some(fx=>fx&&(involvedSet.has(fx.home)||involvedSet.has(fx.away)))) return;
        const dataAntiga = new Date(round.date);
        round.date = addDays(round.date, 2);
        algoFoiReagendado = true;
        justShifted.add(round);
        const envolveUtilizador = round.some(fx=>fx.home===state.userTeamId || fx.away===state.userTeamId);
        if(envolveUtilizador){
          pushNews(state.currentDate, `Por causa d${sourceLabel.startsWith("C")?"a "+sourceLabel:sourceLabel}, a jornada de ${competitionLinkHtml(comp.id)} agendada para ${fmtDateShort(dataAntiga)} foi reagendada para ${fmtDateShort(round.date)}.`, "sistema");
        }
      });
    });
    // Restantes provas (todas de eliminação direta): cada "jogo"/"mão" guarda a data diretamente
    // no próprio objeto (tie.date, ou leg.date nas eliminatórias a duas mãos europeias) — nunca
    // dentro de uma "jornada" com várias equipas como nas ligas. Percorre-se cada contentor
    // conhecido (a lista cresce à medida que se acrescentam provas novas ao jogo) à procura de
    // qualquer objeto com home/away/date, reagendando-o com a mesma regra (avança 2 dias).
    function shiftMatchIfCollides(match, label){
      if(!match || typeof match!=="object" || !match.date || typeof match.home!=="string" || typeof match.away!=="string") return;
      if(exclude && exclude.has(match)) return;
      if(!sameDay(match.date, date)) return;
      if(involvedSet && !involvedSet.has(match.home) && !involvedSet.has(match.away)) return;
      const dataAntiga = new Date(match.date);
      match.date = addDays(match.date, 2);
      algoFoiReagendado = true;
      justShifted.add(match);
      const envolveUtilizador = match.home===state.userTeamId || match.away===state.userTeamId;
      if(envolveUtilizador){
        pushNews(state.currentDate, `Por causa d${sourceLabel.startsWith("C")?"a "+sourceLabel:sourceLabel}, o jogo de ${label} agendado para ${fmtDateShort(dataAntiga)} foi reagendado para ${fmtDateShort(match.date)}.`, "sistema");
      }
    }
    // Rondas "à liga" (uma jornada com várias equipas, data guardada no próprio array — usado
    // também pela fase de grupos europeia, europaAssignGroupSetDates) — mesma ideia do primeiro
    // ciclo acima (state.competitions), generalizada para qualquer prova que use esta forma.
    function shiftRoundIfCollides(round, label){
      if(!Array.isArray(round) || !round.date || exclude && exclude.has(round)) return;
      if(!sameDay(round.date, date)) return;
      if(involvedSet && !round.some(fx=>fx&&(involvedSet.has(fx.home)||involvedSet.has(fx.away)))) return;
      const dataAntiga = new Date(round.date);
      round.date = addDays(round.date, 2);
      algoFoiReagendado = true;
      justShifted.add(round);
      const envolveUtilizador = round.some(fx=>fx && (fx.home===state.userTeamId || fx.away===state.userTeamId));
      if(envolveUtilizador){
        pushNews(state.currentDate, `Por causa d${sourceLabel.startsWith("C")?"a "+sourceLabel:sourceLabel}, a jornada de ${label} agendada para ${fmtDateShort(dataAntiga)} foi reagendada para ${fmtDateShort(round.date)}.`, "sistema");
      }
    }
    function walkOtherCompetitions(node, label, depth){
      if(!node || typeof node!=="object" || depth>8) return;
      if(Array.isArray(node)){ shiftRoundIfCollides(node, label); node.forEach(item=>walkOtherCompetitions(item, label, depth+1)); return; }
      shiftMatchIfCollides(node, label);
      Object.keys(node).forEach(k=>{
        // Historico é uma cópia arquivada de épocas já fechadas — nunca precisa de reagendamento
        // (essas datas já ficaram no passado, jogadas ou não). Os restantes ramos pesados/
        // irrelevantes (equivalente ao filtro já usado no diagnóstico de colisões) ficam de fora
        // por segurança, ainda que não devessem aparecer nestes contentores.
        if(k==="historico" || k==="players" || k==="financeiro" || k==="movimentos") return;
        walkOtherCompetitions(node[k], label, depth+1);
      });
    }
    walkOtherCompetitions(state.tacaPortugal, "Taça de Portugal", 0);
    walkOtherCompetitions(state.supertaca, "Supertaça António Livramento", 0);
    walkOtherCompetitions(state.eliteCup, "Elite Cup", 0);
    walkOtherCompetitions(state.copaDelRey, "Copa del Rey", 0);
    walkOtherCompetitions(state.coppaItalia, "Coppa Italia", 0);
    walkOtherCompetitions(state.supercopaEspana, "Supercopa de España", 0);
    walkOtherCompetitions(state.supercoppaItaliana, "Supercoppa Italiana", 0);
    walkOtherCompetitions(state.europa, "competições europeias", 0);
    rebuildGlobalAgenda();
    // Correção (bug real encontrado ao alargar esta função a todas as provas): tudo o que aqui se
    // reagenda é sempre empurrado para a MESMA nova data (a original +2 dias) — mas essa nova
    // data podia já estar ocupada por OUTRA prova qualquer, que nunca chegava a ser verificada
    // (só se verificava a data original pedida, nunca o destino do reagendamento). Isso permitia
    // um "reagendamento em cadeia" nunca detetado: A colide com B, A é empurrado 2 dias, e calha
    // a cair exatamente em cima de C, sem que C alguma vez seja avisado. Por isso, sempre que algo
    // for mesmo reagendado nesta passagem, valida-se recursivamente a NOVA data (limitada a 8
    // saltos — 16 dias no total — para nunca entrar em ciclo infinito num cenário degenerado).
    if(algoFoiReagendado && depth<8){
      // As jornadas/jogos reagendados NESTA passagem (justShifted) somam-se ao exclude já recebido
      // — a próxima verificação (na nova data) tem de as ignorar, senão confunde-as consigo
      // próprias e o ciclo repete-se para sempre em vez de parar assim que a nova data já não
      // colide com mais nada de genuinamente diferente (ver nota acima da definição da função).
      const nextExclude = exclude ? new Set(exclude) : new Set();
      justShifted.forEach(x => nextExclude.add(x));
      avoidLeagueCollisionsOnDate(addDays(date,2), sourceLabel, involvedTeamIds, depth+1, nextExclude);
    }
  }
  // Provas "só da Plata" (Copa de la Princesa): as notícias gerais só interessam a quem as segue
  // (clube participante ou qualquer clube da OK Liga Plata) — ao contrário da Copa del Rey/Coppa
  // Italia, não devem interromper o avanço de quem gere um clube de outro escalão/país.
  function nationalCupNewsAllowed(cupId){
    const cfg = NATIONAL_CUP_CONFIG[cupId];
    if(!cfg.soPlata) return true;
    const edicao = nationalCupContainer(cupId).edicao;
    const me = state.userTeamId;
    if(edicao && (edicao.participantes||[]).includes(me)) return true;
    const t = state.teams[me];
    return !!t && t.divisaoAtual==="ok-liga-plata";
  }
  function nationalCupContainer(cupId){
    const cfg = NATIONAL_CUP_CONFIG[cupId];
    if(!state[cfg.stateField] || typeof state[cfg.stateField]!=="object") state[cfg.stateField] = { historico: [], edicao: null };
    if(!Array.isArray(state[cfg.stateField].historico)) state[cfg.stateField].historico = [];
    return state[cfg.stateField];
  }
  function nationalCupAssignDatesForFase(cupId, fase){
    const edicao = nationalCupContainer(cupId).edicao;
    const cfg = NATIONAL_CUP_CONFIG[cupId];
    const date = edicao.datas[fase];
    // Correção (verificação pedida pelo utilizador): antes só a data da FINAL era protegida
    // contra colisões (uma única chamada em maybeStartNationalCup, feita antecipadamente) — os
    // quartos e as meias-finais nunca eram verificados. Passa a proteger-se todas as fases, no
    // momento exato em que cada uma recebe data — SEMPRE antes de atribuir a data aos próprios
    // jogos desta fase (que continuam com date:null nesse momento, logo nunca "colidem" consigo
    // mesmos): só assim é possível distinguir uma colisão real com OUTRA prova de uma falsa
    // colisão com os nossos próprios jogos, que estamos prestes a agendar para esta mesma data.
    // Os clubes desta fase já são conhecidos neste momento (o emparelhamento já existe, só falta
    // a data) — protege-se apenas a disponibilidade real desses clubes (3.3 da auditoria), não o
    // dia inteiro.
    avoidLeagueCollisionsOnDate(date, cfg.label, (edicao.jogos[fase]||[]).flatMap(j=>[j.home,j.away]));
    (edicao.jogos[fase]||[]).forEach(j=>{ j.date = new Date(date); });
  }
  // Quartos: só a Coppa Italia tem vantagem de casa real (para o melhor classificado do par —
  // ver construção dos pares em maybeStartNationalCup); a Copa del Rey é sempre neutra. Meias e
  // final: sempre neutras em ambas (Final Four/Final a Oito, um só recinto).
  function nationalCupIsNeutral(cfg, fase){
    return fase!=="quartos" || cfg.neutralQuartos;
  }
  function maybeStartNationalCup(cupId){
    const cfg = NATIONAL_CUP_CONFIG[cupId];
    const comp = state.competitions[cfg.leagueCompetitionId];
    if(!comp) return;
    const container = nationalCupContainer(cupId);
    if(container.edicao && container.edicao.epoca===state.season) return; // idempotência
    if(container.historico.some(e=>e.epoca===state.season)) return;
    const half = Math.floor(comp.fixtures.length/2);
    if(comp.currentRound < half) return; // 1ª volta ainda não terminou
    const seeds = standingsForCompetition(cfg.leagueCompetitionId).slice(0,8).map(t=>t.id);
    if(seeds.length < 8) return;
    const datas = nationalCupSafeDates(cupId, state.season);
    const edicao = {
      epoca: state.season, seasonLabel: seasonLabel(state.season), fase: "quartos",
      participantes: seeds.slice(), datas,
      jogos: { quartos: [], semifinal: [], final: [] },
      campeao: null, runnerUp: null, premiosAtribuidos: false,
    };
    // 1º vs 8º, 2º vs 7º, 3º vs 6º, 4º vs 5º — tie.home é sempre o melhor classificado do par
    // (só importa de facto na Coppa Italia, cujos quartos não são em campo neutro).
    const pairs = [[0,7],[1,6],[2,5],[3,4]];
    edicao.jogos.quartos = pairs.map(([a,b]) => makeCupTie(seeds[a], seeds[b]));
    container.edicao = edicao;
    nationalCupAssignDatesForFase(cupId, "quartos");
    // Correção (pedido do utilizador: "por causa da Copa del Rey" a reagendar o Campeonato
    // Placard): sem involvedTeamIds, avoidLeagueCollisionsOnDate protegia o dia inteiro contra
    // TODAS as competições, incluindo países sem qualquer clube em comum com esta taça (a Copa
    // del Rey é só clubes espanhóis — nunca pode colidir com o campeonato português). Os
    // finalistas ainda não são conhecidos aqui, mas comp.teamIds (todos os clubes da liga deste
    // país, já em scope) é um superconjunto seguro e suficiente para restringir a proteção aos
    // clubes que realmente podem vir a jogar esta final.
    avoidLeagueCollisionsOnDate(datas.final, cfg.label, comp.teamIds);
    const matchupsTxt = edicao.jogos.quartos.map(j=>`${teamLinkHtml(j.home)} vs ${teamLinkHtml(j.away)}`).join("; ");
    pushNews(state.currentDate, `${cfg.label} ${edicao.seasonLabel}: apurados os 8 clubes da 1ª volta — 1/4 de Final: ${matchupsTxt} (${fmtDateLong(datas.quartos)}).`, "sistema", cfg.label, {autoAdvanceStop:true});
  }
  // Copa de la Princesa (OK Liga Plata): apura-se quando as DUAS zonas completam a 1.ª volta —
  // 1.º de cada zona, melhor 2.º (pontos, depois diferença de golos) e um clube organizador
  // (sorteado entre os restantes clubes da Plata; equipas B não organizam). Sorteio das meias-finais.
  function maybeStartCopaPrincesa(){
    const cupId = "copa-princesa", cfg = NATIONAL_CUP_CONFIG[cupId];
    const zones = plataZoneCompetitions();
    const norte = zones.norte, sul = zones.sul;
    if(!norte || !sul) return;
    const container = nationalCupContainer(cupId);
    if(container.edicao && container.edicao.epoca===state.season) return; // idempotência
    if(container.historico.some(e=>e.epoca===state.season)) return;
    const half = Math.floor(norte.fixtures.length/2);
    if(norte.currentRound < half || sul.currentRound < half) return;
    const tN = standingsForCompetition(norte.id), tS = standingsForCompetition(sul.id);
    if(tN.length<2 || tS.length<2) return;
    const better = (a,b)=> (a.stats.Pts!==b.stats.Pts ? a.stats.Pts>b.stats.Pts : (a.stats.GM-a.stats.GS)>=(b.stats.GM-b.stats.GS));
    const bestSecond = better(tN[1], tS[1]) ? tN[1] : tS[1];
    const chosen = [tN[0].id, tS[0].id, bestSecond.id];
    const hostPool = norte.teamIds.concat(sul.teamIds).filter(id=>!chosen.includes(id) && !isBTeamId(id));
    if(!hostPool.length) return;
    const anfitriao = hostPool[Math.floor(Math.random()*hostPool.length)];
    chosen.push(anfitriao);
    const draw = shuffleArray(chosen.slice());
    const datas = nationalCupSafeDates(cupId, state.season);
    container.edicao = {
      epoca: state.season, seasonLabel: seasonLabel(state.season), fase: "semifinal",
      participantes: chosen.slice(), anfitriao, datas,
      jogos: { quartos: [], semifinal: [makeCupTie(draw[0],draw[1]), makeCupTie(draw[2],draw[3])], final: [] },
      campeao: null, runnerUp: null, premiosAtribuidos: false,
    };
    nationalCupAssignDatesForFase(cupId, "semifinal");
    if(nationalCupNewsAllowed(cupId)){
      const involves = chosen.includes(state.userTeamId);
      pushNews(state.currentDate, `${cfg.label} ${container.edicao.seasonLabel}: apurados ${chosen.map(id=>teamLinkHtml(id)).join(", ")} (organizador: ${teamLinkHtml(anfitriao)}). Meias-finais: ${teamLinkHtml(draw[0])} vs ${teamLinkHtml(draw[1])}; ${teamLinkHtml(draw[2])} vs ${teamLinkHtml(draw[3])} (${fmtDateLong(datas.semifinal)}).`, "sistema", cfg.label, {autoAdvanceStop: involves});
    }
  }
  function nationalCupTieWinner(tie){ return tacaTieWinner(tie); } // mesma forma/regra de desempate (golos e, se preciso, grandes penalidades)
  function nationalCupAwardChampion(cupId, edicao, campeaoId, runnerUpId){
    const cfg = NATIONAL_CUP_CONFIG[cupId];
    const campeaoTeam = state.teams[campeaoId], runnerUpTeam = state.teams[runnerUpId];
    const prizeW = cfg.prizes ? cfg.prizes.winner : NATIONAL_CUP_PRIZE_WINNER;
    const prizeR = cfg.prizes ? cfg.prizes.runnerUp : NATIONAL_CUP_PRIZE_RUNNERUP;
    const prizeS = cfg.prizes ? cfg.prizes.semifinalist : NATIONAL_CUP_PRIZE_SEMIFINALIST;
    const prestigeW = cfg.prestigeWinner!=null ? cfg.prestigeWinner : NATIONAL_CUP_PRESTIGE_WINNER;
    edicao.campeao = campeaoId; edicao.runnerUp = runnerUpId;
    if(campeaoTeam){
      awardClubTitle(campeaoId, cupId, `${cfg.label} ${edicao.seasonLabel}`);
      campeaoTeam.reputacaoPontos = clamp((campeaoTeam.reputacaoPontos!=null?campeaoTeam.reputacaoPontos:normalizeClubReputation(campeaoTeam.reputacao, campeaoTeam)) + prestigeW, 5, 99);
      campeaoTeam.reputacao = reputationFromPoints(campeaoTeam.reputacaoPontos);
      addFinanceMovement(campeaoTeam, "receita", "Prémio de competição", `${cfg.label} ${edicao.seasonLabel} — vencedor`, prizeW, state.currentDate);
    }
    if(runnerUpTeam) addFinanceMovement(runnerUpTeam, "receita", "Prémio de competição", `${cfg.label} ${edicao.seasonLabel} — finalista`, NATIONAL_CUP_PRIZE_RUNNERUP, state.currentDate);
    (edicao.jogos.semifinal||[]).forEach(j=>{
      const loserId = nationalCupTieWinner(j)===j.home ? j.away : j.home;
      const team = state.teams[loserId];
      if(team) addFinanceMovement(team, "receita", "Prémio de competição", `${cfg.label} ${edicao.seasonLabel} — meia-final`, prizeS, state.currentDate);
    });
    edicao.premiosAtribuidos = true;
    if(nationalCupNewsAllowed(cupId)) pushNews(state.currentDate, `🏆 ${teamLinkHtml(campeaoId)} venceu a ${cfg.label} ${edicao.seasonLabel}!`, "sistema", cfg.label, {autoAdvanceStop:true});
  }
  function nationalCupCheckFaseComplete(cupId){
    const cfg = NATIONAL_CUP_CONFIG[cupId], edicao = nationalCupContainer(cupId).edicao;
    const jogos = edicao.jogos[edicao.fase]||[];
    if(!jogos.length || !jogos.every(j=>j.played)) return;
    if(edicao.fase==="quartos"){
      const winners = shuffleArray(jogos.map(nationalCupTieWinner));
      edicao.jogos.semifinal = [makeCupTie(winners[0],winners[1]), makeCupTie(winners[2],winners[3])];
      edicao.fase = "semifinal";
      nationalCupAssignDatesForFase(cupId, "semifinal");
      if(nationalCupNewsAllowed(cupId)) pushNews(state.currentDate, `Meias-finais da ${cfg.label} ${edicao.seasonLabel} definidas: ${teamLinkHtml(winners[0])} vs ${teamLinkHtml(winners[1])}; ${teamLinkHtml(winners[2])} vs ${teamLinkHtml(winners[3])}.`, "sistema", cfg.label, {autoAdvanceStop:true});
    } else if(edicao.fase==="semifinal"){
      const winners = jogos.map(nationalCupTieWinner);
      edicao.jogos.final = [makeCupTie(winners[0], winners[1])];
      edicao.fase = "final";
      nationalCupAssignDatesForFase(cupId, "final");
      if(nationalCupNewsAllowed(cupId)) pushNews(state.currentDate, `Final da ${cfg.label} ${edicao.seasonLabel} definida: ${teamLinkHtml(winners[0])} vs ${teamLinkHtml(winners[1])}.`, "sistema", cfg.label, {autoAdvanceStop:true});
    }
  }
  function nationalCupRecordTieResult(cupId, fase, idx, hs, as, soWinner){
    const container = nationalCupContainer(cupId), edicao = container.edicao;
    const tie = edicao && edicao.jogos[fase] && edicao.jogos[fase][idx];
    if(!tie || tie.played) return;
    tie.played = true; tie.homeScore = hs; tie.awayScore = as; tie.soWinner = soWinner||null;
    const winner = nationalCupTieWinner(tie);
    if(!winner){ console.error(`${NATIONAL_CUP_CONFIG[cupId].label}: eliminatória terminou sem vencedor definido.`, tie); return; }
    const cfg = NATIONAL_CUP_CONFIG[cupId];
    const loser = winner===tie.home ? tie.away : tie.home;
    // Correção (verificação pedida pelo utilizador: notícia sempre que a equipa do utilizador
    // passa de fase ou sai da competição): esta função nunca publicava NENHUMA notícia por
    // eliminatória (só as fases seguintes, no agregado — sorteio dos quartos/meias/final) — nem
    // sequer o resultado genérico que a Taça de Portugal, a Elite Cup e a Europa já têm. Passa a
    // ter sempre uma notícia genérica do resultado, mais uma notícia dedicada e explícita quando é
    // o próprio clube do utilizador a passar ou a sair, tal como já acontece na Taça de Portugal.
    const marcador = `${hs}-${as}${soWinner?" (g.p.)":""}`;
    // Correção (pedido do utilizador, 2026-09-17: "não quero notícias individuais de resultados
    // ... ou outra competição"): resultado entre dois clubes de IA não interessa — só publica
    // quando um dos dois é o próprio clube do utilizador (a notícia dedicada de "passa"/
    // "eliminado", logo a seguir, já cobre esse caso).
    if(winner===state.userTeamId || loser===state.userTeamId){
      pushNews(state.currentDate, `${teamLinkHtml(winner)} elimina ${teamLinkHtml(loser)} (${marcador}) na ${cfg.label} ${edicao.seasonLabel}.`, "jogo", `${cfg.label} — ${NATIONAL_CUP_FASE_LABEL[fase]||fase} — Resultado`);
    }
    if(winner===state.userTeamId && fase!=="final"){
      pushNews(state.currentDate, `${teamLinkHtml(winner)} passa os ${NATIONAL_CUP_FASE_LABEL[fase]||fase} da ${cfg.label} ${edicao.seasonLabel}, após vencer ${teamLinkHtml(loser)} por ${marcador}.`, "sistema", `${myTeam().name} avança na ${cfg.label}`, {autoAdvanceStop:true});
    } else if(loser===state.userTeamId){
      pushNews(state.currentDate, `${teamLinkHtml(loser)} foi eliminado da ${cfg.label} ${edicao.seasonLabel} nos ${NATIONAL_CUP_FASE_LABEL[fase]||fase}, após perder com ${teamLinkHtml(winner)} por ${marcador}.`, "sistema", `${myTeam().name} eliminado da ${cfg.label}`, {autoAdvanceStop:true});
    }
    if(fase==="final"){
      nationalCupAwardChampion(cupId, edicao, winner, loser);
      edicao.fase = "concluida";
      if(!container.historico.some(e=>e.epoca===edicao.epoca)) container.historico.push({ ...edicao });
      return;
    }
    nationalCupCheckFaseComplete(cupId);
  }
  // Processamento diário — chamado a partir de processPhaseFiveFinalsForCurrentDate (07-playoff.js),
  // exatamente como a Taça de Portugal/Elite Cup: resolve já todas as eliminatórias IA-IA da fase
  // atual cuja data já chegou, parando só quando encontra o jogo do próprio utilizador.
  function processNationalCupForCurrentDate(cupId){
    const cfg = NATIONAL_CUP_CONFIG[cupId];
    const edicao = nationalCupContainer(cupId).edicao;
    if(!edicao || edicao.fase==="concluida") return false;
    let processedAny = false;
    while(true){
      const jogos = edicao.jogos[edicao.fase]||[];
      const idx = jogos.findIndex(j=>!j.played && j.date && j.date<=state.currentDate);
      if(idx<0) break;
      const tie = jogos[idx];
      const involvesUser = tie.home===state.userTeamId || tie.away===state.userTeamId;
      const neutral = nationalCupIsNeutral(cfg, edicao.fase);
      if(!involvesUser){
        const res = simulateMatchToCompletion(tie.home, tie.away, true, neutral, cupId);
        nationalCupRecordTieResult(cupId, edicao.fase, idx, res.home, res.away, res.soWinner);
        processedAny = true;
        if(edicao.fase==="concluida") return true;
        continue;
      }
      if(state.matchDayReady) break;
      const oppId = tie.home===state.userTeamId ? tie.away : tie.home;
      state.pendingProvisional = { mine: ensureMinimumSquad(myTeam()), opp: ensureMinimumSquad(state.teams[oppId]) };
      state.pendingFixture = tie; state[cfg.pendingFaseField] = edicao.fase; state[cfg.pendingIndexField] = idx;
      state.pendingSuspensionServing = { home: getSuspendedIds(tie.home), away: getSuspendedIds(tie.away) };
      generatePreGameReport(tie, `${cfg.label} — ${NATIONAL_CUP_FASE_LABEL[edicao.fase]}`, null);
      state.matchDayReady = true;
      return true;
    }
    return processedAny;
  }
  // Serialização/desserialização para guardar/carregar (11-guardar-carregar.js) — mesmo padrão
  // de eliteCupSerializeEdition/eliteCupDeserializeEdition (07d-elite-cup.js): datas em ISO
  // string na gravação, objetos Date ao carregar.
  function nationalCupSerializeEdition(e){
    if(!e) return null;
    const iso = v => v ? new Date(v).toISOString() : null;
    const jogos = {};
    Object.keys(e.jogos||{}).forEach(fase=>{ jogos[fase] = (e.jogos[fase]||[]).map(j=>({...j, date: iso(j.date)})); });
    return { ...e, jogos, datas: e.datas ? { quartos: iso(e.datas.quartos), semifinal: iso(e.datas.semifinal), final: iso(e.datas.final) } : null };
  }
  function nationalCupDeserializeEdition(e){
    if(!e) return null;
    const dedate = v => v ? new Date(v) : null;
    const jogos = {};
    Object.keys(e.jogos||{}).forEach(fase=>{ jogos[fase] = (e.jogos[fase]||[]).map(j=>({...j, date: dedate(j.date)})); });
    return { ...e, jogos, datas: e.datas ? { quartos: dedate(e.datas.quartos), semifinal: dedate(e.datas.semifinal), final: dedate(e.datas.final) } : null };
  }
