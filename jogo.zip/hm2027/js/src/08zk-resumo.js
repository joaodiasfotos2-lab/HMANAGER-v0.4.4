// ============================= 08zk-resumo.js =============================
// Resumo do clube (0.4.0): painel único, sem scroll, que se adapta às provas em que o clube do
// utilizador realmente está (treinar o Benfica traz mais provas do que treinar o Tojal): liga,
// playoff, Taça, Supertaça, Elite Cup, taças nacionais, supertaças internacionais e as provas
// europeias. Cada prova mostra a fase, o lugar (quando faz sentido) e a forma recente; um clube
// eliminado de uma prova continua a vê-la, com a fase em que ficou.
// =============================================================================
const RS_FASES = {
  "pre-eliminatoria": "Pré-eliminatória", "32avos": "32 avos de final", "16avos": "16 avos de final",
  oitavos: "Oitavos de final", quartos: "Quartos de final", meiafinal: "Meias-finais", semifinal: "Meias-finais",
  meias: "Meias-finais", final: "Final", preliminar: "Eliminatória preliminar",
  PR: "Turno preliminar", QF: "Quartos de final", SF: "Meias-finais", F: "Final",
};
function rsFaseLabel(f) { return RS_FASES[f] || f; }
function rsNomeClube(id) { return state.teams[id] ? state.teams[id].name : "?"; }
function rsResultado(j, uid) {
  if (!j || !j.played) return null;
  const casa = j.home === uid;
  const m = casa ? j.homeScore : j.awayScore, s = casa ? j.awayScore : j.homeScore;
  if (m > s) return "V";
  if (m < s) return "D";
  if (j.soWinner) return ((j.soWinner === "home") === casa) ? "V" : "D";
  return "E";
}
function rsFormaPills(f) {
  const u = (f || []).slice(-5);
  return u.length
    ? u.map(r => `<span class="form-pill form-${r === "V" ? "win" : r === "E" ? "draw" : "loss"}">${r}</span>`).join("")
    : '<span class="rs-dim">Sem jogos ainda</span>';
}
// Eliminatórias a jogo único: { home, away, played, homeScore, awayScore, soWinner }.
const RS_ADAPT_SIMPLES = {
  vencedor: t => (typeof tacaTieWinner === "function" ? tacaTieWinner(t) : null),
  resultados: (t, uid) => { const r = rsResultado(t, uid); return r ? [r] : []; },
  placar: (t, uid) => t.played ? (t.home === uid ? `${t.homeScore}-${t.awayScore}` : `${t.awayScore}-${t.homeScore}`) + (t.soWinner ? " (g.p.)" : "") : "",
};
// Eliminatórias europeias a uma ou duas mãos: { home, away, legs:[...] }.
const RS_ADAPT_EUROPA = {
  vencedor: t => t.vencedor || (typeof europaTieDecide === "function" ? europaTieDecide(t) : null),
  resultados: (t, uid) => (t.legs || []).map(l => rsResultado(l, uid)).filter(Boolean),
  placar: (t, uid) => {
    if (!(t.legs || []).some(l => l.played)) return "";
    const a = europaTieAggregate(t);
    return t.home === uid ? `${a.golsHome}-${a.golsAway}` : `${a.golsAway}-${a.golsHome}`;
  },
};
// Motor genérico de eliminatórias: devolve null se o clube não participa.
function rsEliminatorias(uid, nome, key, jogos, fases, ad, extra) {
  extra = extra || {};
  let ultima = null; const forma = [];
  fases.forEach(f => (jogos[f] || []).forEach(t => {
    if (t.home === uid || t.away === uid) { ultima = { fase: f, tie: t }; ad.resultados(t, uid).forEach(r => forma.push(r)); }
  }));
  if (!ultima) {
    if (extra.semJogosAinda) return { key, nome, estado: "ativa", fase: extra.semJogosAinda, lugar: "", forma };
    return null;
  }
  const w = ad.vencedor(ultima.tie);
  const opp = ultima.tie.home === uid ? ultima.tie.away : ultima.tie.home;
  const label = rsFaseLabel(ultima.fase);
  const placar = ad.placar(ultima.tie, uid);
  const eFinal = ultima.fase === fases[fases.length - 1];
  if (!w) return { key, nome, estado: "ativa", fase: label, lugar: "", nota: `Próximo adversário: ${rsNomeClube(opp)}`, forma };
  if (w === uid) {
    if (eFinal) return { key, nome, estado: "campea", fase: "Campeão", lugar: "", nota: `Final ganha a ${rsNomeClube(opp)}${placar ? ` (${placar})` : ""}`, forma };
    return { key, nome, estado: "ativa", fase: `${label} — apurado`, lugar: "", nota: `Eliminou ${rsNomeClube(opp)}${placar ? ` (${placar})` : ""}`, forma };
  }
  return { key, nome, estado: "afastada", fase: `Eliminado: ${label}`, lugar: "", nota: `Perdeu com ${rsNomeClube(opp)}${placar ? ` (${placar})` : ""}`, forma };
}
function rsLinhaGrupo(g, uid) {
  const tab = europaGroupStandings(g);
  const pos = tab.findIndex(r => r.id === uid);
  const row = tab[pos];
  const meus = [];
  (g.fixtures || []).forEach(round => { const fx = (round || []).find(f => f.home === uid || f.away === uid); if (fx) meus.push(fx); });
  return { pos, row, forma: meus.filter(f => f.played).map(f => rsResultado(f, uid)), jogados: meus.filter(f => f.played).length, total: meus.length };
}

function rsLiga(team) {
  const uid = team.id;
  const comp = state.competitions && state.competitions[state.userCompetitionId];
  if (!comp) return [];
  const out = [];
  const tabela = standingsForCompetition(comp.id);
  const idx = tabela.findIndex(t => t.id === uid);
  const meus = [];
  (comp.fixtures || []).forEach(r => { const f = r.find(x => x.home === uid || x.away === uid); if (f) meus.push(f); });
  const jogados = meus.filter(f => f.played).length, total = meus.length;
  const forma = meus.filter(f => f.played).map(f => rsResultado(f, uid));
  const cfg = typeof PLAYOFF_DIVISION_CONFIG !== "undefined" ? PLAYOFF_DIVISION_CONFIG[comp.divisionId] : null;
  const regularFim = total > 0 && jogados >= total;
  out.push({
    key: "liga", cid: comp.id, nome: competitionLabel(comp.id),
    estado: regularFim && !cfg ? "concluida" : "ativa",
    fase: regularFim ? "Fase regular concluída" : `Fase regular · jornada ${jogados}/${total}`,
    lugar: idx >= 0 ? `${idx + 1}.º lugar · ${team.stats && team.stats.Pts != null ? team.stats.Pts : 0} pts` : "",
    forma,
  });
  // Playoff da divisão (Placard, OK Liga, Serie A1).
  if (cfg) {
    const po = comp.playoff || null;
    const nome = `${cfg.championLabel} — Playoff`;
    if (po && po.series) {
      const seeds = po.seeds || [];
      if (!seeds.includes(uid)) {
        out.push({ key: "playoff", nome, estado: "afastada", fase: "Não se apurou para o playoff", lugar: idx >= 0 ? `Fase regular: ${idx + 1}.º lugar` : "", forma: [] });
      } else {
        let ultima = null; const f2 = [];
        ["PR", "QF", "SF", "F"].forEach(ph => (po.series[ph] || []).forEach(s => {
          if (s.teamTop === uid || s.teamBottom === uid) {
            ultima = { ph, s };
            (s.games || []).forEach(g => { const r = rsResultado({ ...g, played: true }, uid); if (r) f2.push(r); });
          }
        }));
        if (ultima) {
          const s = ultima.s, opp = s.teamTop === uid ? s.teamBottom : s.teamTop;
          const placar = `${(s.wins && s.wins[uid]) || 0}-${(s.wins && s.wins[opp]) || 0}`;
          if (s.winner === uid && ultima.ph === "F") out.push({ key: "playoff", nome, estado: "campea", fase: "Campeão nacional", lugar: "", nota: `Final ganha a ${rsNomeClube(opp)} (${placar})`, forma: f2 });
          else if (s.winner === uid) out.push({ key: "playoff", nome, estado: "ativa", fase: `${rsFaseLabel(ultima.ph)} — apurado`, lugar: "", nota: `Eliminou ${rsNomeClube(opp)} (${placar})`, forma: f2 });
          else if (s.winner) out.push({ key: "playoff", nome, estado: "afastada", fase: `Eliminado: ${rsFaseLabel(ultima.ph)}`, lugar: "", nota: `Perdeu com ${rsNomeClube(opp)} (${placar})`, forma: f2 });
          else out.push({ key: "playoff", nome, estado: "ativa", fase: `${rsFaseLabel(ultima.ph)} · série ${placar}`, lugar: "", nota: `Adversário: ${rsNomeClube(opp)}`, forma: f2 });
        }
      }
    } else if (regularFim) {
      const lim = cfg.preliminaryRound ? 10 : 8;
      out.push(idx >= 0 && idx < lim
        ? { key: "playoff", nome, estado: "ativa", fase: "Apurado — aguarda o início", lugar: `${idx + 1}.º lugar`, forma: [] }
        : { key: "playoff", nome, estado: "afastada", fase: "Não se apurou para o playoff", lugar: idx >= 0 ? `Fase regular: ${idx + 1}.º lugar` : "", forma: [] });
    }
  }
  // Eliminatórias de subida/final de divisão (2.ª Divisão e OK Liga Plata).
  [[state.promotionTie, "Liguilha de promoção", "liguilha"], [state.secondDivisionFinal, "Final da 2.ª Divisão", "final2div"], [state.plataTie, "Liguilha da OK Liga Plata", "plata"]].forEach(([t, nome, key]) => {
    if (!t || !(t.participants || []).includes(uid)) return;
    const jogos = (t.games || []);
    const f2 = jogos.filter(g => g.played).map(g => rsResultado(g, uid)).filter(Boolean);
    const opp = t.participants.find(x => x !== uid);
    if (t.winner) out.push({ key, nome, estado: t.winner === uid ? "campea" : "afastada", fase: t.winner === uid ? "Vencedor" : "Eliminado", lugar: "", nota: `Contra ${rsNomeClube(opp)}`, forma: f2 });
    else out.push({ key, nome, estado: "ativa", fase: "Eliminatória a duas mãos", lugar: "", nota: `Contra ${rsNomeClube(opp)}`, forma: f2 });
  });
  return out;
}

function rsCompeticoes(team) {
  const uid = team.id, out = [];
  const add = e => { if (e) out.push(e); };
  try { rsLiga(team).forEach(add); } catch (e) { console.error("rsLiga", e); }
  try {
    const tp = state.tacaPortugal;
    if (tp && tp.jogos) {
      const fases = ["pre-eliminatoria", "32avos", "16avos", "oitavos", "quartos", "meiafinal", "final"];
      const bye = (tp.byesPlacard || []).includes(uid) || (tp.byesNaoPlacard || []).includes(uid) || tp.bye32avos === uid;
      let e = rsEliminatorias(uid, "Taça de Portugal", "taca", tp.jogos, fases, RS_ADAPT_SIMPLES, bye ? { semJogosAinda: "Isento — entra nos 32 avos de final" } : null);
      if (e && tp.campeao === uid) { e.estado = "campea"; e.fase = "Campeão"; }
      add(e);
    }
  } catch (e) { console.error("rs taça", e); }
  try {
    const j = state.supertaca && state.supertaca.jogo;
    if (j && (j.home === uid || j.away === uid)) {
      const opp = j.home === uid ? j.away : j.home;
      if (!j.played) add({ key: "supertaca", nome: "Supertaça António Livramento", estado: "ativa", fase: "Final · jogo único", lugar: "", nota: `Contra ${rsNomeClube(opp)} · ${fmtDateShort(j.date)}`, forma: [] });
      else {
        const venceu = (j.vencedor || (rsResultado(j, uid) === "V" ? uid : opp)) === uid;
        add({ key: "supertaca", nome: "Supertaça António Livramento", estado: venceu ? "campea" : "afastada", fase: venceu ? "Vencedor" : "Perdeu a final", lugar: "", nota: `Contra ${rsNomeClube(opp)}`, forma: [rsResultado(j, uid)].filter(Boolean) });
      }
    }
  } catch (e) { console.error("rs supertaça", e); }
  try {
    const ed = state.eliteCup && state.eliteCup.edicao;
    if (ed && (ed.participantes || []).includes(uid)) {
      const r = rsEliminatorias(uid, "Elite Cup", "elite", ed.jogos || {}, ["quartos", "semifinal", "final"], RS_ADAPT_SIMPLES);
      if (r) { if (ed.campeao === uid) { r.estado = "campea"; r.fase = "Campeão"; } add(r); }
    }
  } catch (e) { console.error("rs elite", e); }
  try {
    if (typeof NATIONAL_CUP_CONFIG === "object") {
      Object.keys(NATIONAL_CUP_CONFIG).forEach(cupId => {
        const cfg = NATIONAL_CUP_CONFIG[cupId];
        const ed = state[cfg.stateField] && state[cfg.stateField].edicao;
        if (!ed || !ed.jogos) return;
        add(rsEliminatorias(uid, cfg.label, cupId, ed.jogos, ["quartos", "semifinal", "final"], RS_ADAPT_SIMPLES));
      });
    }
  } catch (e) { console.error("rs copas", e); }
  try {
    const sce = state.supercopaEspana && state.supercopaEspana.edicao;
    if (sce && sce.jogos) add(rsEliminatorias(uid, "Supercopa de España", "supercopa-es", sce.jogos, ["semifinal", "final"], RS_ADAPT_SIMPLES));
    const sci = state.supercoppaItaliana && state.supercoppaItaliana.jogo;
    if (sci && (sci.campeaoNacionalId === uid || sci.adversarioId === uid)) {
      const opp = sci.campeaoNacionalId === uid ? sci.adversarioId : sci.campeaoNacionalId;
      const f = [sci.leg1, sci.leg2].filter(l => l && l.played).map(l => rsResultado(l, uid)).filter(Boolean);
      if (!sci.concluida) add({ key: "supercoppa-it", nome: "Supercoppa Italiana", estado: "ativa", fase: "Duas mãos", lugar: "", nota: `Contra ${rsNomeClube(opp)}`, forma: f });
      else add({ key: "supercoppa-it", nome: "Supercoppa Italiana", estado: sci.vencedor === uid ? "campea" : "afastada", fase: sci.vencedor === uid ? "Vencedor" : "Perdeu a final", lugar: "", nota: `Contra ${rsNomeClube(opp)}`, forma: f });
    }
  } catch (e) { console.error("rs supertaças", e); }
  try { rsEuropa(uid).forEach(add); } catch (e) { console.error("rs europa", e); }
  const ordem = { ativa: 0, campea: 1, concluida: 2, afastada: 3 };
  const ALVOS = { taca: "taca-portugal", elite: "elite-cup", "supercopa-es": "supercopa-espana", supertaca: "supertaca", "supercoppa-it": "supercoppa-italiana", "eu-qualif": "europa-qualificacao", "eu-cl": "europa-champions", "eu-cup": "europa-cup", "eu-trophy": "europa-trophy" };
  const PLAYOFF_KEYS = ["playoff", "liguilha", "final2div", "plata"];
  out.forEach(e => {
    if (e.key === "liga") { e.alvo = e.cid || state.userCompetitionId; e.tab = "tabStandings"; }
    else if (PLAYOFF_KEYS.includes(e.key)) { e.alvo = state.userCompetitionId; e.tab = "tabPlayoff"; }
    else e.alvo = ALVOS[e.key] || e.key;
  });
  return out.map((e, i) => ({ ...e, _i: i })).sort((a, b) => (ordem[a.estado] - ordem[b.estado]) || (a._i - b._i));
}

function rsEuropa(uid) {
  const ed = state.europa && state.europa.edicao;
  if (!ed) return [];
  const out = [];
  const letra = g => String(g.nome || "").split("— ").pop();
  // Ronda de qualificação.
  const gq = ((ed.qualificacao && ed.qualificacao.grupos) || []).find(g => g.teamIds.includes(uid));
  if (gq) {
    const L = rsLinhaGrupo(gq, uid);
    const dest = ed.participantes && ed.participantes[uid];
    const concl = !!(ed.qualificacao && ed.qualificacao.concluida);
    const lugar = L.pos >= 0 ? `${L.pos + 1}.º lugar · ${L.row.Pts} pts` : "";
    if (!concl) out.push({ key: "eu-qualif", nome: "Qualificação europeia", estado: "ativa", fase: `${letra(gq)} · jogo ${L.jogados}/${L.total}`, lugar, forma: L.forma });
    else if (dest === "qualificacao" || !dest) out.push({ key: "eu-qualif", nome: "Qualificação europeia", estado: "afastada", fase: "Eliminado: não passou a qualificação", lugar: `${letra(gq)} · ${L.pos + 1}.º lugar`, forma: L.forma });
    else out.push({ key: "eu-qualif", nome: "Qualificação europeia", estado: "concluida", fase: `Concluída — apurado para a ${dest === "champions" ? "Champions League" : dest === "cup" ? "WSE Cup" : "WSE Trophy"}`, lugar: `${letra(gq)} · ${L.pos + 1}.º lugar`, forma: L.forma });
  }
  // Champions League.
  const ch = ed.champions;
  if (ch) {
    const gc = (ch.grupos || []).find(g => g.teamIds.includes(uid));
    const jogosKO = ch.jogos || {};
    if (gc) {
      const L = rsLinhaGrupo(gc, uid);
      const dentroKO = ["quartos", "meias", "final"].some(f => (jogosKO[f] || []).some(t => t.home === uid || t.away === uid));
      const koDesenhado = ["quartos", "meias", "final"].some(f => (jogosKO[f] || []).length);
      if (dentroKO) {
        const r = rsEliminatorias(uid, "WSE Champions League", "eu-cl", jogosKO, ["quartos", "meias", "final"], RS_ADAPT_EUROPA);
        r.forma = L.forma.concat(r.forma);
        if (ch.campeao === uid) { r.estado = "campea"; r.fase = "Campeão"; }
        out.push(r);
      } else if (koDesenhado) {
        out.push({ key: "eu-cl", nome: "WSE Champions League", estado: "afastada", fase: "Eliminado: fase de grupos", lugar: `${letra(gc)} · ${L.pos + 1}.º lugar · ${L.row.Pts} pts`, forma: L.forma });
      } else {
        out.push({ key: "eu-cl", nome: "WSE Champions League", estado: "ativa", fase: `Fase de grupos · ${letra(gc)}`, lugar: L.pos >= 0 ? `${L.pos + 1}.º lugar · ${L.row.Pts} pts (${L.jogados}/${L.total} jogos)` : "", forma: L.forma });
      }
    } else if ((ch.directIds || []).includes(uid)) {
      out.push({ key: "eu-cl", nome: "WSE Champions League", estado: "ativa", fase: "Apurado — aguarda o sorteio dos grupos", lugar: "", forma: [] });
    }
  }
  // WSE Cup e WSE Trophy.
  [["cup", "WSE Cup", ["oitavos", "quartos", "meias", "final"]], ["trophy", "WSE Trophy", ["preliminar", "quartos", "meias", "final"]]].forEach(([k, nome, fases]) => {
    const b = ed[k]; if (!b) return;
    const participa = (ed.participantes && ed.participantes[uid] === k) || (b.directIds || []).includes(uid) || (b.byeIds || []).includes(uid);
    if (!participa && !fases.some(f => ((b.jogos || {})[f] || []).some(t => t.home === uid || t.away === uid))) return;
    const bye = (b.byeIds || []).includes(uid) ? "Isento da eliminatória preliminar" : "Apurado — aguarda o sorteio";
    const r = rsEliminatorias(uid, nome, "eu-" + k, b.jogos || {}, fases, RS_ADAPT_EUROPA, { semJogosAinda: bye });
    if (r) { if (b.campeao === uid) { r.estado = "campea"; r.fase = "Campeão"; } out.push(r); }
  });
  return out;
}

// ------------------------------------------------------------------ próximo jogo (qualquer prova)
function rsProximoJogo(team) {
  const uid = team.id, c = [];
  const hoje = new Date(state.currentDate); hoje.setHours(0, 0, 0, 0);
  const push = (date, comp, oppId, local, extra) => { if (date) c.push({ date: new Date(date), comp, oppId, local, extra: extra || "" }); };
  try {
    if (state.playoffActive && state.playoff && state.playoff.series) {
      const ph = state.playoff.phase;
      const s = (state.playoff.series[ph] || []).find(x => (x.teamTop === uid || x.teamBottom === uid) && !x.winner);
      if (s) {
        const opp = s.teamTop === uid ? s.teamBottom : s.teamTop;
        push(state.playoff.nextGameDate, `Playoff — ${s.label}`, opp, seriesGameSides(s).home === uid ? "C" : "F", `Série ${(s.wins[uid] || 0)}-${(s.wins[opp] || 0)}`);
      }
    } else {
      const r = state.currentRound < (state.fixtures || []).length ? state.fixtures[state.currentRound] : null;
      const f = r && r.find(x => x.home === uid || x.away === uid);
      if (f) push(r.date, `${competitionLabel(state.userCompetitionId)} · jornada ${state.currentRound + 1}`, f.home === uid ? f.away : f.home, f.home === uid ? "C" : "F");
    }
  } catch (e) { /* prova opcional */ }
  try {
    const tp = state.tacaPortugal;
    if (tp && tp.fase && tp.fase !== "concluida") {
      const t = (tp.jogos[tp.fase] || []).find(j => !j.played && j.date && (j.home === uid || j.away === uid));
      if (t) push(t.date, `Taça de Portugal — ${rsFaseLabel(tp.fase)}`, t.home === uid ? t.away : t.home, (tp.fase === "meiafinal" || tp.fase === "final") ? "N" : (t.home === uid ? "C" : "F"));
    }
  } catch (e) { /* prova opcional */ }
  try {
    const j = state.supertaca && state.supertaca.jogo;
    if (j && !j.played && j.date && (j.home === uid || j.away === uid)) push(j.date, "Supertaça António Livramento", j.home === uid ? j.away : j.home, "N");
  } catch (e) { /* prova opcional */ }
  try {
    [[state.promotionTie, "Liguilha de promoção"], [state.secondDivisionFinal, "Final da 2.ª Divisão"], [state.plataTie, "Liguilha da OK Liga Plata"]].forEach(([t, nome]) => {
      if (!t || t.winner || !(t.participants || []).includes(uid)) return;
      const g = (t.games || []).find(x => !x.played);
      if (g) push(g.date, nome, g.home === uid ? g.away : g.home, g.home === uid ? "C" : "F");
    });
  } catch (e) { /* prova opcional */ }
  try {
    if (typeof otherCompetitionsScheduleRows === "function") otherCompetitionsScheduleRows().forEach(r => { if (!r.played) push(r.date, r.competicao, r.oppId, r.local); });
  } catch (e) { /* prova opcional */ }
  c.sort((a, b) => a.date - b.date);
  const ok = c.filter(x => { const d = new Date(x.date); d.setHours(0, 0, 0, 0); return d >= hoje; });
  let prox = ok[0] || null;
  // Amigáveis (pré-época e calendário), que só trazem a data e o rótulo.
  try {
    const am = typeof preSeasonNextFriendlyRow === "function" ? preSeasonNextFriendlyRow() : null;
    if (am && (!prox || new Date(am.date) < prox.date)) prox = { date: new Date(am.date), comp: am.label || "Jogo de preparação", oppId: am.oppId || null, local: null, extra: "" };
  } catch (e) { /* opcional */ }
  return prox;
}

// ------------------------------------------------------------------ blocos do painel
function rsAlertas(club) {
  const a = [];
  const ct = club.players.filter(p => p.contrato && isFinalContractYear(p)).length;
  if (ct) a.push(`${ct} contrato${ct > 1 ? "s" : ""} a terminar`);
  const of = (state.aiOffers || []).filter(o => o.toTeamId === club.id && o.status === "pendente").length;
  if (of) a.push(`${of} proposta${of > 1 ? "s" : ""} no mercado`);
  const su = club.players.filter(p => (p.suspensoJogos || 0) > 0).length;
  if (su) a.push(`${su} suspenso${su > 1 ? "s" : ""}`);
  const le = club.players.filter(p => (p.diasLesao || 0) > 0).length;
  if (le) a.push(`${le} lesionado${le > 1 ? "s" : ""}`);
  const de = club.players.filter(p => (p.satisfacao != null ? p.satisfacao : 70) < 40).length;
  if (de) a.push(`${de} descontente${de > 1 ? "s" : ""}`);
  const em = club.players.filter(p => p.emprestimo && p.emprestimo.returnSeason <= state.season + 1).length;
  if (em) a.push(`${em} empréstimo${em > 1 ? "s" : ""} a terminar`);
  return a;
}
function rsCompCardHtml(e) {
  const rotulo = { ativa: "Em prova", campea: "Campeão", concluida: "Concluída", afastada: "Eliminado" }[e.estado];
  return `<div class="rs-comp rs-${e.estado} rs-click" role="button" tabindex="0" data-alvo="${escapeHtml(e.alvo || "")}" data-tab="${e.tab || ""}" title="Abrir ${escapeHtml(e.nome)}">
    <div class="rs-comp-h"><b title="${escapeHtml(e.nome)}">${escapeHtml(e.nome)}</b><span class="rs-badge rs-b-${e.estado}">${rotulo}</span></div>
    <div class="rs-comp-fase">${escapeHtml(e.fase)}</div>
    ${e.lugar ? `<div class="rs-comp-lugar">${escapeHtml(e.lugar)}</div>` : ""}
    ${e.nota ? `<div class="rs-dim">${escapeHtml(e.nota)}</div>` : ""}
    <div class="rs-comp-forma">${rsFormaPills(e.forma)}</div>
  </div>`;
}
function rsEscudoGrande(id) {
  const t = state.teams[id];
  if (!t) return `<span class="rs2-crest rs2-crest-vazio"></span>`;
  const url = typeof clubCrestUrl === "function" ? clubCrestUrl(id) : null;
  return url ? `<span class="rs2-crest"><img src="${url}" alt="" class="crest-img"></span>`
    : `<span class="rs2-crest rs2-crest-vazio" style="background:${clubDisplayColor(t)}">${escapeHtml((t.name || "?").trim().slice(0, 1))}</span>`;
}
function rsEquipaCartaz(id) {
  const t = state.teams[id];
  const forma = t ? (t.recentResults || []).slice(-5) : [];
  return `<div class="rs2-team">${rsEscudoGrande(id)}<b>${teamLinkHtml(id)}</b><div class="rs2-forma">${rsFormaPills(forma)}</div></div>`;
}
// Logótipo da competição de um jogo, a partir do nome com que o próximo jogo é descrito.
function rsLogoDaProva(nome) {
  const n = String(nome || "");
  let id = null;
  if (/Taça de Portugal/.test(n)) id = "taca-portugal";
  else if (/Supertaça/.test(n)) id = "supertaca";
  else if (/Elite Cup/.test(n)) id = "elite-cup";
  else if (/Champions/.test(n)) id = "europa-champions";
  else if (/WSE Cup/.test(n)) id = "europa-cup";
  else if (/Trophy/.test(n)) id = "europa-trophy";
  else if (/^Playoff|jornada/.test(n)) id = state.userCompetitionId;
  else if (n.startsWith(competitionLabel(state.userCompetitionId))) id = state.userCompetitionId;
  return id && typeof competitionLogoUrl === "function" ? competitionLogoUrl(id) : null;
}
function rsProximoHtml(team) {
  const p = rsProximoJogo(team);
  if (!p) return `<div class="rs2-vazio">Sem mais jogos agendados nesta época.</div>`;
  const dias = Math.round((new Date(p.date).setHours(0, 0, 0, 0) - new Date(state.currentDate).setHours(0, 0, 0, 0)) / 86400000);
  const quando = dias <= 0 ? "É hoje" : dias === 1 ? "Amanhã" : `Faltam ${dias} dias`;
  const local = p.local === "N" ? "Campo neutro" : p.local === "C" ? "Em casa" : p.local === "F" ? "Fora" : "";
  const logo = rsLogoDaProva(p.comp);
  const meio = `<div class="rs2-mid">${logo ? `<img class="rs2-prova-logo" src="${logo}" alt="">` : ""}<span class="rs2-comp-nome">${escapeHtml(p.comp)}</span><b class="rs2-vs-t">VS</b><span class="rs2-data">${fmtDateLong(p.date)}</span><span class="rs2-count">${quando}</span>${local || p.extra ? `<span class="rs2-local">${[local, p.extra].filter(Boolean).map(escapeHtml).join(" · ")}</span>` : ""}</div>`;
  if (!p.oppId || !state.teams[p.oppId]) return `<div class="rs2-vs">${meio}</div>`;
  const fora = p.local === "F";
  const a = fora ? p.oppId : team.id, b = fora ? team.id : p.oppId;
  return `<div class="rs2-vs">${rsEquipaCartaz(a)}${meio}${rsEquipaCartaz(b)}</div>`;
}
const RS_ENVELOPE_SVG = '<svg viewBox="0 0 64 48" width="60" height="45" aria-hidden="true"><rect x="2" y="6" width="60" height="38" rx="5" fill="#f4f1e8" stroke="#c9c2ad" stroke-width="2"/><path d="M4 10l28 20L60 10" fill="none" stroke="#9a927a" stroke-width="3" stroke-linejoin="round"/></svg>';
function rsMailHtml(n, ultimo) {
  return `<button type="button" class="rs2-mail${n ? " has" : ""}" id="rsMailBtn" title="${n ? n + " e-mail" + (n > 1 ? "s" : "") + " por ler" : "Sem e-mails por ler"}">
    <span class="rs2-env">${RS_ENVELOPE_SVG}${n ? `<i class="rs2-badge-n">${n > 99 ? "99+" : n}</i>` : ""}</span>
    <span class="rs2-mail-t">${n ? `${n} por ler` : "Em dia"}${ultimo ? `<small>${escapeHtml((ultimo.title || "").slice(0, 46))}</small>` : ""}</span></button>`;
}
function rsFinancasHtml(club) {
  initClubFinance(club);
  const st = financialState(club), f = club.financeiro, pr = st.projection;
  const net = Math.round(pr.net);
  const cor = st.level >= 3 ? "rs-bad" : st.level >= 1 ? "rs-warn" : "rs-ok";
  const divida = (f.divida || 0) + (f.creditoUtilizado || 0);
  return `<div class="rs-card-h"><span class="eyebrow">Finanças</span><span class="rs-badge ${cor}">${escapeHtml(st.label)}</span></div>
    <div class="rs2-saldo">${fmtMoney(f.saldo)}<small>saldo</small></div>
    <div class="rs-kv">
      <div><span>Resultado/mês</span><b class="${net < 0 ? "money-neg" : "money-pos"}">${fmtMoney(net)}</b></div>
      <div><span>Massa salarial</span><b>${Math.round(st.wageRatio * 100)}% das receitas</b></div>
      <div><span>${divida > 0 ? "Dívida" : "Transferências"}</span><b>${fmtMoney(divida > 0 ? divida : (f.orcamentoTransferencias || 0))}</b></div>
    </div>
    ${net < 0 ? `<div class="rs-dim">Autonomia de cerca de ${pr.runway >= 99 ? "—" : Math.round(pr.runway)} meses.</div>` : ""}`;
}
function rsDirecaoHtml(club) {
  const confianca = club.confiancaDirecao != null ? club.confiancaDirecao : 60;
  const tier = directionConfidenceTier(confianca);
  let objetivos = "";
  try {
    if (typeof presElegivelNaEpoca === "function" && presElegivelNaEpoca(club) && typeof presAvaliar === "function") {
      const dono = presOwner(club), obj = presObjetivosAtuais(dono), live = presAvaliar(dono);
      const ic = { cumprido: "✓", falhado: "✕", "em-linha": "●", "em-risco": "▲" };
      objetivos = live.goals.map((g, i) => {
        const o = obj.itens[i];
        return `<div class="rs-obj rs-o-${g.estado}" title="${escapeHtml(o.label + " — " + g.detalhe)}"><span>${PRES_TIPOS[o.tipo].icon} ${g.principal ? "<b>Principal</b> · " : ""}${escapeHtml(o.label)}</span><i>${ic[g.estado] || ""}</i></div>`;
      }).join("");
    }
  } catch (e) { objetivos = ""; }
  return `<div class="rs-card-h"><span class="eyebrow">Direcção</span><span class="rs-badge ${tier.cls === "ok" ? "rs-ok" : "rs-warn"}">${tier.label} · ${Math.round(confianca)}/100</span></div>
    <div class="rs-bar"><i style="width:${Math.round(confianca)}%"></i></div>
    ${objetivos || '<div class="rs-dim">Sem objectivos definidos para este clube.</div>'}`;
}
function rsDivisaoSub(club) {
  return club.divisaoAtual === "placard" ? "1.ª Divisão" : club.divisaoAtual === "ok-liga" ? "OK Liga (Espanha)" : club.divisaoAtual === "serie-a1" ? "Serie A1 (Itália)"
    : club.divisaoAtual === "2div" ? `2.ª Divisão · Zona ${club.zona === "norte" ? "Norte" : "Sul"}`
    : club.divisaoAtual === "ok-liga-plata" ? `OK Liga Plata (Espanha) · Zona ${club.zona === "norte" ? "Norte" : "Sur"}` : "3.ª Divisão";
}

function renderResumoDashboard(club) {
  const box = document.getElementById("resumoDash");
  if (!box || !club) return;
  const naoLidos = (state.news || []).filter(n => !n.archived && !n.read);
  const ultimo = naoLidos.length ? emailsByReadingOrder(naoLidos)[0] : null;
  const avgCond = club.players.length ? Math.round(club.players.reduce((s, p) => s + (p.condicao != null ? p.condicao : 100), 0) / club.players.length) : 100;
  const comps = rsCompeticoes(club);
  const alertas = rsAlertas(club);
  box.innerHTML = `
  <div class="rs2">
    <div class="rs2-hero">
      <div class="rs2-top">
      ${rsMailHtml(naoLidos.length, ultimo)}
      <div class="rs2-strip"><b>${escapeHtml(competitionLabel(state.userCompetitionId))}</b><span>${escapeHtml(rsDivisaoSub(club))}</span><span>Reputação <b>${club.reputacao}</b> · ${escapeHtml(clubReputationLabel(club))}</span><span>Condição do plantel <b>${avgCond}%</b></span></div>
      </div>
      ${rsProximoHtml(club)}
      ${alertas.length ? `<div class="rs2-alerts">${alertas.map(a => `<span>${escapeHtml(a)}</span>`).join("")}</div>` : ""}
    </div>
    <div class="rs2-comps">${comps.map(rsCompCardHtml).join("") || '<div class="rs2-vazio">Sem competições activas.</div>'}</div>
    <div class="rs2-bottom">
      <div class="rs-card">${rsFinancasHtml(club)}</div>
      <div class="rs-card">${rsDirecaoHtml(club)}</div>
      <div id="adeptosPanel" class="rs-card rs-adeptos balneario-panel hidden"></div>
    </div>
  </div>`;
  if (typeof renderAdeptosPanel === "function") renderAdeptosPanel();
  box.querySelectorAll(".rs-comp[data-alvo]").forEach(c => {
    const abrir = () => rsAbrirCompeticao(c.getAttribute("data-alvo"), c.getAttribute("data-tab"));
    c.addEventListener("click", abrir);
    c.addEventListener("keydown", ev => { if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); abrir(); } });
  });
  const mb = document.getElementById("rsMailBtn");
  if (mb) mb.addEventListener("click", () => setView("noticias"));
  rsFitSoon();
}

// Sem scroll: se ainda for mais alto do que o espaço, reduz o conteúdo o mínimo (mín. 0,9).
let rsFitRaf = 0;
function rsFit() {
  const v = document.getElementById("viewClube"), box = document.getElementById("resumoDash");
  if (!v || !box || v.classList.contains("hidden")) return;
  box.style.zoom = "";
  let z = 1;
  for (let i = 0; i < 4; i++) {
    const over = v.scrollHeight - v.clientHeight;
    if (over <= 0) break;
    const alvo = Math.max(v.clientHeight < 560 ? 0.8 : 0.9, z * (v.clientHeight - 6) / v.scrollHeight);
    if (Math.abs(alvo - z) < 0.002) break;
    z = alvo; box.style.zoom = String(z);
  }
}
function rsFitSoon() { if (rsFitRaf) return; rsFitRaf = requestAnimationFrame(() => { rsFitRaf = 0; rsFit(); }); }
(function () {
  const ligar = () => {
    const v = document.getElementById("viewClube"); if (!v) return;
    new MutationObserver(rsFitSoon).observe(v, { attributes: true, attributeFilter: ["class"] });
    const box = document.getElementById("resumoDash");
    if (box) new MutationObserver(rsFitSoon).observe(box, { childList: true, subtree: true });
    window.addEventListener("resize", rsFitSoon);
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", ligar); else ligar();
})();

// Pelo menos uma vez por semana de jogo, ao regressar de processar com "Continuar", abre-se o
// Resumo (a menos que haja um jogo ao vivo ou uma janela aberta à espera de decisão).
function rsVoltarAoResumoSemanal() {
  try {
    const t = new Date(state.currentDate).getTime();
    if (state.activeView === "clube") { state.resumoVisitaData = t; return; }
    if (state.resumoVisitaData == null) { state.resumoVisitaData = t; return; }
    if (t - state.resumoVisitaData < 7 * 86400000) return;
    if (state.activeView === "jogo" || state.pendingPostMatchCtx || (state.match && !state.match.finished)) return;
    if (document.querySelector(".modal-overlay:not(.hidden)")) return;
    setView("clube");
  } catch (e) { /* opcional */ }
}

// Clicar numa competição do Resumo abre a respectiva classificação ou quadro de eliminatórias.
function rsAbrirCompeticao(alvo, tab) {
  if (!alvo) return;
  state.viewedCompetitionId = alvo;
  setView("competicoes");
  if (tab) { const b = document.querySelector('#viewCompeticoes .tab-btn[data-tab="' + tab + '"]'); if (b) b.click(); }
}
