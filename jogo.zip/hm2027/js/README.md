# Estrutura do motor (js/)

O motor deixou de estar concentrado num único ficheiro gigante. O código-fonte
está agora dividido por área funcional em `src/`, e o `app.js` que o jogo
carrega é **gerado automaticamente** a partir desses módulos.

```
js/
├── app.js          ← gerado, não editar diretamente
├── build.py        ← script que junta os módulos em app.js
├── README.md        ← este ficheiro
└── src/
    ├── manifest.json          (ordem de concatenação)
    ├── 01-nucleo.js            Constantes, clubes reais, geração determinística
    ├── 02-estado.js            Estado global do jogo
    ├── 03-calendario.js        Calendário (jornadas, método do círculo)
    ├── 04-financas.js          Finanças
    ├── 05-ui-navegacao.js      Navegação, plantel, importação, ficha de jogador
    ├── 06-motor-jogo.js        Escalação, força da equipa, motor de simulação
    ├── 07-playoff.js           Playoff
    ├── 08-evolucao-jogadores.js Evolução de jogadores / fim de época
    ├── 09-fluxo-epoca.js       Avanço de calendário, convocatória/escalação
    ├── 10-estatisticas.js      Classificações, equipas e estatísticas (render)
    ├── 11-guardar-carregar.js  Guardar / Carregar jogo
    └── 12-arranque.js          Arranque do jogo
```

## Como editar o motor

1. Edita o ficheiro certo dentro de `src/` (todos partilham o mesmo âmbito —
   uma única IIFE que começa em `01-nucleo.js` e fecha em `12-arranque.js`,
   por isso todas as funções e variáveis continuam visíveis entre módulos,
   exatamente como antes).
2. A partir da pasta `hm2027/`, corre:
   ```
   python3 js/build.py
   ```
3. Isto regenera `js/app.js`. O `index.html` continua a carregar só esse
   ficheiro — não é preciso mudar nada aí, nem usar `type="module"`, nem
   servidor com CORS para módulos.

## Porquê esta abordagem (e não módulos ES nativos)?

Módulos ES (`import`/`export`) trariam uma separação mais "correta" a nível de
linguagem, mas exigem `<script type="module">`, o que em muitos browsers
bloqueia o carregamento ao abrir o `index.html` diretamente como ficheiro local
(sem servidor). Esta divisão dá a mesma vantagem de manutenção (ficheiros mais
pequenos e focados) sem esse risco — continua a funcionar tal como sempre
funcionou, incluindo abrindo o `index.html` a partir do disco.


## Fase 3 - Agenda global
Agenda cronologica unica em `state.globalAgenda`, com IDs permanentes e estados `pendente`/`processado`.


## Fase 8
Transferências internas entre equipas A e B, impacto proporcional na moral e satisfação, proteção de plantéis mínimos e histórico separado por clube na mesma época.


## Fase 9
Interface completa das competições: seletor independente de competição, indicação de divisão/zona no clube e resumo visual de fim de época com campeão, promoções e descidas.


## Fase 10
Schema de gravação v10, migração automática de saves v6 a v9, validação estrutural de calendários, clubes e competições, e mensagens explícitas de compatibilidade.


## Fase 11
Painel de diagnóstico com testes de calendários 12/13/14/16 equipas, bye rotativo, integridade das três competições, plantéis, IDs, finanças, equipas A/B, migração de saves v6-v9 e simulação estrutural não destrutiva de 10 épocas.


## Correção Norte/Sul
A distribuição dos despromovidos do Placard calcula primeiro as vagas exatas de cada zona, testa todas as combinações possíveis e escolhe a solução geograficamente mais adequada que termine obrigatoriamente com 14 clubes em cada competição.

## Fase 12/13 — Contratos, mercado regulamentado, negociações e IA
Contrato completo por jogador: `salarioMensal`, `anos`, `dataInicio`, `dataFim` e `papel`
prometido no plantel (`Titular` / `Rotacao` / `Desenvolvimento`). A distribuição inicial de
duração de contrato é 70% (1 ano) / 27% (2 anos) / 3% (3 anos).

**Janela de mercado real** (`marketPeriodForDate`, em `01-nucleo.js`): mercado fechado entre
setembro e março (sem transferências imediatas entre clubes portugueses); pré-contratos
disponíveis em abril/maio para jogadores em final de contrato; defeso em junho-agosto com
transferências livres e ativação de pré-acordos.

**Negociação** (`04-financas.js`): qualquer proposta (renovação, pré-contrato ou transferência
em defeso) é avaliada por `evaluateContractOffer`/`negotiationScore`, que pondera salário vs.
valor de mercado, papel prometido, atratividade do clube e satisfação do jogador — resultando
em aceitação, contraproposta ou recusa. A UI correspondente (Central de Contratos, mercado e
ficha do jogador) é gerada dinamicamente em JS e injetada nos painéis já existentes, sem alterar
o `index.html`.

**IA de mercado**: `renewalPriorityScore` calcula uma prioridade de renovação 0-100 por jogador
(OVR, utilização, notas, titularidade, potencial, idade, moral, satisfação, massa salarial e
saúde financeira do clube), com as escalas do documento mestre (80-100 prioritária, 60-79
tentar renovar, 40-59 seletiva, 0-39 deixar terminar). `processDefesoMarket()` corre uma vez por
transição de época (dentro de `endOfSeason()`, em `08-evolucao-jogadores.js`): ativa
pré-contratos assinados, decide renovações pela prioridade da IA para todos os clubes (incluindo
o do utilizador, caso este não tenha negociado manualmente), liberta jogadores para o mercado de
jogadores livres (`state.freeAgents`) e garante os mínimos de plantel em todos os clubes
recorrendo a esse mercado. A renovação automática "simples" anterior foi removida.

Foi acrescentada satisfação ligada ao papel prometido (`applyRolePromiseSatisfaction`, corrida
mensalmente): jogadores com poucos minutos face ao papel combinado perdem satisfação; os que
jogam mais do que o esperado ganham. O save subiu para a versão 11, com migração automática dos
contratos antigos (v10 e anteriores) para o novo formato.

Ainda por implementar (Fases 14/15, conforme o plano): perfis financeiros próprios por clube,
bilheteira revista, orçamento/dívida da direção e um ecrã de defeso dedicado dia-a-dia (por
agora, o defeso é resolvido instantaneamente na transição de época).

## Fase 14/15 — Finanças realistas, Direção e Defeso próprio

**Finanças (`04-financas.js`, `CLUB_FINANCE_PROFILES`)**: perfis financeiros reais para Benfica,
Sporting, FC Porto, Barcelos, Valongo, Sanjoanense e HC Turquel (patrocinador com nome/valor
anual/objetivo desportivo, quotas de sócios, apoio municipal, capacidade e % de sócios); os
restantes clubes usam um perfil genérico escalado por divisão/reputação/massa adepta. Bilheteira
revista para ~5€ no Placard e ~3€ nas divisões inferiores, com a assistência de cada jogo a
separar sócios (sem receita de bilheteira, já pagam quota) de bilhetes pagos, influenciada por
clássicos (`isDerby`) e por jogos de playoff. Dívida acumula-se automaticamente quando o saldo
fica negativo (`addFinanceMovement`).

**Direção (nova vista "🎯 Direção", `renderDirectionPanel`)**: rácio de massa salarial com as 3
escalas do documento (`wageHealthTier`: ≤60% saudável, 60-75% atenção, >75% risco), objetivos da
época em curso (saldo positivo, massa salarial <70%, objetivo do patrocinador, uso de pelo menos
um sub-23 — `evaluateDirectionGoals`), orçamento anual projetado e histórico de avaliações
anuais por clube (`team.avaliacaoDirecao`, calculado em `recordDirectionEvaluation` no fim de
cada época, antes das estatísticas da época serem resetadas).

**Defeso próprio (`08-evolucao-jogadores.js`)**: `endOfSeason()` deixou de saltar diretamente
para a época seguinte. Agora chama `beginDefeso()`, que processa tudo (promoção/descida, prémios,
reputações, mercado de contratos/defeso, avaliação da direção) e mostra um modal-resumo
consolidado (entradas, saídas, renovações, dívida, avaliação da direção); só quando o utilizador
clica em "Avançar para a nova época" é que `finalizeNewSeason()` desenvolve os jogadores, avança
o calendário e a época efetivamente começa.

**Bug pré-existente corrigido durante os testes desta fase**: `standingsForCompetition()`
(`10-estatisticas.js`) só substituía `state.userCompetitionId`, mas `sortedStandings()` prioriza
`state.viewedCompetitionId` internamente — isto fazia com que os cálculos de classificação da
Zona Norte/Sul devolvessem sempre a tabela do Placard, partindo a liguilha de promoção (e por
vezes até `applyPromotionAndRelegation`) em praticamente qualquer jogo real. Corrigido para
substituir também `viewedCompetitionId` temporariamente.

**Validação**: para além dos diagnósticos automáticos (23 no total, incluindo 4 novos desta
fase), foi feita uma simulação completa e isolada (sem UI) de 5 épocas seguidas — fase regular,
playoff, liguilha de promoção, defeso e transição — sem perda de integridade de plantéis,
contratos ou jogadores livres.

Save subiu para a versão 12 (migração automática das finanças antigas para o novo formato).

## Fase 16 — Massa salarial inicial, empréstimos visíveis e curva de desgaste

**1. Normalização da massa salarial inicial** (`04-financas.js`): `normalizeInitialWageBill()`,
chamada uma única vez em `chooseClub()` (criação de uma carreira nova). Os salários gerados por
`generateContract` (a partir do OVR) nunca tinham qualquer relação com o limite salarial do
clube — resultado: até 290% do limite em clubes provisórios da 2ª Divisão, e 4 clubes reais do
Placard também acima de 100%. Agora, se a soma dos salários exceder uma taxa-alvo do limite
(55%-82%, contínua, ligada a `capacidadeFinanceira` — clubes mais frágeis financeiramente ficam
com uma fatia maior, clubes mais robustos com mais margem), os salários são reduzidos
proporcionalmente (nunca aumentados), preservando a hierarquia entre titulares e suplentes, com
piso de 450€ e arredondamento a 50€. Validado: nenhum dos 42 clubes acima de 85% no arranque
(pior caso 72%, média 67%).

**2. Jogadores emprestados sempre a azul** (`01-nucleo.js`): função central `playerNameHtml(player)`
— devolve o nome normal, ou (se `player.emprestimo` existir) o nome a azul com uma etiqueta
"EMPR.", via as classes CSS `.player-loaned`/`.loan-badge` (`styles.css`, com variante para o
tema CM3 em `cm3-theme.css`). Aplicada em ~23 pontos: plantel, estatísticas, convocatória,
escalação, banco/pista ao vivo, resumo de jogo (golos/assistências/cartões/expulsões), mercado,
central de contratos e mercado interno A/B. A ficha do jogador (separador "Pessoal") passou a
mostrar um bloco de Empréstimo: "Emprestado por" + regresso previsto + % salarial + papel
prometido (visto do lado do clube de destino), ou "Emprestado a" (visto do lado do proprietário).

**7/8. Curva de desgaste mais percetível, com atenuação por atributo** (`06-motor-jogo.js`):
`fitnessFactor` (fadiga viva em jogo) e `condicaoFactor` (condição persistente entre jogos)
passam a partilhar a mesma curva (`fatigueCurve`), bastante mais acentuada do que antes a partir
dos 85-90% (ex.: a 70% o fator combinado passa de ~0,81 para ~0,62). A fadiga deixou de afetar
todos os atributos por igual: um novo mapa `FATIGUE_TIER` faz os atributos físicos (velocidade,
aceleração, resistência, força, drible, desarme, reflexos, agilidade, um-para-um) sofrerem o
efeito completo, os técnicos (finalização, habilidade, posicionamento, meia-distância,
concentração) sofrerem metade, e os mentais (liderança, determinação, criatividade, bolas
paradas) ficarem quase imunes — aplicado em `teamStrength`, `onRinkStrength` e nos remates de
bola parada/penáltis. A recuperação diária (`dailyConditionRecovery`, em `09-fluxo-epoca.js`)
foi reduzida (~3,6%→2,8%/dia em vez de 4,5%→3,5%/dia), para que a fadiga acumulada ao longo de
uma época com 1 jogo/semana passe a pesar de facto, em vez de recuperar quase sempre para perto
de 100% antes do jogo seguinte.

**Correção adicional (bloqueante, fora do pedido mas necessária)**: `10-estatisticas.js`
referenciava `homeFaltasLabel`/`awayFaltasLabel`, elementos que não existem neste `index.html`
(existem `homeFaltas`/`awayFaltas`, sem "Label"). Isto fazia `renderAll()` rebentar sempre a
meio, impedindo o plantel, as finanças e as classificações de sequer serem desenhados. Corrigido
com uma verificação defensiva (`if(el) el.textContent = ...`).

Validado: recálculo dos rácios salariais de todos os 42 clubes, teste de ponta a ponta de um
empréstimo (plantel + ficha do jogador), verificação numérica da curva de fadiga e da atenuação
por atributo, confirmação da nova taxa de recuperação diária, e simulação de várias jornadas para
garantir que o motor de jogo continua estável. Os 23 diagnósticos automáticos continuam todos a
passar.

## Fase 16 (continuação) — Mercado IA-contra-IA, elegibilidade de empréstimo, Resumo/Plantel/Escalação

**3. Mercado IA-contra-IA verdadeiro** (`04-financas.js`, `processAiToAiMarket`): corre uma vez
por defeso, logo a seguir a `processDefesoMarket()`. Cada clube (exceto o do utilizador) com uma
carência de plantel tenta resolvê-la por ordem — equipa B → jogador livre → empréstimo compatível
→ compra a outro clube IA — sempre respeitando orçamento e mínimos de plantel do vendedor. Corre
uma única vez (não diariamente), com um conjunto de jogadores já movidos nessa passagem para
impedir transferências múltiplas do mesmo jogador na mesma janela. Testado: sem duplicação de
jogadores entre clubes, idempotente na mesma época, e — combinado com o `processDefesoMarket()`
que corre antes — garante sempre os mínimos de plantel mesmo em cenários extremos de carência
simultânea em vários clubes.

**4/5/6. Elegibilidade de empréstimo** (`04-financas.js`): `loanEligibilityProfile()` substitui a
regra antiga (demasiado permissiva: "jovem OU não-titular") por dois perfis reais — jovem em
papel de Rotação/Desenvolvimento a precisar de minutos, ou veterano (28+) pouco utilizado e pouco
satisfeito a tentar relançar a carreira; titulares nunca são elegíveis. `canLoanPlayer()` (usada
tanto quando a IA propõe ao utilizador como quando o utilizador propõe a um clube IA — regras
simétricas) bloqueia combinações absurdas: um clube muito maior não pede emprestado um jovem
comum a um clube pequeno (prefere equipa B, compra ou jogador livre — usada também em
`generateAiOffersForUser`, que agora só oferece empréstimo quando faz sentido, propondo compra
caso contrário); um clube muito menor não recebe emprestado um jogador de reputação ou
internacionalizações elevadas. Um jogador anónimo continua livre para sair de um clube grande
para um pequeno à procura de minutos — o caso de uso mais comum e realista — só ficando
bloqueado quando já tem alguma reputação a mais para a dimensão do destino.

**Resumo, Plantel e Escalação reorganizados** (`index.html`, `01-nucleo.js`, `05-ui-navegacao.js`,
`09-fluxo-epoca.js`): a configuração tática (estilo de jogo e agressividade) saiu do Resumo e
passou a viver no Plantel, como predefinição do clube, e também na Escalação, como decisão
específica para o próximo jogo (entre a escolha dos convocados e a confirmação). O Resumo passa a
mostrar informação e notícias: posição/pontos, forma recente, condição média do plantel, saldo do
clube, alertas (contratos a terminar, propostas recebidas, suspensos, jogadores descontentes,
empréstimos a terminar no fim da época) e as últimas 5 notícias com um botão "Ver todas as
notícias". A sincronização entre as três cópias visuais da tática (Plantel, Escalação, painel ao
vivo) ficou centralizada em `syncTacticButtonsUI()`/`setTeamTactic()`/`setTeamAggro()`, com um
único listener delegado a substituir os 4 anteriores — a escolha feita em qualquer um dos três
sítios atualiza sempre `myTeam().tactic`/`agressividadeTatica` e reflete-se de imediato nos
outros dois.

Save subiu a estrutura interna com `aiToAiMarketProcessedSeason` (idempotência do mercado IA-IA),
sem necessidade de subir a versão do schema (campo aditivo, com omissão segura em saves antigos).

Validado: regras de elegibilidade testadas uma a uma (incluindo um bug encontrado e corrigido a
meio — bloqueava também o caso normal de um jovem anónimo sair de um clube grande para um
pequeno); mercado IA-IA testado isoladamente e no fluxo real; interface Resumo/Plantel/Escalação
testada de ponta a ponta (conteúdo certo em cada vista, sincronização ao mudar tática em
qualquer um dos três sítios); e simulação completa de 5 épocas seguidas com todos os sistemas
novos ativos em cada defeso, sem perda de integridade e com os 23 diagnósticos automáticos
sempre aprovados.

## Fase A — Sistema tático 3-1/2-2 e renomeação Mentalidade/Pressão

**Renomeação real** (não só cosmética): `team.tactic` → `team.mentalidade`, `team.agressividadeTatica`
→ `team.pressao`, com os valores de pressão alinhados ao documento (`cauteloso/normal/agressivo`
→ `baixa/media/alta`). Migração automática de saves antigos em `normalizeLoadedTeams`
(`11-guardar-carregar.js`): mapeia os valores antigos, remove os campos obsoletos e define
`sistema:"3-1"` por omissão. Save subiu para a versão 15.

**Novo eixo: Sistema tático** (`3-1` ou `2-2`, `06-motor-jogo.js`):
- `systemFitScore(team, sistema)` — adequação 0-100 ao sistema, calculada a partir das posições
  (`linha`: `Avancado`/`DefesaMedio`, já existente), atributos, condição e satisfação dos
  jogadores disponíveis (excluindo suspensos e com condição muito baixa) — nunca um valor manual
  ou aleatório. Para o 3-1 pesa a qualidade do melhor AVÇ como referência, dos 3 melhores DEF/MED
  e a criatividade/posicionamento coletivos; para o 2-2 pesa os 2 melhores AVÇ, os 2 melhores
  DEF/MED e a mobilidade coletiva (velocidade/aceleração/resistência).
- `lineupCompositionFactor(outfield, sistema)` — penalização não-bloqueante (0,75-1,0) quando a
  escalação real (contagem de AVÇ vs. DEF/MED efetivamente em pista) não corresponde ao ideal do
  sistema escolhido. Aplicada em `teamStrength` e `onRinkStrength`, reduzindo ataque e defesa sem
  tocar no OVR visível dos jogadores — o motor não impede o utilizador de usar uma composição
  desajustada, só a torna menos eficaz.

**Interface reorganizada**: novo separador **"🧩 Táticas"** no menu principal, com Sistema,
Mentalidade e Pressão reunidos num único sítio, cada um com explicação curta do impacto, e as
pontuações de adequação ao 3-1 e ao 2-2 calculadas em tempo real. A Escalação voltou a ser só
Convocatória → GR → Jogadores de campo → Confirmar (a tática não fica lá). O painel ao vivo
mantém-se visualmente igual, com a análoga secção de ajustes agora com Sistema/Mentalidade/Pressão
em vez de Estilo/Pressão. Sincronização entre o separador Táticas e o painel ao vivo centralizada
em `syncTaticasUI()`/`setTeamSistema()`/`setTeamMentalidade()`/`setTeamPressao()`
(`01-nucleo.js`), com um único listener delegado (`05-ui-navegacao.js`).

Por implementar nas fases seguintes, conforme combinado: escolha e mudança de sistema pela IA
antes e durante o jogo (Fase B), substituições por perfil em vez de OVR (Fase B), e identidade
tática a condicionar as decisões do mercado IA-IA (Fase C) — por agora `team.sistema` só é
alterado manualmente pelo utilizador; os clubes IA ficam todos em "3-1" por omissão.

Validado: valores iniciais corretos (3-1/equilibrado/media), separador Táticas renderiza com as
três opções e as pontuações de adequação, Escalação confirmada sem tática, sincronização
Táticas↔painel ao vivo testada, migração de saves antigos testada valor a valor
(cauteloso→baixa, normal→media, agressivo→alta, mais o `sistema` por omissão), penalização de
composição confirmada numericamente (composição ideal = fator 1, composição desajustada = fator
0,75, com força de equipa visivelmente mais baixa), e simulação completa de 5 épocas seguidas com
o novo sistema tático ativo em todos os 42 clubes, sem erros e com os 23 diagnósticos automáticos
sempre aprovados.

## Fase B — Decisão tática da IA

**Escolha do sistema pré-jogo** (`chooseAiSistema`, `06-motor-jogo.js`): compara `systemFitScore`
para 3-1 e 2-2; só muda de sistema quando a diferença é clara (≥6 pontos em 100) — caso contrário
mantém o sistema habitual do clube, para não andar a mudar sem motivo entre jogos. Testado com
plantéis reais (todos os 42 clubes mantiveram o habitual, diferenças pequenas) e com um cenário
extremo forçado (2 avançados de elite + defesas fracas), onde mudou corretamente para 2-2.

**Escalação respeita o sistema escolhido** (`bestOutfieldForSystem`, usada em `getLineup` para
clubes IA): em vez de escalar sempre os 4 melhores OVR sem olhar à posição, escolhe os melhores
AVÇ e DEF/MED na proporção ideal do sistema (1+3 no 3-1, 2+2 no 2-2), só recorrendo aos melhores
restantes se não houver jogadores suficientes de um dos tipos. O utilizador continua a escalar
livremente os seus titulares — a penalização de composição da Fase A continua a aplicar-se-lhe
quando a escolha não bate certo com o sistema.

**Ajuste tático ao vivo** (`manageSideTactics`, chamada no mesmo ciclo que já geria a fadiga):
clubes IA passam a mentalidade ofensiva e sobem a pressão quando estão a perder perto do fim
(e podem passar de 3-1 para 2-2, se a adequação o permitir); ficam defensivos e reduzem a
pressão quando estão a proteger um resultado (podendo voltar a 3-1). Intervalo mínimo de 4
minutos entre ajustes, para não mudar de tática constantemente. Testado nos dois sentidos
(a perder 0-2 aos 40 min → ofensiva + 2-2; a ganhar 2-0 aos 45 min → defensiva + 3-1).

**Adaptação por fadiga** (`shouldSwitchToThreeOneForFatigue`): cobre o exemplo do documento —
equipa em 2-2, um avançado exausto, sem outro avançado fresco no banco mas com um DEF/MED
fresco disponível: a IA passa para 3-1 em vez de forçar um DEF/MED a jogar artificialmente como
segundo avançado. Testado e confirmado isoladamente.

**Perfis funcionais automáticos** (secção 6 do documento, `playerProfile` e funções auxiliares):
DEF/MED classificados em construtor/defensivo/móvel, AVÇ em finalizador/móvel — calculados só a
partir de atributos já existentes, sem qualquer campo novo manual. `manageSideFatigue` passou a
preferir um suplente do mesmo perfil funcional (não só da mesma linha, e não só do maior OVR)
quando decide quem entra para substituir um jogador cansado.

Por implementar na Fase C, conforme combinado: a identidade tática do clube a condicionar as
decisões do mercado IA-IA (não vender/emprestar o único AVÇ adequado ao sistema, etc.).

Validado: escolha de sistema testada com plantéis reais e extremos; escalação por sistema
confirmada a respeitar a proporção ideal; ajuste tático ao vivo confirmado nos dois sentidos
(a perder/a ganhar) e por fadiga; perfis funcionais verificados numa amostra de jogadores reais;
e simulação completa de 5 épocas seguidas (milhares de jogos simulados, todos a passar pelo
mesmo ciclo `runMatchTicks` que agora inclui a nova lógica), sem erros e com os 23 diagnósticos
automáticos sempre aprovados.

## Fase C — Identidade tática no mercado IA-contra-IA

**Carências ligadas ao sistema** (`aiSquadNeed`, `04-financas.js`): depois de cumpridos os
mínimos gerais de plantel (GR, jogadores de campo), um clube "3-1" passa a detetar falta de um
avançado de referência ou de qualquer DEF/MED construtor no plantel; um clube "2-2" passa a
detetar falta de um segundo avançado competitivo. `candidateMatchesNeed` traduz estas carências
específicas (`"AVC"`, `"CONSTRUTOR"`) na procura de candidatos certos — equipa B, jogador livre,
empréstimo ou compra — em vez de qualquer jogador de campo genérico.

**Proteção de jogadores essenciais** (`aiSystemCriticalityBlock`): antes de considerar um
jogador de outro clube-IA como candidato a empréstimo ou compra no mercado IA-contra-IA
(`tryFillAiSquadNeed`), verifica-se se essa saída deixaria o clube vendedor sem alternativa para
o seu próprio sistema — o único avançado de referência do 3-1, um dos únicos dois avançados do
2-2, ou o único DEF/MED construtor do plantel. Esses jogadores ficam automaticamente fora de
consideração nesse mercado, independentemente de tudo o resto correr a favor do negócio.

Esta proteção aplica-se apenas ao mercado automático entre clubes-IA (secção 17 do documento) —
não restringe as decisões do utilizador sobre o seu próprio plantel (dispensar, emprestar ou
vender um jogador continua a ser sempre uma escolha livre do treinador humano).

Validado: `aiSystemCriticalityBlock` testado nos três cenários (único AVÇ do 3-1, um dos dois
do 2-2, único construtor, e confirmação de que deixa de bloquear assim que existe alternativa);
teste de ponta a ponta em que um clube com carência de avançado resolveu-a junto de um terceiro
clube, enquanto o clube com o avançado essencial ao seu 3-1 o manteve intacto, mesmo sendo o
alvo mais óbvio; e simulação completa de 5 épocas seguidas com esta proteção ativa em todos os
defesos, sem perda de integridade e com os 23 diagnósticos automáticos sempre aprovados.

Com isto fecham-se as três fases do sistema tático 3-1/2-2 planeadas (A: sistema e interface: B:
decisão e adaptação da IA; C: identidade tática no mercado).

## Fase 1 (Evolução Tática) — Identidade + Familiaridade

**Identidade tática persistente** (`CLUB_TACTICAL_IDENTITY`, `04-financas.js`): sistema
principal/secundário, pressão e mentalidade preferenciais — a filosofia histórica de cada clube,
distinta da tática "ao vivo" (que continua a mudar por jogo). Perfis reais para os 7 clubes com
identidade financeira própria (Sporting: 2-2/3-1, pressão alta, ofensiva; Porto/Barcelos:
3-1/2-2, média, equilibrada; Benfica: 3-1/2-2, alta, ofensiva; Valongo/Sanjoanense/HC Turquel:
3-1/2-2, baixa, defensiva); os restantes clubes usam `genericTacticalIdentity`, derivada da
capacidade financeira. `initTacticalIdentity(team)` corre uma única vez por clube (na criação de
carreira nova ou na migração de saves antigos) e define também os valores iniciais de tática ao
vivo (`sistema`/`mentalidade`/`pressao`) a partir da identidade.

**Familiaridade tática** (`familiaridade31`/`familiaridade22`, 0-100 por clube): sistema
principal começa entre 75-90, secundário entre 40-60. Impacto no jogo (`familiaridadeFactor`,
aplicado em `teamStrength` e `onRinkStrength` junto ao fator de composição já existente): 80+ dá
um pequeno bónus de organização coletiva (até +8%), abaixo de 50 penaliza (até -12%), entre os
dois é neutro.

**Treino tático semanal** — sempre uma decisão manual do utilizador (`team.treinoTaticoEscolhido`,
selecionável no separador Táticas: Nenhum / Treinar 3-1 / Treinar 2-2), processada uma vez por
semana (`applyWeeklyTacticalTraining`, `09-fluxo-epoca.js`, junto à recuperação diária de
condição): treinar um sistema soma +0,5/semana a esse e subtrai -0,1/semana ao outro; sem
escolha, a familiaridade não muda. A IA reforça automaticamente o seu sistema principal de
identidade (`chooseAiTacticalTraining`).

**Estabilidade da IA** (`chooseAiSistema` revisto, `06-motor-jogo.js`): passou a usar a
identidade (sistema principal/secundário) como âncora, com a familiaridade a reforçar essa
estabilidade — só se desvia do sistema principal quando o secundário pontua claramente melhor
(diferença ≥10, já refletindo lesões, suspensões, condição e adversário via `systemFitScore`).
Substitui a versão da Fase B, que comparava diretamente 3-1 vs. 2-2 com um limiar mais permissivo
e sem qualquer noção de identidade ou treino.

Validado: identidade e familiaridade inicializadas corretamente nos 7 clubes reais e num clube
genérico (e nos 42 no total); treino semanal testado (sem escolha não muda nada; a treinar 2-2
sobe exatamente +0,5 e desce exatamente -0,1 por semana); `familiaridadeFactor` testado nos três
patamares e confirmado a refletir-se numa força de equipa real e mensurável; estabilidade da IA
confirmada (mantém-se sempre no sistema principal da identidade ao longo de 10 recálculos, sem
disrupção); interface do separador Táticas testada (mostra identidade, familiaridade e o
seletor de treino, e a escolha atualiza corretamente `team.treinoTaticoEscolhido`); migração de
saves antigos testada; e simulação completa de 5 épocas seguidas com tudo isto ativo, sem erros
e com os 23 diagnósticos automáticos sempre aprovados.

Por implementar, conforme combinado: Fase 2 (relatórios pré-jogo, pós-jogo e mensal do
treinador adjunto) — depende de guardar histórico de sistema/resultado por jogo, ainda não
existente.

## Fase 2 — Relatórios do Treinador Adjunto

**Histórico tático por jogo** (`recordTacticalMatchHistory`, `06-motor-jogo.js`): um registo por
clube e por jogo (sistema/mentalidade/pressão usados, resultado, golos, remates, condição final),
guardado para todos os clubes (não só o do utilizador, para que os relatórios pré-jogo possam
descrever também os adversários). Hooked em `finalizePlayerStats`, ponto único por onde passam
tanto os jogos ao vivo como a simulação rápida — por isso o histórico fica completo
independentemente de como cada jogo foi resolvido. Limite de 60 registos por clube.

**Relatório pré-jogo** (`generatePreGameReport`, `09-fluxo-epoca.js`): gerado uma única vez por
confronto (marcado no próprio objeto do jogo, para não duplicar se a convocatória for reaberta),
a partir do histórico real do adversário (sistema mais utilizado e % de utilização nos últimos
10 jogos), do seu melhor marcador e jogador em melhor forma da época, e de pontos fortes/fracos
calculados a partir da média de atributos do plantel (desarme, criatividade, velocidade,
profundidade ofensiva, dependência dos titulares). Termina com uma sugestão de sistema e pressão.

**Análise pós-jogo** (`generatePostGameReport`, `06-motor-jogo.js`): gerada logo a seguir ao
apito final, só para o clube do utilizador — resultado, sistema utilizado, pontos positivos e
negativos (remates, desgaste, erros defensivos) e uma conclusão sobre a eficácia do sistema
usado contra aquele adversário.

**Relatório tático mensal** (`generateMonthlyTacticalReport`, chamado junto a
`processMonthlyFinances`): agrega o histórico do próprio mês por sistema — % de utilização,
pontos por jogo, golos marcados/sofridos, familiaridade atual — e sugere qual sistema continuar
a desenvolver, com base no rendimento real (pontos por jogo), não no mais utilizado.

**Todos os três aparecem nas notícias** (`pushNews(..., "tatica", título)`), com título explícito
e uma nova cor de destaque (`.news-tatica`, azul, em `styles.css`/`cm3-theme.css`) para os
distinguir das restantes categorias.

Nota de transparência: as notícias têm um limite global de 200 itens (partilhado por todas as
categorias, não só a tática) — em simulações muito longas, com rajadas de atividade de mercado no
defeso, relatórios táticos mais antigos podem acabar por sair dessa janela. Os relatórios
continuam sempre a ser gerados e a aparecer no momento certo; é uma limitação pré-existente do
sistema de notícias como um todo, não desta funcionalidade em particular.

Validado: histórico tático confirmado a registar-se para ambos os clubes em cada jogo; relatório
pós-jogo testado com o texto e indicadores corretos; relatório pré-jogo testado com histórico
real forçado do próximo adversário (identificou corretamente o sistema mais usado e a
percentagem), e confirmado que não duplica ao reabrir a convocatória; relatório mensal testado a
comparar os dois sistemas corretamente (pontos por jogo, golos, familiaridade) e confirmado que
não duplica no mesmo mês; e simulação completa de 3 épocas seguidas com tudo isto ativo, sem
erros e com os 23 diagnósticos automáticos sempre aprovados.

Com isto fecham-se as duas fases da Evolução Tática combinadas (Fase 1: Identidade +
Familiaridade; Fase 2: Relatórios).

## Interação leve entre sistemas (3-1 vs. 2-2)

Adicionado por pedido explícito, depois de confirmado que não existia nenhuma relação direta
entre os sistemas dos dois lados. Continua a não haver matriz rígida ("3-1 vence 2-2") — em vez
disso, `systemMatchupModifier` (`06-motor-jogo.js`) ajusta o ataque em no máximo ±5%, só quando
os dois lados usam sistemas diferentes, a partir de confrontos de atributos concretos, exatamente
como a secção 11 do documento descrevia:

- **3-1 contra 2-2**: a circulação do 3-1 (criatividade + habilidade dos seus DEF/MED) tenta
  furar a cobertura do 2-2 adversário (posicionamento + desarme dos seus 2 DEF/MED — mais
  expostos por serem só dois).
- **2-2 contra 3-1**: a mobilidade e finalização dos AVÇ do 2-2 tentam explorar o espaço deixado
  pela dependência do 3-1 do seu avançado isolado, cuja eficácia depende do seu próprio
  posicionamento e finalização.

Contra o mesmo sistema (3-1 vs. 3-1 ou 2-2 vs. 2-2) não há qualquer ajuste — a diferença vem só
dos jogadores em confronto, tal como antes. Aplicado tanto no cálculo pré-jogo (`teamStrength`)
como no cálculo ao vivo por tick (`onRinkStrength`, usando a escalação real do adversário nesse
momento, não só a média do plantel).

Validado: sistemas iguais confirmados sem ajuste; um 3-1 com DEF/MED muito criativos contra um
2-2 com defesa fraca recebe o bónus máximo (+5%); o mesmo confronto com a defesa do 2-2 reforçada
reduz esse bónus até zero; e um 2-2 móvel contra um avançado de referência fraco no 3-1 adversário
recebe bónus na direção oposta — nunca fora do intervalo ±5%. Simulação completa de 5 épocas
seguidas com o modificador ativo em todos os jogos, sem erros e com os 23 diagnósticos
automáticos sempre aprovados.

## Fase 1+2 (Reformas e Novas Gerações) — implementadas em conjunto

**Reformas** (`processRetirements`, `retirementProbability`, `archiveRetiredPlayer` — `01-nucleo.js`,
chamado em `beginDefeso`): avaliação anual a partir dos 34 anos, combinando utilização,
titularidade, forma recente (últimas 8 notas), condição física, títulos conquistados e duração
de contrato — nunca uma idade fixa a decidir sozinha. Quando a decisão é "sim", o jogador não
desaparece — fica marcado (`player.retiringSeason = state.season+1`), joga toda a época seguinte
normalmente (convocado, titular ou suplente) e só sai do plantel na transição seguinte, indo para
`state.retiredPlayers` (nome, posição, clubes por onde passou, jogos/golos/assistências de
carreira, títulos, época de reforma). Tudo isto gera notícias (anúncio + reforma efetiva).

**Novas gerações** (`generateNewGeneration`, `generateYouthOutfield`/`generateYouthGoalkeeper`,
`01-nucleo.js`, chamado logo a seguir): sem regens — nomes sempre novos, através de
`randomPortugueseName` (nomes e apelidos portugueses comuns, combinados aleatoriamente, por
vezes com apelido duplo). Cada clube tem uma **Qualidade de Formação** (1-10) persistente —
perfis reais para Sporting (10), Benfica/Porto (9), Barcelos (6), Valongo (5); os restantes
seguem um valor genérico ligado a ter ou não equipa B e à reputação. A qualidade determina
quantos jovens de 15-17 anos surgem por época (2-6, conforme os exemplos do documento) e o teto
do seu potencial oculto (mais alto quanto melhor a formação). Clubes com equipa B recebem sempre
os jovens lá — nunca diretamente na equipa principal; clubes sem equipa B recebem-nos direto na A.

Ambos correm uma vez por transição de época, com uma passagem final de segurança
(`ensureRosterMinimumsFromFreeAgents`) para garantir que nenhuma reforma deixa um clube abaixo
dos mínimos de plantel.

**Validado**: os dois exemplos do próprio documento reproduzidos exatamente (jogador competitivo
de 36 anos → probabilidade baixa ≈1%; jogador em final de carreira de 39 anos → probabilidade
elevada ≈74%); confirmado que o jogador anunciado continua no plantel até à reforma efetiva;
histórico de reformados testado com números de carreira corretos; geração de jovens confirmada a
ir para a B ou A conforme o clube, com idade 15-17, potencial oculto e nacionalidade portuguesa
corretos; e uma **simulação de 12 épocas seguidas** (o teste de longo prazo que é o objetivo
central do documento) sem quebrar nenhum mínimo de plantel, sem duplicações, e com os 23
diagnósticos sempre aprovados.

**Nota honesta de calibração, encontrada nesta simulação longa**: ao fim de 12 épocas, a idade
média da liga desceu de ~25 para ~19 anos, com apenas 23 reformas efetivas contra 357 jogadores
gerados pela formação ainda ativos. A causa: o sistema de não-renovação de contratos das Fases
12/13 (`processDefesoMarket`) já dispensa muitos jogadores em declínio antes dos 34 anos, por isso
poucos chegam sequer a ser avaliados para reforma — o volume de entradas (jovens) acabou por não
ter um travão equivalente do lado das saídas. O sistema de reformas em si está calibrado
corretamente (os dois exemplos do documento batem certo); o desequilíbrio é uma interação
emergente com o sistema de contratos já existente, não um erro deste código. Fica como nota para
uma eventual afinação futura (ex.: tornar `renewalPriorityScore` menos agressivo a dispensar
jogadores 28-33 ainda decentes, para mais gente chegar aos 34 e o sistema de reformas fazer mais
do trabalho de renovação geracional).

## Investigação de calibração — idade média da liga (aplicada, não totalmente resolvida)

Depois de implementar Reformas + Novas Gerações, uma simulação de 12 épocas revelou que a idade
média da liga desce de forma pouco realista (~25 → ~18 anos), com muito poucas reformas efetivas
face ao volume de jovens gerados. Foram aplicadas quatro correções de calibração, cada uma válida
e testada nos seus próprios termos, mas **nenhuma resolveu sozinha o sintoma agregado** medido em
simulações completas de 12 épocas — a idade média continua a descer de forma semelhante mesmo com
as quatro ativas ao mesmo tempo:

1. **Curva de idade do `renewalPriorityScore`** — suavizada dos 30 aos 33 anos (`04-financas.js`).
2. **Curva de declínio de atributos do `developPlayer`** — suavizada dos 30 aos 32 anos, com uma
   nova fatia intermédia 33-35 (`08-evolucao-jogadores.js`).
3. **Distribuição de duração das renovações** — nova função `randomRenewalContractYears`
   (35%/40%/25%, em vez de reaplicar a distribuição inicial de 70%/27%/3% em todas as
   renovações), usada em `processDefesoMarket` e `signFreeAgentToTeam` (`01-nucleo.js`,
   `04-financas.js`). Reduziu de forma real e confirmada a **sincronização de contratos** (96% da
   liga em final de contrato simultaneamente → ~80-83%), mas não chegou ao valor teórico esperado
   em regime estável, nem alterou de forma visível a idade média agregada.
4. **Peso da utilização no `renewalPriorityScore`** — passou a comparar a utilização real com a
   expectativa do papel contratual do jogador (Titular/Rotação/Desenvolvimento), em vez de
   penalizar diretamente o número absoluto de jogos.

As quatro alterações são individualmente corretas, testadas e mantidas — nenhuma partiu
funcionalidade existente, e os 23 diagnósticos automáticos continuam sempre aprovados (confirmado
de novo numa simulação de 12 épocas com as quatro ativas ao mesmo tempo). Mas a causa de fundo do
desequilíbrio (idade média a descer ano após ano) não foi isolada com confiança — seria
necessária uma investigação mais profunda e metódica, fora do âmbito de correções pontuais, para
a identificar. Fica documentado para retomar no futuro, se e quando fizer sentido dedicar tempo a
isso.

## Correções pedidas — geração de jovens, liguilha, painel ao vivo e cores de equipamento

**1. Data de nascimento dos jovens gerados** (`makeBirthDate`, `01-nucleo.js`): usava sempre uma
data de referência fixa (1 de agosto de 2026), fazendo com que um "jovem de 16 anos" gerado em
épocas avançadas tivesse a idade recalculada incorretamente assim que `refreshPlayerAge` corria.
`makeBirthDate` passou a aceitar uma data de referência opcional; `generateYouthOutfield` e
`generateYouthGoalkeeper` passam sempre a data atual real do jogo (`state.currentDate`), a
criação do plantel inicial mantém-se inalterada (usa a referência fixa, correta nesse contexto).
Validado numa época simulada em 2033: um jovem gerado nesse ano nasce em 2016-2017, dando 15-17
anos como esperado.

**2. OVR inicial dos jovens demasiado alto**: a fórmula `8 + qualidadeFormação×0.5` dava 12-14
em academias fortes (Sporting, Benfica, Porto) — perto do nível de um profissional feito, para
alguém de 15-17 anos. Recalibrada para `6 + qualidadeFormação×0.25`, dando um intervalo muito
mais plausível (~7 em clubes fracos, ~9 nas melhores academias) — o potencial oculto continua a
ser onde a qualidade de formação realmente se nota. Confirmado numa simulação de 6 épocas: OVR
médio dos jovens estabilizou entre 8,9 e 9,6.

**3. Calendário e resultados da Liguilha de Promoção** (`renderPlayoffTab`, `07-playoff.js`): a
lógica (`state.promotionTie`) já corria corretamente, mas não havia nenhuma interface a mostrá-la.
Passa a aparecer na aba Playoff de Competições, com as duas mãos, datas, resultados (ou "por
jogar") e o vencedor assim que a liguilha termina.

**4/5. Lado esquerdo/direito no painel ao vivo, e remoção do texto "(a tua equipa)"**
(`renderPistaBanco`, `06-motor-jogo.js`): a lista da esquerda mostrava sempre "a minha equipa" e
a da direita sempre "o adversário", independentemente de se jogava em casa ou fora. Passa a
mostrar sempre a equipa da **casa** à esquerda e a de **fora** à direita — como num
marcador/pista reais — e o texto "(a tua equipa)" foi removido do título. Os botões de
substituição continuam a aparecer no sítio certo (a lógica interna já verificava
`side===ctx.userSide`, independentemente do lado onde é desenhada).

**6. Regra de cores semelhantes** (`colorDistance`, `effectiveHomeColor`, `06-motor-jogo.js`):
nova função de distância de cor "redmean" (aproximação leve e conhecida da diferença de cor
percebida pelo olho humano) aplicada ao marcador ao vivo. Quando a cor principal da equipa da
casa fica demasiado parecida com a do adversário, a casa troca automaticamente para a sua cor
secundária (ou terciária, se a secundária também colidir) — a equipa visitante mantém sempre a
sua cor principal. Validado com clubes reais: Benfica vs. Oliveirense (dois vermelhos, distância
53) dispara a troca; Sporting vs. Barcelos (verde vs. azul, distância 180) mantém as cores
originais.

Todas as seis correções foram validadas numa simulação de 6 épocas seguidas sem regressões, com
os 23 diagnósticos automáticos sempre aprovados.

**Por implementar, conforme combinado**: 3ª Divisão (descidas da 2ª/subidas da 3ª) — deixado de
fora por agora, a pedido explícito.

## Bug corrigido — perda de estado ao gravar/carregar durante o defeso

**Sintoma reportado**: depois do defeso, o botão "Continuar" normal aparecia em vez do botão de
avançar a época; os dias avançavam sem nada acontecer (nenhuma jornada); e o mercado parecia
ficar preso "aberto".

**Causa confirmada** (não relacionada com o cenário original suspeitado — o utilizador confirmou
que não gravou/carregou o jogo, nem foi despromovido): os campos que controlam o ecrã de defeso
(`inDefeso`, `isPreSeasonDefeso`, `pendingSeasonSummary`, `lastDefesoStats`,
`pendingSeasonStartDate`) **nunca eram gravados no save**, e o carregamento forçava sempre
`inDefeso=false` de forma incondicional. Um save feito a meio do defeso (mercado aberto, antes de
avançar) ficava com as divisões já atualizadas (isso já tinha acontecido antes de gravar) mas sem
o calendário/estatísticas da nova época, porque essa parte só corre quando se clica no botão de
avançar — e ao carregar, o jogo saía do defeso à força sem essa etapa alguma vez ter corrido.

Não foi possível confirmar com certeza que este bug foi a causa exata do que o utilizador
descreveu (não envolveu gravar/carregar), mas é um bug real e reprodutível que ia afetar qualquer
pessoa que gravasse o jogo durante o ecrã de defeso — um momento perfeitamente natural para o
fazer.

**Correção**: estes campos passam a ser gravados (`buildSaveObject`); ao carregar, restauram-se
tal como estavam — se ainda em defeso, o ecrã correspondente (defeso normal ou pré-época) volta a
aparecer, com o botão certo, retomando exatamente onde o utilizador tinha ficado.

Validado: cenário completo de gravar a meio do defeso (normal e pré-época) e carregar de seguida,
com uma serialização JSON real (não só cópia de objetos em memória) — confirma-se que
`state.inDefeso` se mantém, a época não avança sozinha, o modal certo volta a aparecer, e a
transição de época continua a funcionar normalmente a partir daí. Testado ao longo de 6 épocas
seguidas, com gravar/carregar a meio de cada defeso, sem qualquer erro e com os 23 diagnósticos
automáticos sempre aprovados.

## Reação da IA às tuas negociações + intensidade por divisão

**1. Clubes-IA reagem quando lhes tiras jogadores**: o mercado IA-contra-IA só corria uma vez, no
início do defeso — antes de teres oportunidade de negociar. Um empréstimo/compra feito por ti
durante essa janela (ex.: um GR do Valongo, deixando-o com só 1) nunca era visto por ninguém.
`processAiToAiMarketReactive()` (`04-financas.js`) corre a mesma lógica de sempre (equipa B →
livre → empréstimo → compra), mas sem guarda de época e chamada mesmo antes de avançares
(`finalizeNewSeason`/`finalizePreSeasonDefeso`) — já a par de tudo o que negociaste. Validado com
o cenário exato descrito: Valongo com 2 GR, emprestas um, fica com 1, avanças a época, e o
Valongo já tinha ido buscar outro GR antes de a época seguinte começar.

**2. Intensidade de jogo por divisão**: o desgaste em jogo dependia só da resistência do
jogador, sem olhar à competição. `DIVISION_INTENSITY` (`06-motor-jogo.js`): Placard = 1,0, 2ª
Divisão = 0,7 — aplicado ao desgaste por tick (`fitnessDecayPerTick`/`fitnessDecayPerTickGK`),
lido diretamente de `divisaoAtual` de cada equipa no início do jogo (`ctx.intensity`). Jogadores
com stats mais baixos aguentam-se bem ao ritmo da 2ª Divisão, mas sentem mais o desgaste se
subirem para o Placard. Validado: mesmo jogador, mesmo tempo de jogo, desgaste na 2ª Divisão
exatamente 70% do desgaste no Placard; confirmado também num jogo real de cada divisão.

Ambas validadas numa simulação de 8 épocas seguidas, sem erros e com os 23 diagnósticos
automáticos sempre aprovados.

## Correções ao mercado IA-contra-IA — distância entre clubes, esvaziamento e volume na 1ª época

**Bug crítico corrigido: um clube podia ser "assaltado" por muitos clubes diferentes na mesma
passagem** — o Benfica chegou a ficar com 8 jogadores. Cada transação individual passava a
verificação de mínimos no momento em que acontecia, mas nada olhava à soma de várias transações
"válidas" na mesma passagem. `DONOR_CAP_PER_PASS = 2` (`04-financas.js`): um clube só pode ser
fonte de empréstimo ou compra **2 vezes** por passagem, independentemente de quantos clubes
diferentes o procurem — não conta promoções da própria equipa B (movimento interno, não
esvaziamento de um clube alheio). Testado com um cenário extremo (10 clubes a precisar
simultaneamente de jogadores do Benfica): perda limitada a 2 jogadores, não dezenas.

**Limite de distância entre clubes não fazia o que devia**: só bloqueava um empréstimo
big-club→small-club quando a reputação *individual* do jogador já era ≥35 — a maioria dos
jogadores de rotação, mesmo em clubes grandes, nunca chega lá. `LOAN_APPEAL_GAP_HARD_LIMIT = 30`:
um limite absoluto, sempre aplicado, independentemente da reputação do jogador. Confirmado com
números reais: Benfica (clubAppeal 80,3) → GD CRIAR-T (43,8, gap 36,5) passa a ser bloqueado;
Benfica → HC Braga (52,8, gap 27,5) continua permitido.

**Equipas B como fonte de empréstimo**: estavam completamente excluídas do conjunto de onde se
procuram candidatos no mercado IA-contra-IA (o filtro `!equipaPrincipalId` retirava-as por
completo). Passam a poder ser fonte de empréstimo/compra para outros clubes — isentas do limite
de distância entre clubes (`ownerIsBTeam`), porque pedir um jogador emprestado a uma equipa B é
uma fonte de reforço normal, não uma "queda" de dimensão — continuam de fora do conjunto de
clubes que procuram resolver as suas próprias carências (isso continua a caber ao clube
principal, via youth generation e promoção interna).

**Volume de mercado reduzido na 1ª época**: os plantéis importados já são realistas — não fazia
sentido o mercado IA-contra-IA baralhá-los logo na primeira transição. Na passagem sazonal da 1ª
época (não na reativa às tuas próprias negociações, que continua sempre completa), só se recorre
a equipa B e jogadores livres — sem empréstimos nem compras entre clubes IA. A partir da 2ª
época, o mercado sazonal volta a correr por inteiro. Testado: 0 empréstimos/compras entre clubes
IA na transição da 1ª época; a reação a uma ação do próprio utilizador (empréstimo que deixou o
Valongo com 1 GR) continua completa mesmo nessa mesma transição.

Sobre a "notícia de promoção sem o jogador aparecer visível no plantel": revi o código da
promoção interna (equipa B → equipa A) e está correto — não encontrei um bug de dados nesse
ponto específico. O mais provável é ter sido um efeito colateral visual do esvaziamento em massa
do Benfica, já corrigido acima. Fica por resolver até haver um caso concreto e reproduzível
(nome do jogador + clube) para investigar.

Todas as correções validadas numa simulação de 8 épocas seguidas: nenhum plantel caiu abaixo de
9 jogadores em nenhuma época, sem duplicações, com os 23 diagnósticos automáticos sempre
aprovados.

## Correções acumuladas: empréstimos, ordenação, fadiga e reforma das equipas B

**Regresso de empréstimos antes das passagens de mercado**: `returnSeasonLoans()` passou a correr
logo no início de `beginDefeso`, antes de `processDefesoMarket`/`processAiToAiMarket` — um
jogador que regresse de empréstimo fica imediatamente disponível para um novo empréstimo na
mesma transição, em vez de só na época seguinte.

**Bloqueio de renovação com jogadores emprestados a ti**: três pontos de entrada corrigidos —
`proposeContract` recusa explicitamente, o cartão do jogador já não mostra "Renovar/Dispensar"
para um jogador emprestado (mostra antes uma explicação de que o contrato pertence ao clube de
origem), e a Central de Contratos (Mercado) filtra-os da lista.

**Clique no nome de um jogador emprestado (Plantel)**: `e.target.classList.contains(...)` só
reconhecia um clique exatamente no botão — como um jogador emprestado tem o nome envolvido em
`<span>` extra (para o estilo azul + etiqueta "EMPR."), clicar no nome acertava num desses spans,
não no botão, e o clique não fazia nada. Corrigido com `e.target.closest(".playername-btn")`.

**Ordenação por posição**: nova `playerPositionSortKey` (GR, DEF/MED, AVÇ), aplicada à
convocatória e à escalação, que antes mostravam os jogadores pela ordem crua do plantel.

**Fadiga recalibrada**: a curva de desgaste por minuto (`fitnessDecayPerTick`) já ultrapassava os
100% bem antes do fim de um jogo para resistências baixas (comuns em plantéis fracos,
especialmente na 2ª Divisão) — corrigida para uma curva mais suave (resistência 8 termina uma
partida normal a ~39%, resistência 14/média a ~57%, em vez de esgotar a meio do jogo). A
transição do fim do jogo para a condição física persistente deixou de ser uma cópia direta
(`condicao = __fitness`) — passa a ser uma média (35% condição anterior / 65% fim do jogo), para
travar a espiral descendente que deixava praticamente toda a gente perto de 0% ao longo de uma
época inteira em plantéis de resistência baixa.

**Reforma das equipas B** — quatro mudanças, conforme definido:
1. Removidas da lista de clubes escolhíveis no início de uma carreira nova.
2. Sem finanças próprias: partilham o mesmo objeto `financeiro` do clube principal — qualquer
   receita ou despesa da equipa B soma-se diretamente ao saldo, orçamento e massa salarial do
   clube principal, como uma linha de custo (ou receita pontual) da equipa A, nunca um orçamento
   autónomo (`initClubFinance`).
3. Sem contratações externas: excluídas de `ensureRosterMinimumsFromFreeAgents` — alimentam-se só
   da formação e das renovações de contrato (que já corriam, e continuam a correr, para todos os
   clubes sem exceção).
4. Novo separador "Equipa A / Equipa B" no Plantel (só visível para clubes com equipa B): permite
   ver e gerir o plantel da equipa B, incluindo abrir a ficha de qualquer jogador e negociar
   renovações — a equipa B do próprio clube do utilizador conta agora como "minha" para efeitos
   de gestão (`isMine`), tal como a equipa A.

Validado: equipas B confirmadas fora da seleção de clube (ambas as zonas da 2ª Divisão); objeto
financeiro partilhado confirmado (uma despesa lançada na equipa B reflete-se imediatamente no
saldo do clube principal); rede de segurança de jogadores livres confirmada a não mexer na
equipa B mesmo abaixo do mínimo; separador Equipa A/B testado (aparece só quando há equipa B,
alterna corretamente, abre o plantel certo); renovação de um jogador da própria equipa B
confirmada a funcionar (e a de um jogador de outro clube, corretamente recusada); bloqueio de
renovação com jogador emprestado confirmado nos três pontos de entrada; ordenação por posição
confirmada com um caso real (convocatória com GR/DEF-MED/AVÇ na ordem certa); fadiga confirmada
com números reais (resistência 8 → 39% no fim de um jogo normal, antes esgotava a meio).
Simulação completa de 8 épocas seguidas com tudo isto ativo, sem erros, sem duplicações, mínimos
de plantel preservados em todos os clubes, e os 23 diagnósticos automáticos sempre aprovados.

## Bug crítico corrigido: calendário corrompido na 2ª época para clubes fora do Placard

**Confirmado com um caso real** (HCP Grândola, 2ª Divisão Zona Sul): a partir da 2ª época, o jogo
ficava preso — "Continuar" só avançava a data, sem nenhuma jornada a acontecer, com o "próximo
jogo" a mostrar sempre a 1ª jornada numa data já passada.

**Causa**: `finalizeNewSeason()` regenerava sempre o calendário com as equipas do Placard
(`generateValidatedFixtures(state.competitions["placard-2026-27"].teamIds)`) e escrevia-o através
do setter `state.fixtures`, que aponta sempre para a competição do **utilizador** — se o
utilizador gerisse um clube da 2ª Divisão, isso substituía o calendário da sua própria zona por um
cheio de equipas do Placard, e a atribuição de datas (`assignFixtureDates()`, com o mesmo
problema) só acontecia para a competição do utilizador, nunca garantidamente para o Placard.
`chooseClub()` (a 1ª época) já fazia isto corretamente desde sempre — o bug estava isolado à
transição para a 2ª época em diante.

**Correção**: as três competições (Placard, 2ª Divisão Norte, 2ª Divisão Sul) passam a ser
sempre regeneradas e a ter as suas datas atribuídas diretamente, uma por uma, com as suas
próprias equipas — nunca através dos getters/setters ambíguos que só resolviam a competição onde
o utilizador estivesse.

Validado: reproduzido o bug exato (clube da Zona Sul) e confirmado corrigido — calendário da 2ª
época com as 14 equipas certas da Zona Sul, data atual a apenas 5 dias da 1ª jornada (antes:
calendário corrompido, meses de atraso), e uma jornada a ser efetivamente jogada logo a seguir.
Testado também que o cenário normal (utilizador no Placard) continua perfeito ao longo de 8
épocas, e o cenário da 2ª Divisão ao longo de 6 épocas seguidas, incluindo possíveis subidas.

## Geração de guarda-redes ligada à necessidade (equipas B)

Depois de retirar às equipas B o acesso a jogadores livres (por pedido explícito — "só
formação"), uma simulação longa mostrou o risco teórico já discutido a materializar-se: o AD
Valongo "B" chegou a ficar sem nenhum guarda-redes ao fim de algumas épocas, por azar na
distribuição aleatória (18% de hipótese por jovem gerado, com só 2-3 jovens/época em clubes de
formação mais fraca — variância suficiente para passar várias épocas sem sair nenhum).

**Correção**: se o plantel de destino (a equipa B, ou o próprio clube se não tiver equipa B) já
estiver com 1 ou menos guarda-redes, o primeiro jovem gerado nessa época é sempre guarda-redes —
os restantes continuam a seguir a distribuição normal de 18%. Continua a ser só formação, sem
qualquer contratação externa — a formação apenas "sabe" priorizar a posição em falta quando o
plantel já está mesmo aflito, tal como um clube reagiria na vida real.

Validado nos dois limiares (0 e 1 GR) isoladamente, e confirmado numa simulação completa de 6
épocas (o mesmo cenário que antes tinha revelado o problema): todas as 6 equipas B terminaram
com pelo menos 2 guarda-redes, 23/23 diagnósticos aprovados.

## Correções da auditoria de 20 épocas + regra dos 2 guarda-redes

**Regra de regulamento (hóquei em patins)**: toda a convocatória tem de incluir 2 guarda-redes.
Corrigido em dois sítios: a validação da convocatória do utilizador (`09-fluxo-epoca.js`, só
aceita menos de 2 se o plantel genuinamente não tiver 2 disponíveis — nunca bloqueia o jogo sem
solução possível) e `ensureMinimumSquad` (usado nos jogos simulados entre clubes IA), que também
passou a garantir 2 GR em vez de 1.

**Bug crítico #1 — equipas B podiam subir ao Placard e ser campeãs nacionais**: `nova
`eligiblePromotionRanking(table)` filtra equipas B antes de decidir quem sobe diretamente ou
entra na liguilha — a vaga passa sempre para o próximo clube elegível na tabela, em
`applyPromotionAndRelegation` e `maybeStartPromotionTie`. Testado com um cenário forçado (equipa
B a dominar claramente uma zona): a vaga de promoção foi corretamente para o clube seguinte.

**Bug crítico #2 — equipas B podiam ficar com 2-4 jogadores**: nova `ensureBTeamMinimums()`
(chamada em `beginDefeso`, depois da rede de segurança da equipa A), sem recorrer a mercado
externo — usa jogadores pouco utilizados da equipa A (despromoção interna) e, só depois, jovens
de emergência gerados fora do calendário normal da formação. Testado com o cenário exato da
auditoria (2 jogadores): resolvido para os mínimos (1 GR + 5 jogadores de campo).

**Bug crítico #3 — finanças partilhadas nunca descontavam o custo da equipa B (pior do que a
auditoria descrevia)**: como a equipa B partilha o objeto `financeiro` do clube principal, e
`processMonthlyFinances` marca esse objeto como "processado este mês" assim que processa a
primeira equipa do par, a segunda (a equipa B) via o mês já marcado e saía sem o seu custo
salarial ser alguma vez descontado. `monthlyWageBill` passa a agregar sempre a equipa principal
e a sua equipa B (`clubSquads`/`financialOwnerTeam`); `processMonthlyFinances` deixa de processar
equipas B como entidade independente — o custo entra sempre através do clube principal. Testado:
massa salarial agregada correta (soma exata A+B), descontada exatamente uma vez por mês, nunca
duplicada.

**Bug alto #4 — jogadores livres sem limite**: `cleanupFreeAgentPool()` (chamada em
`beginDefeso`), com reforma automática (38+ anos sempre; 36+ após 2 épocas sem clube; 34+ com OVR
baixo após 1 época) e um limite técnico ativo de 90 jogadores livres — os excedentes (mantendo
sempre os mais interessantes) são arquivados, não continuam no array operacional. Testado com 150
jogadores livres sintéticos: reduzido para 90; um jogador de 38 anos reformou-se automaticamente.

**Bugs altos #5 e #6 — prémios e reputações dependiam da competição visualizada no ecrã**:
confirmado por rasto de código que `sortedStandings()` (usada por ambas as funções) depende de
`state.viewedCompetitionId || state.userCompetitionId` — se o utilizador estivesse a ver uma
competição diferente da sua no momento da transição de época, os prémios/reputações eram
atribuídos à tabela errada, e 28 dos 42 clubes podiam nunca ter a reputação atualizada.
`awardSeasonFinances()` e `updateReputations()` passam a percorrer explicitamente as três
competições via `standingsForCompetition(comp.id)`, com escalas de prémio e impacto de reputação
diferentes por divisão (2ª Divisão: impacto reduzido a 40%). O campeão nacional passou também a
ser sempre identificado a partir do playoff do Placard especificamente, nunca de
`state.playoff` (que também dependia de onde o utilizador estivesse). Testado: as três competições
confirmadas a receber reputação e prémios corretamente mesmo com uma competição diferente
visualizada.

**Bug alto #7 — equipas B ganhavam reputação institucional como clubes autónomos**: corrigido
como consequência direta do bug #6 — `updateReputations()` ignora explicitamente equipas B
(`if(t.equipaPrincipalId) return;`). Testado: 0 equipas B com reputação alterada numa transição
de época.

Todas as correções validadas numa simulação de **15 épocas seguidas**, com verificação ativa em
cada época de: nenhuma equipa B no Placard, nenhum plantel B abaixo de 6 jogadores, nenhum plantel
B sem GR ou com menos de 5 jogadores de campo, jogadores livres sempre dentro do limite de 90 —
sem uma única falha ao longo de todas as épocas, e os 23 diagnósticos automáticos sempre
aprovados.

## Bug 7 completado + velocidade de desenvolvimento ligada às condições de treino

**Bug 7 (auditoria) — completado**: a correção anterior só tratava `updateReputations()`. Uma
segunda função separada (também no fim de época) deixava as equipas B alterarem
`capacidadeFinanceira`, `massaAdepta` e `desempenhoRecente` com base no seu próprio resultado
desportivo — exatamente "aparecem como entidades independentes em vários cálculos", tal como a
auditoria descreve. Estes quatro campos institucionais (juntando `reputacaoPontos`/`reputacao`,
já corrigidos) passam agora a pertencer sempre ao clube principal; a equipa B continua a ter
estatísticas e classificação desportiva próprias (isso é normal e desejável), só não altera
identidade institucional. Confirmado: 0 equipas B com estes campos alterados ao longo de 5 épocas.

**Velocidade de desenvolvimento ligada às condições de treino** (uma das causas de "volatilidade
competitiva excessiva" identificada na auditoria): a qualidade de formação já influenciava o
*teto* de potencial dos jovens (academias de elite dão um potencial mais alto), mas a
*velocidade* a que esse potencial se realizava era igual em qualquer clube. `developPlayer`
passa a receber as condições de treino do clube atual do jogador, aplicando um multiplicador
ligeiro (±15% no máximo) só à fase de crescimento (nunca ao declínio dos veteranos, que já tem a
sua calibração própria): Excelentes ×1,15, Muito boas ×1,08, Boas ×1,0 (neutro), Razoáveis ×0,92.
Validado estatisticamente (200 simulações independentes do mesmo jovem, para filtrar o ruído
aleatório): OVR médio após 3 épocas em condições Excelentes ficou consistentemente acima do
mesmo jovem em condições Razoáveis. Simulação de 10 épocas confirmada estável, sem erros, 23/23
diagnósticos.

Fica como próximo passo natural, se fizer sentido: repetir a simulação longa de 20 épocas da
auditoria com todas estas correções ativas, para medir com números reais quanto é que a
volatilidade competitiva já melhorou.

## Liguilha visível em qualquer competição + Final da 2ª Divisão (novo)

**Bug real corrigido: a liguilha continuava invisível apesar da correção anterior.** A causa:
`renderCompetitionView()` (10-estatisticas.js) apagava por completo o conteúdo da aba Playoff
sempre que a competição VISUALIZADA não era o Placard, substituindo-a por uma mensagem genérica
— nunca chegava a chamar `renderPlayoffTab()` (onde a liguilha estava definida) a não ser que se
estivesse especificamente a ver o Campeonato Placard. Como a liguilha e a nova Final da 2ª
Divisão são eventos *entre equipas da 2ª Divisão*, isto tornava-as invisíveis exatamente para
quem mais as queria ver — alguém a gerir ou a acompanhar um clube da 2ª Divisão. `promotionTieCard()`
e a nova `secondDivisionFinalCard()` foram extraídas para funções autónomas, chamadas sempre,
independentemente de qual competição está a ser vista no ecrã. Confirmado: ambas aparecem tanto a
ver a Zona Sul como o Placard.

**Nova competição: Final da 2ª Divisão** (1.º classificado do Norte vs. 1.º classificado do Sul,
a duas mãos) — sem promoção associada (essa vaga já é decidida pela Liguilha, entre os 2.os
classificados), só o título de campeão da 2ª Divisão e um pequeno bónus de reputação para o
vencedor ("algum prestígio"). Segue exatamente o mesmo padrão já existente da Liguilha de
Promoção: `maybeStartSecondDivisionFinal`, `finishSecondDivisionFinalIfReady`,
`recordSecondDivisionFinalResult`, `processSecondDivisionFinalForCurrentDate` (com o mesmo
critério de desempate — pontos, depois golos, depois grandes penalidades), incluindo o jogo
interativo (convocatória própria) quando o clube do utilizador está envolvido. A época só fecha
depois de esta final também estar concluída (`globalSeasonReadyToClose`). Guardado/carregado
corretamente no save.

Validado: confirmado com números reais que os participantes são mesmo o 1.º do Norte e o 1.º do
Sul; confirmado que a reputação do vencedor sobe (30→32 num teste concreto); confirmado o fluxo
interativo quando o próprio clube do utilizador está na final (abre a convocatória, tal como
qualquer outro jogo importante). Simulação de 10 épocas seguidas com tudo isto ativo, sem erros,
23/23 diagnósticos.

## Nomenclatura oficial da FPP

A pedido do utilizador, com as denominações oficiais da Federação de Patinagem de Portugal
(confirmadas por duas capturas de ecrã do site oficial), corrigidos os nomes em todo o jogo:

| Antes | Nome oficial FPP |
|---|---|
| "2.ª Divisão · Zona Norte" | **CN 2.ª Divisão Norte** |
| "2.ª Divisão · Zona Sul" | **CN 2.ª Divisão Sul** |
| "Liguilha de Promoção" | **CN 2.ª Divisão Apuramento Promoção** |
| "Final da 2.ª Divisão" | **CN 2.ª Divisão Apuramento Campeão** |
| "Quartos de Final" (Placard) | **1/4 Final** (secção) / Campeonato Placard Play Off — 1/4 Final (cabeçalho completo) |
| "Meias-Finais" (Placard) | **1/2 Final** |
| "Final" (Placard) | mantém-se "Final", com cabeçalho completo "Campeonato Placard Play Off — Final" |

Corrigido em: notícias (anúncio e resultado de cada mão, empates/desempate, título final), aba
Playoff de Competições (cabeçalhos de secção e as duas novas competições da 2ª Divisão),
seletor de competição (`COMPETITION_LABELS` e o `<select>` do ecrã de Competições), e os botões
de escolha de competição no início de uma carreira nova (também corrigidos no `index.html`, que
tinha os nomes antigos escritos diretamente e não usava `COMPETITION_LABELS`).

Validado: nenhuma menção a "Liguilha" restante em lado nenhum; nomes oficiais confirmados em
notícias, no seletor de competição, e nos botões de escolha de clube; simulação de 6 épocas
seguidas sem erros, 23/23 diagnósticos.

## CN 3.ª Divisão — implementação completa

Nova divisão, visível (não escolhível pelo utilizador — "só simulação" por agora), com clubes
reais (recolhidos do site oficial da FPP) e jogadores inventados, seguindo a estrutura oficial:

**Estrutura**: 4 zonas regulares — CN 3.ª Divisão Norte A, Norte B, Sul A (13 equipas, número
real oficial, com "bye" rotativo por jornada), Sul B (14 equipas cada) — mais duas mini-ligas de
apuramento criadas automaticamente quando as 4 zonas terminam: **CN 3.ª Divisão Apuramento
Campeão** (1.º de cada zona, todos contra todos a duas voltas, decide o título nacional, sem
promoção associada) e **CN 3.ª Divisão Apuramento Promoção** (2.º de cada zona, mesmo formato,
decide 2 das 6 vagas de subida à 2.ª Divisão).

**Subida/descida 2.ª ↔ 3.ª Divisão**: descem sempre os últimos 3 de cada zona da 2.ª Divisão (6
no total); sobem sempre os 4 vencedores de zona da 3.ª Divisão, mais os 2 primeiros do Apuramento
Promoção (6 no total) — "Sul vai para Sul, Norte vai para Norte" (uma equipa despromovida da Zona
Norte da 2.ª só pode entrar em Norte A ou Norte B da 3.ª, nunca em Sul, e vice-versa).

**Dois bugs arquiteturais reais, encontrados e corrigidos durante a validação**:

1. `team.stats` é partilhado e cumulativo entre competições — como as mesmas equipas jogam
   primeiro a fase de zona e depois o apuramento, usar `standingsForCompetition` (que lê
   `team.stats`) para as mini-ligas de apuramento dava classificações contaminadas com os
   resultados da zona somados aos do apuramento. Corrigido com uma classificação própria
   (`apuramentoStandings`) calculada diretamente dos jogos já disputados, e um *snapshot* dos
   vencedores de zona (`state.terceiraDivisaoZoneWinners`) capturado antes de qualquer jogo do
   apuramento acontecer.

2. **Deriva de tamanho ao longo de várias épocas**: como os 2 promovidos do Apuramento Promoção
   podem vir de qualquer combinação de regiões (0, 1 ou 2 do Norte), e as descidas da 2ª Divisão
   são sempre fixas (3 de cada zona), nada garantia por si só que a 2ª Divisão Norte/Sul (14/14)
   ou as regiões da 3ª Divisão (Norte=28, Sul=27) se mantivessem nesses tamanhos-alvo — o
   desequilíbrio de uma época podia compor-se com o da seguinte, indefinidamente. Corrigido com
   `rebalanceTwoWay` (corretivo técnico, aplicado a dois níveis: 2ª Divisão Norte↔Sul, e a
   região Norte↔Sul da 3ª Divisão antes de equilibrar as suas sub-zonas A/B) — testado e
   confirmado estável ao longo de 25 épocas seguidas sem nenhuma deriva.

**Escalas por divisão**: `DIVISION_FINANCE_MULT["3div"]` já existia (0,34); acrescentado
`DIVISION_INTENSITY["3div"]=0,55` (fadiga mais branda que a 2ª Divisão) e um `impactScale` de
reputação de 0,2 (metade do da 2ª Divisão). Prémios financeiros de fim de época com escalão
próprio, mais baixo que o da 2ª Divisão.

**Visibilidade**: as 4 zonas aparecem no seletor de competições do ecrã Competições (tabelas,
calendário, estatísticas — tudo navegável); as duas mini-ligas de apuramento aparecem sempre na
aba Playoff, independentemente de qual competição estiver a ser vista (mesmo princípio já
aplicado à Liguilha/Final da 2ª Divisão).

**Descoberta a registar, não corrigida** (fora do que foi pedido): confirmei que equipas B da 2ª
Divisão (ex.: FC Porto "B", Sporting CP "B") podem legitimamente descer para a 3ª Divisão se
terminarem nos últimos 3 lugares da sua zona — não há nenhuma proteção contra isto, ao contrário
da proteção que já existe contra subirem. Não mexi nisto sem confirmar se é pretendido.

Validado: 55 clubes/plantéis gerados sem colisões; estrutura das 4 zonas e das duas mini-ligas de
apuramento confirmada; subida/descida testada com números reais (vencedores de zona sempre
promovidos, "Sul para Sul, Norte para Norte" respeitado); simulação de 25 épocas seguidas com
todos os tamanhos de competição estáveis (97 clubes ativos, sem duplicados, sem deriva), 23/23
diagnósticos automáticos aprovados em todas as verificações.

## Bug corrigido: reputação de jogador nunca calculada na 1ª época de uma carreira nova

**Reportado pelo utilizador**: Henrique Magalhães (34 anos, 22 títulos incluindo Mundial, Europeu
e 4x I Divisão) foi emprestado do Valongo para o APAC Tojal (um clube claramente pequeno demais
para um jogador desta dimensão) — o utilizador corretamente estranhou que isto não estivesse
bloqueado.

**Causa**: `reputacaoJogador` nunca vinha preenchido na base de dados inicial (campo ausente,
`undefined`) — só era calculado no fim de cada época (`08-evolucao-jogadores.js`) ou ao carregar
um save antigo (`11-guardar-carregar.js`, como rede de segurança de migração). Isto significava
que, durante **toda a 1ª época de qualquer carreira nova**, todos os jogadores — por mais
títulos, internacionalizações ou OVR que tivessem — eram tratados como completamente anónimos
pelas regras que dependem da reputação individual, incluindo o limite de distância entre clubes
num empréstimo (`canLoanPlayer`). Um veterano lendário como o Henrique Magalhães ficava com
`reputacaoJogador` a 0 só por o jogo ainda não ter calculado isso uma primeira vez.

**Correção**: `chooseClub()` passa a calcular `reputacaoJogador` para todos os jogadores logo no
arranque de uma carreira nova, antes de qualquer mercado ou empréstimo poder acontecer.

Validado: confirmado que o Henrique Magalhães passa a ter `reputacaoJogador=37` (acima do limiar
de 35) logo no arranque, e que o mesmo empréstimo para o Tojal fica agora corretamente bloqueado
("O clube de destino é demasiado pequeno para a reputação deste jogador"); confirmado que
jogadores genuinamente anónimos (sem títulos) continuam elegíveis para o mesmo tipo de
empréstimo; confirmado que todos os jogadores do jogo ficam com o campo preenchido (0 em falta).
Simulação de 5 épocas seguidas sem regressões, 23/23 diagnósticos.

## Empréstimos entre 1ª e 3ª Divisão + equipas B por nome fora do mercado

**Assimetria no limite de distância dos empréstimos**: reportado pelo utilizador — jogadores da
3ª Divisão a serem emprestados diretamente ao Placard, saltando a 2ª Divisão inteira. Confirmado
com números reais: o limite de distância "de baixo para cima" só se aplicava ao perfil "jovem"
(e só bloqueava se o OVR fosse baixo) — o perfil "relançamento" (veterano com pouca utilização,
a tentar relançar a carreira) não tinha nenhuma verificação de distância, em nenhuma direção.
Testado diretamente: um veterano de 31 anos da 3ª Divisão passava sem qualquer bloqueio para o
Sporting (gap de 43,5, muito acima do limite de 30). Corrigido: o mesmo limite absoluto de
distância (30) aplica-se agora a qualquer perfil na direção "de baixo para cima", não só ao
"jovem" — o mesmo veterano fica agora corretamente bloqueado, enquanto um empréstimo com um gap
menor (ex.: 2ª Divisão forte → Placard fraco, gap de 9) continua permitido.

**Equipas B por nome, incluindo a 3ª Divisão, fora do lado da procura do mercado**: os 6 clubes
originais (com `equipaPrincipalId` formalmente ligado) já não pediam emprestado nem compravam,
mas há muitas outras equipas B reais na base de dados (13 na 3ª Divisão, como "HC Braga B", "HA
Cambra B", "AD Sanjoanense B") sem essa ligação modelada, porque a equipa principal delas nem
sequer existe neste jogo. Nova `looksLikeReserveTeamName(nome)` deteta estes clubes pelo nome
oficial (termina em "B", com ou sem aspas — confirmado sem falsos positivos nem negativos nos 55
clubes da 3ª Divisão) e `isMarketPassiveTeam(team)` combina esta deteção com a ligação formal
já existente. Aplicado nos dois sítios que decidem "quem vai ao mercado pedir/comprar":
`runAiToAiMarketPass` e `generateAiOffersForUser`. Continuam a poder ser fonte de
empréstimo/compra para outros clubes (tal como as equipas B originais) — só deixam de estar do
lado de quem procura.

Validado: confirmado que um clube B por nome forçado a 0 GR não vai ao mercado resolver isso
sozinho (mas continua elegível como fonte para outro clube pedir); confirmado que a rede de
segurança de jogadores livres continua ativa para eles (nenhum clube ficou sem GR ao longo de 10
épocas). Simulação de 10 épocas seguidas sem erros, 23/23 diagnósticos.

## Bug corrigido: propostas do defeso aceitáveis com o mercado já fechado

**Reportado pelo utilizador**: com o mercado fechado (a meio da época), ainda era possível aceitar
propostas recebidas durante o defeso, concluindo a transferência fora da janela.

**Causa**: `respondToAiOffer` nunca verificava se o mercado estava aberto antes de concluir o
"aceitar" — só confirmava que a proposta ainda estava "pendente" e que havia orçamento/condições
para o negócio. Uma proposta recebida durante o defeso e não respondida (nem aceite, nem
recusada) ficava "pendente" indefinidamente, e o botão "Aceitar" continuava ativo mesmo já a
época em curso.

**Correção**: duas camadas — `expirePendingAiOffers()` marca automaticamente como "expirada"
qualquer proposta ainda pendente ou em contraproposta no momento exato em que o defeso termina
(chamado nos dois pontos onde isso acontece: transição de época normal e pré-época da 1ª
carreira); e `respondToAiOffer` passa também a recusar diretamente um "aceitar" se o mercado não
estiver em período de defeso, como travão adicional independente da expiração automática.

Validado: reproduzido o cenário exato (proposta criada durante o defeso, deixada por responder,
defeso terminado) — confirmado que a proposta expira automaticamente; confirmado que uma
tentativa direta de aceitar uma proposta pendente com o mercado fechado é recusada com a
mensagem correta. Simulação de 8 épocas seguidas sem regressões, 23/23 diagnósticos.

## Bug corrigido: clubes da 3ª Divisão a comprar jogadores do plantel principal do Sporting

**Reportado pelo utilizador** (com captura de ecrã): três clubes da 3ª Divisão (Académico FC, HC
Marco, HC Penafiel) fizeram propostas de compra de 15.000€ por um jogador do plantel principal
do Sporting. Confirmei que não era uma questão de orçamento (estes clubes têm de sobra para
15.000€) — era a mesma falha de distância entre clubes que já tinha corrigido nos empréstimos,
nunca aplicada às compras.

**Causa exata**: em `generateAiOffersForUser`, quando o pedido de empréstimo falhava a
verificação de dimensão (correção anterior), o código não desistia — propunha automaticamente
uma **compra** em vez disso, sem qualquer verificação de distância nessa via. O mesmo acontecia
no mercado IA-contra-IA (`tryFillAiSquadNeed`, passo de compra entre clubes).

**Correção**: nova `purchaseGapBlocked(owner, destination)` — só bloqueia o sentido "clube
pequeno compra a um clube grande" (a mesma direção já restringida nos empréstimos); a direção
normal (clube grande compra a um clube pequeno — descoberta de talento, perfeitamente realista)
continua livre. Aplicada nos dois sítios: `generateAiOffersForUser` (deixa de cair para compra
quando nem o empréstimo nem a compra fazem sentido) e `tryFillAiSquadNeed` (exclui esses clubes
como vendedores no mercado IA-IA).

Validado: reproduzido o cenário exato do print (Sporting vs. Académico FC, gap de 43,5) —
confirmado bloqueado; gerada a oferta 50 vezes seguidas, sem nenhuma compra indevida; confirmado
que a direção inversa (Académico FC compra ao Sporting) continua livre. Simulação de 8 épocas
seguidas sem regressões, 23/23 diagnósticos.

## Empréstimo Placard → 3ª Divisão + orçamentos da 3ª Divisão corrigidos

**Reportado pelo utilizador** (com captura de notícia): Ezequiel Funes emprestado do Juventude
Pacense (Placard) ao HC Fão (3ª Divisão) — saltando a 2ª Divisão inteira.

**Causa 1 — regra em falta**: a diferença de apelo entre os dois clubes (26) estava *dentro* do
limite de 30 já existente, por isso não era bloqueada — mas o problema real não é só a
diferença numérica, é saltar uma divisão inteira sem lá passar. Nova `divisionsTooFarApart`:
um clube nunca negoceia diretamente (empréstimo ou compra) com outro a mais de uma divisão de
distância — Placard↔2ª e 2ª↔3ª continuam permitidos, Placard↔3ª fica bloqueado, seja qual for a
diferença de apelo entre os dois clubes específicos envolvidos.

**Causa 2 — bug real nos orçamentos**: `financeConfig` calculava o `saldo` (dinheiro em caixa)
sem nunca multiplicar pelo fator de divisão (`d`) — só a receita mensal (patrocínio, comercial,
etc.) é que escalava por divisão. Isto fazia com que um clube "Local" da 3ª Divisão começasse
com exatamente o mesmo saldo que um clube "Local" da 2ª Divisão, apesar de já existir um
`DIVISION_FINANCE_MULT` diferenciado (0,62 vs 0,34) — a diferença nunca chegava a aplicar-se ao
dinheiro em caixa em si. Corrigido: `saldo` passa a multiplicar também por `d`. Isto também
corrige, como efeito direto (não colateral — é a mesma fórmula, o mesmo bug), o saldo da 2ª
Divisão, que estava artificialmente alto pela mesma razão.

Adicionalmente, o multiplicador da 3ª Divisão desceu de 0,34 para 0,12, para refletir uma
realidade verdadeiramente amadora, bem distinta da 2ª Divisão (semiprofissional).

Validado com números reais: Placard (saldo médio 478.629€) → 2ª Divisão (93.744€, ~20% do
Placard) → 3ª Divisão (18.144€, ~19% da 2ª Divisão) — uma pirâmide financeira agora coerente e
claramente diferenciada em cada nível. Reproduzido o caso exato reportado (Juventude Pacense →
HC Fão) e confirmado bloqueado; confirmado que Placard↔2ª Divisão e 2ª↔3ª Divisão continuam
livres. Simulação de 8 épocas seguidas sem regressões, 23/23 diagnósticos.

## Empréstimos ainda mais restritivos: só quem realmente não vai fazer falta

**Reportado pelo utilizador**: os empréstimos continuavam muito permissivos — um clube podia
emprestar um jogador não-titular que, mesmo assim, era um dos seus melhores naquela posição (só
por acaso não estar a titular nessa altura, não porque fosse dispensável).

**Causa**: `loanEligibilityProfile` só verificava se o jogador não era titular, idade,
função contratual e utilização — nunca verificava se o clube efetivamente **precisava** dele.
Um jogador podia ser o 3º melhor jogador de campo do plantel e continuar elegível para
empréstimo, só por não estar a titular naquela semana.

**Correção**: novo `isSquadSurplus(player, team)` — ordena os jogadores da mesma posição do
clube por OVR, e só considera o jogador "supérfluo" se ficar fora do que uma convocatória
inteira precisa (2 guarda-redes, 8 jogadores de campo — as mesmas contagens já usadas na
convocatória do utilizador). Um clube só empresta quem sobra mesmo depois de cobrir uma
convocatória completa; os restantes continuam a contar como profundidade de plantel necessária,
independentemente de estarem titulares nessa semana.

Validado: testado com o plantel real do Sporting — o 3º melhor jogador de campo (dentro do que a
convocatória precisa) deixou de ser elegível para empréstimo mesmo sendo jovem/rotação; o pior
jogador de campo (claramente supérfluo) continuou elegível. Confirmado que os empréstimos
continuam a acontecer normalmente no mercado (20 numa só passagem, incluindo exatamente o
jogador mais fraco identificado no teste). Simulação de 8 épocas seguidas sem regressões, 23/23
diagnósticos.

## Taça de Portugal (masculina) — implementação completa

Nova competição de eliminação direta, aberta a todas as divisões (Placard, 2ª e 3ª), seguindo o
modelo oficial fornecido: Pré-Eliminatória (quando necessária) → 32 Avos → 16 Avos → Oitavos →
Quartos → Final Four (Meias-Finais + Final), tudo a uma só mão, com prolongamento e grandes
penalidades em caso de empate.

**Gestão do número de equipas**: 78 clubes elegíveis (97 no total, menos 19 equipas B formais)
não cabem num quadro de 64 — os 14 clubes do Placard têm sempre bye direto (interpretação
assumida, já que a regra especial dos 32 Avos só faz sentido se eles já lá estiverem garantidos);
os restantes 64 clubes da 2ª/3ª Divisão reduzem-se a 50 byes + 14 eliminatórias da
Pré-Eliminatória (28 clubes), seguindo o algoritmo fornecido.

**Regra especial dos 32 Avos**: os clubes do Placard nunca se defrontam entre si nessa ronda —
emparelhados primeiro com clubes de outras divisões, um a um; sorteio livre a partir dos 16
Avos, sem cabeças de série nem proteções.

**Equipas B excluídas** (Artigo 43.º, ponto 9 do RGHP): só as 6 equipas B formalmente ligadas a
um clube principal (`equipaPrincipalId`) — não as ~13 equipas na 3ª Divisão detetadas só pelo
nome (essas são clubes independentes no meu modelo, sem equipa principal formal, e por isso
continuam plenamente elegíveis, incluindo para subir até ao Placard).

**Três bugs reais encontrados e corrigidos durante a validação**:

1. `tacaTieWinner` não convertia o indicador relativo "home"/"away" (devolvido pelo motor de
   jogo após grandes penalidades) no ID real da equipa — produzia `state.teams["home"]`
   (inexistente) e rebentava o sorteio da ronda seguinte.
2. Os dois sítios que criam um jogo ao vivo (botão "Iniciar Jogo" e botão "Simular") só ativavam
   o prolongamento/grandes penalidades quando `state.pendingPlayoffSeries` estava definido —
   nunca verificavam `state.pendingTacaPortugalFase`. Como a Taça é sempre a uma só mão (tem de
   ficar decidida ali mesmo, ao contrário da Liguilha/Final da 2ª Divisão, que são a duas mãos),
   isto permitia empates por resolver.
3. **O mais subtil**: a verificação de elegibilidade para a Taça usava a mesma deteção de
   "equipas B por nome" que já tinha para as impedir de ir ao mercado — mas um clube cujo nome
   real termina em "B" sem nunca ter tido uma equipa principal ligada no jogo é, na prática, um
   clube independente e promovível como qualquer outro. Isto fazia-o ser incorretamente excluído
   da Taça assim que subisse ao Placard, mesmo já lá estando legitimamente — confirmado a
   acontecer numa simulação real (um clube destes chegou ao Placard na 6ª época). Corrigido para
   usar apenas a ligação formal (`equipaPrincipalId`), como o regulamento realmente define.

Validado exaustivamente: estrutura inicial do quadro (sem duplicados, sem equipas B, contas
certas); regra especial dos 32 Avos (0 jogos Placard-Placard, confirmado ao longo de 10 épocas
seguidas); percurso completo até ao campeão incluindo Final Four; fluxo interativo real do
utilizador (convocatória → escalação → simular → modal de pós-jogo); save/load; cartão de
visualização na aba Playoff (percurso do utilizador + fase atual + campeão, visível
independentemente da competição vista). Simulação de 12 épocas seguidas sem nenhum erro, 23/23
diagnósticos.

## Taça de Portugal agora visível como competição independente

**Pedido do utilizador**: a Taça de Portugal tinha de estar visível como uma competição própria,
não só um cartão secundário dentro de outra.

Corrigido: nova opção "Taça de Portugal" no seletor de competição (`competitionViewSelect`),
lado a lado com o Campeonato Placard e as restantes. Ao selecioná-la, a vista muda
automaticamente para a aba "Playoff" (onde faz sentido mostrar um quadro de eliminação direta) e
mostra o **quadro completo de todas as eliminatórias já sorteadas** — não só o percurso do
clube do utilizador (esse continua destacado a negrito dentro do quadro, mas as restantes
eliminatórias também aparecem). As restantes abas (Classificação, Calendário, Estatísticas,
Equipas) mostram uma nota curta a explicar que a Taça não tem classificação, por ser uma prova
de eliminação direta.

Efeito lateral bem-vindo desta correção: ao rever a lógica de elegibilidade, confirmei que passou
de 78 para 91 clubes elegíveis — resultado direto da correção anterior (equipas B só excluídas
pela ligação formal, não pela deteção por nome), agora refletido corretamente também na
contagem mostrada ao utilizador.

Validado: opção nova confirmada no seletor; mudança automática para a aba Playoff; quadro da
fase atual visível; trocar de volta para uma competição normal restaura corretamente a
classificação. Simulação de 6 épocas seguidas sem regressões, 23/23 diagnósticos.

## Notícias para sorteios, jornadas e resultados

**Reportado pelo utilizador**: nenhuma jornada gerava notícia — nem de sorteio do calendário,
nem de resultados. Confirmado: `recordFixtureResult`/`recordFixtureResultFor` nunca tinham
`pushNews`, e o sorteio do calendário de cada época também não.

Corrigido nos três sítios: `processRound` (jornadas da competição do utilizador — jogo do
próprio utilizador já ficava coberto pelo relatório do adjunto, agora os outros jogos da mesma
jornada também aparecem); `processCompetitionRoundFullyAI` (jornadas das restantes 6
competições, simuladas pela IA); e o sorteio do calendário de cada nova época.

Validado: confirmado com números reais — jornada 1 de todas as 7 competições gerou a notícia
correta, com o resultado de cada jogo.

## Correções críticas: apuramentos e Taça encravavam, plantéis sem idade, suspensos jogáveis

**Reportado pelo utilizador** (com capturas de ecrã): os apuramentos da 2ª Divisão não avançavam
mesmo com as datas já passadas; a Taça de Portugal fez só 2 jogos e nunca mais avançou; os
plantéis (incluindo o próprio) só mostravam OVR e posição, sem idade; jogadores suspensos não
podiam ser convocados mas conseguiam jogar na mesma; as eliminatórias da Taça deviam estar em
"Calendário & Resultados", não em "Playoff".

**Causa raiz mais grave, comum aos dois primeiros problemas**: o identificador interno de cada
jornada no sistema de agenda (`agendaEventId`) não incluía a época — "placard-2026-27::round-0"
era exatamente o mesmo id todas as épocas, porque o número da jornada volta sempre a 0. Isto
fazia com que o estado "processado" de uma jornada já jogada na época anterior contaminasse
incorretamente a mesma jornada (ainda por jogar) da época seguinte, através do mecanismo que
preserva estado ao reconstruir a agenda. Confirmado com uma simulação real: a 2ª época ficava
presa nas primeiras jornadas, sem nenhum evento pendente na agenda. Corrigido incluindo a época
no identificador.

**Bug adicional, específico da Taça de Portugal**: mesmo com a agenda corrigida, a Taça continuava
a encravar — porque várias eliminatórias partilham sempre a mesma data (é uma jornada da Taça,
tal como uma jornada normal), mas a função que processa o dia só resolvia UM jogo por chamada, e
o botão "Continuar" só a chama uma vez por dia. Corrigido para resolver todos os jogos IA-IA
dessa mesma data numa só chamada, e para continuar a processar o resto da jornada depois de o
jogo do próprio utilizador terminar (antes ficava parado à espera do dia seguinte, perdendo os
restantes jogos da mesma data para sempre).

**Idade nos plantéis**: a aba "Equipas" (usada tanto para o teu plantel como os dos adversários)
só mostrava número, nome, posição e OVR. Acrescentada a coluna de idade.

**Jogadores suspensos jogáveis**: a checkbox da convocatória aparecia corretamente desativada,
mas o valor gravado internamente podia continuar "verdadeiro" de uma convocatória anterior (se o
jogador tivesse sido selecionado antes de apanhar o cartão vermelho) — e o botão "Confirmar" lia
esse valor diretamente, sem voltar a verificar a suspensão. Corrigido em dois pontos: o próprio
estado é limpo ao reabrir a convocatória, e o botão "Confirmar" nunca inclui um suspenso,
independentemente do que estiver gravado.

**Taça de Portugal movida para "Calendário & Resultados"**: já não aparece na aba "Playoff"
(reservada ao playoff do Placard e às ligas de apuramento).

Validado: reproduzido o cenário exato reportado (simulação real através dos cliques do jogo, não
atalhos de teste) — confirmado que a 2ª época avança normalmente, que a Taça chega ao fim dentro
da mesma época, que um jogador suspenso nunca é convocável mesmo com o estado forçado a
desatualizado, e que o quadro da Taça aparece no separador certo. Duas épocas completas via o
fluxo real do jogo sem erros, 23/23 diagnósticos.

## Data nas jornadas, formato consistente da Taça, notícia combinada, e novo separador Calendário

**Reportado pelo utilizador** (com várias capturas): as jornadas não indicavam a data; as
eliminatórias da Taça apareciam como texto corrido, não no mesmo formato das divisões; a Taça
parecia estar a "somar jornadas" indevidamente; faltava um separador de calendário com os jogos
do próprio clube em todas as competições (como no Championship Manager); não apareciam
relatórios do adjunto nos jogos da Taça; e não queria uma notícia por jogo da Taça, queria uma
notícia combinada por jornada, como já existe para a liga.

**Datas nas jornadas**: `buildJornadaResultsNews`/`buildJornadaPreviewNews` passam agora a
incluir a data da jornada no título (ex.: "Jornada 1 (08/11/2026): ...").

**Formato consistente**: as 6 competições que não são a do utilizador (2ª e 3ª Divisão) ganharam
uma versão própria (`buildJornadaResultsNewsFor`) com exatamente o mesmo estilo `.jr-row` já
usado para a liga do utilizador — antes tinham um texto corrido genérico, sem estilo nem data.

**Taça de Portugal — mesmo formato, notícia combinada**: `tacaFaseHtml` (o quadro mostrado no
Calendário) passou a usar o mesmo formato `.jr-row` das divisões, com a data da eliminatória.
`tacaRecordTieResult` deixou de gerar uma notícia por jogo — agora só se gera **uma notícia
combinada por fase** (`tacaBuildFaseResultsNews`), com todos os resultados dessa fase, no mesmo
estilo e com o mesmo padrão de título das jornadas da liga.

**Relatório pré-jogo em falta na Taça**: confirmado — só era chamado no fluxo da liga
(`processRound`), nunca no da Taça. O relatório pós-jogo já funcionava (não depende da
competição). Corrigido, chamando `generatePreGameReport` também no fluxo interativo da Taça.

**Novo separador "Calendário"**: mostra todos os jogos do próprio clube (data, adversário, local,
competição, resultado) numa só lista cronológica, ao estilo Championship Manager — cobre a liga e
a Taça de Portugal (as duas competições com data fixa desde já). Os jogos de playoff/apuramento
ainda não entram aqui, porque não têm data marcada com antecedência (só se sabe a data do
próximo jogo à medida que a série avança) — posso alargar isto no futuro se fizer sentido.

Validado: confirmado que as datas aparecem nos títulos de todas as jornadas; confirmado que a
pré-eliminatória da Taça gera apenas 1 notícia de resultados combinada (não 27 uma por jogo);
confirmado o novo separador Calendário com jogos da liga e da Taça, atualizando corretamente
assim que cada ronda é sorteada. 23/23 diagnósticos, época completa via cliques reais sem erros.

## Extensão do sistema de equipas B: 13 novos pares clube-mãe ↔ equipa B

**Pedido do utilizador**: aplicar exatamente o mesmo tratamento que já existia para os 6 clubes
originais (Sporting, Benfica, Porto, Valongo, Barcelos, Oliveirense) a outros clubes que têm
equipa B na 3ª Divisão — incluindo os que têm o clube-mãe no Placard.

**Pares identificados e confirmados com o utilizador** (13 no total, por correspondência exata
de nome na base de dados):

| Clube principal | Divisão do principal | Equipa B |
|---|---|---|
| Riba d'Ave | Placard | Riba D'Ave HC "B" |
| HC Braga | Placard | HC Braga "B" |
| Juventude Pacense | Placard | J. Pacense "B" |
| AD Sanjoanense | Placard | AD Sanjoanense B |
| CH Carvalhos | 2ª Divisão | CH Carvalhos "B" |
| Ass. Académica Espinho | 2ª Divisão | AA Espinho "B" |
| HA Cambra | 2ª Divisão | HA Cambra "B" |
| Ass. Académica Coimbra | 2ª Divisão | A Académica C "B" |
| HC Turquel | 2ª Divisão | HC Turquel "B" |
| HC Mealhada | 2ª Divisão | HC Mealhada "B" |
| Sp. Alenquer e Benfica | 2ª Divisão | S Alenquer B "B" |
| AE Física D | 2ª Divisão | AE Física D "B" |
| CD Paço de Arcos | 2ª Divisão | CD Paço de Arcos "B" |

**Correção arquitetural que tornou isto simples**: `isBTeamId(id)` deixou de verificar uma lista
fixa com só os 6 originais — passou a verificar a ligação de dados diretamente
(`state.teams[id].equipaPrincipalId`). Confirmei que todos os outros mecanismos já dependentes
de equipas B (finanças partilhadas, mercado interno A↔B, exclusão do ecrã de seleção de clube,
exclusão da reputação institucional, reforço de plantel a partir da equipa A, etc.) já liam esse
mesmo campo dinamicamente, não uma lista — por isso passaram todos a funcionar automaticamente
para os 13 novos pares, sem precisar de alterações extra.

**Nova regra confirmada com o utilizador**: uma equipa B da 3ª Divisão nunca sobe à 2ª Divisão
(nunca pode coexistir com o clube principal na mesma divisão) — mas **pode legitimamente vencer a
sua zona e disputar o CN 3.ª Divisão Apuramento Campeão** (só título/prestígio, sem promoção
associada), exatamente como já acontecia com as equipas B no Placard. A vaga de subida (garantida
ao 1.º de cada zona, e a vaga do Apuramento Promoção) passa sempre para a próxima equipa
elegível (não-B) melhor colocada.

Validado: confirmados os 13 pares corretamente ligados (`equipaPrincipalId`/`equipaBId`
recíprocos); confirmado que as 19 equipas B (6 originais + 13 novas) ficam todas fora da Taça de
Portugal (78 elegíveis, não 97); testado com números reais que uma equipa B pode vencer a sua
zona e disputar o Apuramento Campeão, mas nunca aparece no Apuramento Promoção nem na lista de
subida garantida — a vaga passou corretamente para a equipa seguinte melhor colocada; confirmado
que nenhuma equipa B aparece no ecrã de seleção de clube. Simulação de 8 épocas seguidas
confirmando que nenhuma das 13 novas equipas B alguma vez saiu da 3ª Divisão, 23/23 diagnósticos.

## Colisão de calendário entre a Taça e a liga corrigida

**Reportado pelo utilizador** (com captura de ecrã): jogos da Taça de Portugal a serem marcados
para o mesmo dia dos jogos da liga (29/11/2026 tinha simultaneamente um jogo da liga e um jogo
da Taça) — impossível na realidade, uma equipa não pode jogar dois jogos no mesmo dia.

**Causa**: as datas da Taça eram calculadas por um deslocamento fixo de dias a partir de uma
data-base, sem nunca verificar em que dia da semana caíam — coincidiam, por acaso do calendário,
com os domingos que a liga usa sempre.

**Correção**: as rondas normais da Taça (Pré-Eliminatória a Quartos) passam a cair sempre à
quarta-feira; o Final Four passa a cair sempre num fim de semana fixo (sábado as meias-finais,
domingo a final). Como as datas do Final Four são conhecidas com antecedência (não dependem de
nenhum resultado), uma nova verificação (`avoidFinalFourCollisions`, chamada uma vez por época,
logo a seguir a montar o quadro da Taça) percorre todas as jornadas de todas as competições e
reagenda qualquer uma que caia nesse fim de semana específico — avançando-a para a terça-feira
seguinte (evita tanto o domingo da liga como a quarta-feira normal da Taça). Se a jornada
reagendada envolver o clube do utilizador, sai uma notícia a avisar da mudança.

Validado: confirmado que todas as fases da Taça caem sempre no dia certo da semana; confirmado
com números reais que já não há nenhuma colisão entre nenhuma jornada de nenhuma competição e
nenhuma fase da Taça, incluindo o fim de semana do Final Four; confirmada a notícia de
reagendamento quando o clube do utilizador é afetado. Época completa via cliques reais sem
erros, 23/23 diagnósticos.

## Cabeçalho do jogo ao vivo mostra a competição e a fase certas

**Reportado pelo utilizador**: o cabeçalho do jogo mostrava sempre "Época X · Jornada Y de Z" da
liga do utilizador — mesmo quando o jogo em curso era da Taça de Portugal, de uma liguilha de
apuramento, ou do playoff, casos em que essa informação estava errada ou sem sentido nenhum.

**Correção**: nova `currentMatchContextLabel()` identifica corretamente qual competição/fase
está em curso, verificando as mesmas variáveis de estado que já geriam cada tipo de jogo
especial: `pendingTacaPortugalFase` (Taça — mostra a fase exata, ex.: "Meias-Finais (Final
Four)"), `pendingPromotionTieGameIndex`/`pendingSecondDivisionFinalGameIndex` (liguilha/final de
apuramento da 2ª Divisão — mostra o número do jogo), `pendingPlayoffSeries` (playoff do Placard —
mostra a série exata, ex.: "1/2 Final 2"), com a liga normal como caso por omissão.

Validado: confirmados os cinco cenários (liga, Taça, Apuramento Promoção, Apuramento Campeão,
Playoff) diretamente, cada um mostrando o texto certo; confirmado no fluxo real de jogo sem
regressões, 23/23 diagnósticos.

## Sobreposição visual no cabeçalho do jogo + remoção da referência à época

**Reportado pelo utilizador** (com captura de ecrã): depois de a correção anterior passar a
mostrar a competição e a jornada no cabeçalho do jogo, o texto ("Época 1 · Campeonato Placard —
Jornada 1 de 26") tornou-se longo demais e quebrou para duas linhas — a caixa central do
cabeçalho tem altura fixa (72px), e o texto a quebrar ultrapassava essa altura, sobrepondo-se
visualmente às barras dos clubes ao lado.

**Correção**: removida a referência à época ("Época 1 ·") — informação desnecessária durante uma
partida, como o utilizador notou. Acrescentada também uma proteção CSS (`white-space:nowrap` +
`text-overflow:ellipsis`) na caixa central, para que, mesmo que uma etiqueta de competição mais
longa apareça no futuro, corte com reticências em vez de voltar a quebrar linha e sobrepor-se.

Validado: confirmado que o texto já não menciona a época em nenhum dos cinco cenários (liga,
Taça, apuramentos, playoff); 23/23 diagnósticos.

## Correção: informação da competição tinha desaparecido do cabeçalho

**Reportado pelo utilizador**: depois da correção anterior (remover "Época 1" + proteção CSS),
a informação da competição desapareceu por completo do cabeçalho do jogo.

**Causa**: a proteção CSS anterior (`overflow:hidden` na caixa central, para impedir a quebra de
linha de sobrepor as barras dos clubes) tinha um efeito secundário — a caixa tem altura fixa
(72px, usada também noutros cálculos de layout do ecrã de jogo), e com as três linhas empilhadas
(período, cronómetro, competição) a stack ficava ligeiramente mais alta do que a caixa, fazendo
o `overflow:hidden` cortar a terceira linha por completo em vez de a deixar transbordar
visivelmente, como acontecia antes.

**Correção**: revertido o `overflow:hidden` (e o `text-overflow:ellipsis`, que só faz sentido
com ele) — mantido o `white-space:nowrap`, que continua a impedir a quebra de linha (a causa
original da sobreposição visual), sem arriscar mexer na altura fixa da caixa, que está
interligada com vários outros cálculos de layout do ecrã de jogo.

Validado: confirmado que o texto volta a aparecer corretamente no elemento; 23/23 diagnósticos.

## Bug crítico: nunca mais era possível mover jogadores entre a equipa A e B

**Reportado pelo utilizador** (com captura de ecrã): a mensagem "Não é possível mover jogadores
durante a preparação ou realização de um jogo" aparecia sempre, mesmo fora de qualquer jogo.

**Causa**: `state.pendingFixture` (usado por este bloqueio) só era limpo num único sítio — a
migração de saves antigos. Em todos os outros pontos onde um jogo termina (liga, playoff, Taça,
liguilha/final de apuramento), `state.match` era corretamente limpo, mas `state.pendingFixture`
nunca. Isto significava que, a partir do primeiro jogo alguma vez jogado numa carreira, este
campo ficava preso para sempre, bloqueando todos os movimentos A/B pelo resto do jogo.

**Correção**: `state.pendingFixture = null` acrescentado a seguir a `cleanupPendingProvisional()`
em todos os cinco pontos onde um jogo termina, dentro de `finalizeMatchBookkeeping`.

Validado: confirmado que `pendingFixture` fica corretamente `null` depois de jogar a 1ª jornada;
confirmado com `transferPlayerBetweenAandB` que um jogador pode agora ser movido para a equipa B
depois de um jogo terminar.

## Antevisão e relatório pré-jogo só funcionavam para a liga, e apareciam no dia errado

**Reportado pelo utilizador**: a antevisão do jogo do dia seguinte só disparava para a liga,
nunca para a Taça de Portugal; e o relatório pré-jogo do treinador adjunto aparecia no próprio
dia do jogo, não na véspera.

**Correção**: `generatePreGameReport` deixou de ser chamado no dia do jogo (`processRound`) — 
passou a ser chamado na véspera, junto com `buildJornadaPreviewNews` (mantém-se uma chamada de
segurança no dia do jogo, caso a véspera seja saltada por algum motivo — a função já tem
proteção própria contra duplicação). O aviso de véspera no botão "Continuar" passou também a
verificar a eliminatória da Taça agendada para o clube do utilizador (`tacaMyTieForCurrentDate`),
com uma antevisão própria no mesmo estilo (`tacaBuildPreviewNews`).

Validado: confirmado com números reais que, na véspera de uma eliminatória dos 32 Avos da Taça,
saem tanto a antevisão como o relatório do adjunto. Época completa via cliques reais sem
regressões, 23/23 diagnósticos.

## Transferências pouco realistas, objetivo da Taça na Direção, e separador de Táticas na partida

**Reportado pelo utilizador**: era possível comprar uma estrela do Benfica para o Valongo (um
clube muito mais pequeno) e ainda por cima baixar-lhe o salário — irrealista, o jogador nunca
aceitaria. Faltava um objetivo da Taça de Portugal no separador Direção. E faltava um separador
de Táticas dentro da partida, para mexer nas substituições, sistema, mentalidade e pressão, com
o jogo a pausar/retomar sozinho ao entrar/sair.

**Transferências**: encontrei a causa exata — para transferências (ao contrário de renovações),
a exigência salarial do jogador nunca considerava o que já ganhava, só o "valor de mercado"
genérico calculado a partir da sua própria qualidade. Corrigido: agora só aceita ganhar menos do
que já ganha se o destino for claramente maior (o prestígio/ambição compensa; um clube com apelo
semelhante ou menor nunca é aceite com corte salarial). Além disso, a compra direta pelo
utilizador nunca verificava a diferença de dimensão entre clubes — a mesma regra já existente
para empréstimos (`purchaseGapBlocked`) passou a aplicar-se também aqui.

**Objetivo da Taça na Direção**: nova entrada nos objetivos anuais, com a fasquia a variar
consoante a dimensão do clube (gigantes: pelo menos Quartos-de-Final; médios: Oitavos; restantes:
passar dos 32 Avos). Equipas B não têm este objetivo (não participam na Taça, por regulamento).

**Separador de Táticas na partida**: novo separador "Táticas", com sistema/mentalidade/pressão
(movidos do separador "Jogo") e uma cópia das listas de pista/banco para fazer substituições sem
sair de lá (a lista original em "Jogadores" continua a funcionar na mesma). O jogo pausa
automaticamente ao entrar neste separador (sem interferir se já estava pausado por outro motivo,
como o intervalo) e retoma sozinho ao sair — sem precisar de clicar em "Retomar".

Validado: reproduzido o cenário exato reportado (Gonçalo Pinto, Benfica → Valongo, com corte
salarial) — confirmado bloqueado; confirmado que o objetivo da Taça aparece corretamente e as
equipas B não o têm; confirmado que o separador Táticas pausa e retoma sozinho, com conteúdo
duplicado presente e substituições a funcionar a partir dali. Época completa via cliques reais
sem regressões, 23/23 diagnósticos.

## Remates enquadrados = total de remates (bug corrigido) + novos comentários

**Reportado pelo utilizador**: nas estatísticas, "remates" e "remates enquadrados" eram sempre
iguais — não fazia sentido, muitos remates (sobretudo de meia-distância) não vão à baliza.

**Pesquisa feita antes de implementar** (regulamento oficial da FPP): confirmei as quatro regras
reais que o utilizador descreveu — bola alta dentro da área (mais de 1,5m) é falta técnica; um
golo é anulado se a bola desviar num patim (ou outra parte do corpo que não o stick) de um
atacante antes de entrar; um golo só é válido se a bola ultrapassar completamente a linha de
golo; falta anterior anula golo (prática arbitral padrão).

**Causa do bug**: `remates enquadrados = golos + defesas` — todo o remate era assumido a acabar
OU em golo OU em defesa, sem nenhuma categoria para "nem sequer testou o guarda-redes".

**Correção e adições**, todas no motor de jogo (`resolveShot`):
- Novo desfecho "remate desenquadrado" antes da decisão golo/defesa — mais provável em remates
  de meia-distância (34% vs 15% num remate normal), reduzido pela qualidade do rematador.
- Uma fração dos remates de meia-distância desenquadrados (30%) é assinalada como **bola alta**
  — falta técnica, com comentário próprio.
- **Golos de picadinha**: variante de comentário para finalizações mais técnicas, mais provável
  com jogadores de habilidade/drible elevados (≥16 de média) — não muda a probabilidade de golo,
  só o texto.
- **Golos anulados**: verificados antes de aplicar qualquer efeito do golo (raro, ~3,5% por
  golo), com uma das três razões reais do regulamento escolhida aleatoriamente para o comentário.
- **Amarelos por contestação**: nova `maybeIssueDissentCard`, reutilizando exatamente o mesmo
  mecanismo de cartões já existente (extraído para uma função partilhada `applyCardConsequences`,
  usada tanto pelas faltas físicas normais como pela contestação) — mais provável em jogadores
  com agressividade alta, disparada tipicamente a seguir a um golo anulado à própria equipa.

Também acrescentado `ctx.disallowedGoals`, para que um golo anulado continue a contar como
"remate enquadrado" nas estatísticas (a bola foi mesmo à baliza, só não foi validado).

Validado com 30 partidas simuladas: confirmado que remates enquadrados ficaram sempre abaixo do
total de remates (2038 remates vs. 1691 enquadrados); confirmadas todas as quatro variantes de
comentário a aparecer com frequências plausíveis (bola alta em 24/30 jogos, picadinha 1/30,
golo anulado 5/30, amarelo por contestação 1/30). Época completa via cliques reais sem
regressões, 23/23 diagnósticos.

## Sete novas variantes de comentário (pedidas pelo utilizador)

Implementados os pontos 3, 6, 7, 10, 11, 12 e 15 da lista de ideias sugerida:

- **3. Stick acima dos ombros**: novo motivo variável para um cartão amarelo por falta física
  (ao lado de "entrada dura", "carga irregular", etc.) — infração distinta no regulamento real.
- **6. Remate ao poste/à barra**: variante mais dramática do remate desenquadrado (22% dos
  desenquadrados que não são "bola alta"), distinta de um simples "ao lado".
- **7. Golo na recarga**: 12% das defesas passam a poder resultar num golo imediato no ressalto
  — um jogador da equipa atacante (escolhido por posicionamento/finalização) aproveita antes de
  o guarda-redes se recompor.
- **10. Bis/hat-trick**: marcador especial quando o mesmo jogador chega ao 2º ou 3º golo da
  partida.
- **11. Golo nos instantes finais de uma parte**: dramatismo extra quando faltam 90 segundos ou
  menos para o fim do período em curso.
- **12. Defesa com o corpo/patim**: mais variedade nas frases de defesa do guarda-redes, além das
  já existentes com as mãos.
- **15. Simulação (dá amarelo)**: ~6% das situações de pressão que pareciam resultar em falta são
  reveladas como simulação do atacante — o árbitro não concede a falta e mostra amarelo a quem
  tentou enganar, em vez de premiar a queda.

**Refactoring de apoio**: extraída `escalateCardType` (2º amarelo no jogo → azul; 3º azul → 
vermelho) e `applyCardConsequences` (aplicação da penalização em pista), agora partilhadas entre
faltas físicas normais, contestação e simulação — evita triplicar a mesma lógica em três sítios.

Validado com 50 partidas simuladas: todas as sete variantes confirmadas a aparecer, sem nenhum
erro (encontrado e corrigido um bug real de âmbito de variável — `attacker` estava declarado
dentro de um bloco `if` mais interior do que onde a simulação o usava). Época completa via
cliques reais sem regressões, 23/23 diagnósticos.

## Cores reais dos clubes aplicadas

O utilizador forneceu as cores reais (principal/secundária/terciária) para 83 clubes — todos os
não-Placard (14 clubes "grandes" do Placard já tinham cores reais). Confirmadas 5 correspondências
de nome com dúvida (CI Sagres, CA Feira, Escola Livre A, OH Sports — confirmadas pelo utilizador
como corretas — e ADB Campo, sem correspondência na base de dados, ignorado a pedido).

Aplicadas 82 (`scripts/apply-colors.js`, mantido no repositório para referência/futuras
atualizações), atualizando `color`/`primaryColor`/`secondaryColor`/`tertiaryColor` em
`database.json` e `database.js` (mantidos em sincronia manualmente, não há build script entre
os dois — confirmado e documentado aqui para não se perder este detalhe).

Validado: 97 clubes continuam a carregar corretamente; `effectiveHomeColor` (o sistema que evita
duas equipas jogarem com cores parecidas) testado sem erros com as novas cores reais; 23/23
diagnósticos.

**Ainda pendente** (o utilizador pediu para não implementar até as cores estarem prontas): quando
uma equipa é forçada a jogar com a cor secundária/terciária por colisão visual, a linha de
comentários da partida também deve mudar para essa mesma cor — hoje só a barra do marcador reage
a isto, o relato/feed é sempre neutro. Por fazer, mal seja pedido.

## Comentários da partida acompanham a cor efetiva da equipa (ajustada por colisão)

**Pedido do utilizador**: quando uma equipa é forçada a jogar com a cor secundária/terciária
(por colidir visualmente com o adversário), os comentários da partida têm de acompanhar essa
mesma cor — incluindo a linha de comentário mais recente, em baixo do ecrã.

**Encontrado**: já existia um mecanismo de cor por equipa no cartão de relato principal
(`applyEventTeamColours`), mas usava sempre a cor principal "crua" do clube, nunca verificando
se havia colisão com o adversário — ficava inconsistente com o marcador (que já usava a cor
efetiva via `effectiveHomeColor`). A linha "Último relato" em baixo não tinha cor nenhuma.

**Correção**: nova `effectiveColorForEventTeam(team)` — para a equipa da casa, reutiliza
exatamente a mesma lógica já usada no marcador (`effectiveHomeColor`); para a equipa de fora,
mantém sempre a cor principal (só a casa muda por colisão, tal como já acontecia). Usada agora
tanto no cartão de relato como na linha "Último relato" — as duas ficam sempre com a mesma cor.

Validado: confirmado que, com um adversário de cor semelhante (Sporting vs. Termas OC, ambos
verdes), a cor recua corretamente para a secundária, e que o cartão de relato e a linha de baixo
ficam sempre com a cor exatamente igual entre si; confirmado que, sem colisão, a cor principal
se mantém normalmente. Época completa via cliques reais sem regressões, 23/23 diagnósticos.

## Placares muito elevados corrigidos (motor de golos/recarga reformulado)

**Reportado pelo utilizador** (com captura de ecrã de um golo de recarga sem cor no cartão, e
exemplos de resultados como 16-4 e 12-4 a jogar com o Benfica): a média de golos por jogo estava
demasiado alta. Confirmei com números reais: a média geral rondava os 13-15 golos por jogo — bem
acima do que é normal em hóquei em patins.

**Investigação**: isolei a causa comparando com e sem o mecanismo de "golo na recarga" (adicionado
numa sessão anterior) — sem ele, a média já descia para ~8, confirmando que essa adição
específica estava a inflacionar bastante o marcador, por cima de uma calibração que já estava no
limite alto.

**Correção**: o utilizador forneceu uma versão do ficheiro do motor de jogo com uma reformulação
bastante mais profunda do sistema de conversão e recargas — `reboundProbabilities` substitui o
mecanismo anterior (uma probabilidade fixa de 12%) por duas fases separadas e mais realistas
(chance de bola solta, depois chance de conversão, cada uma calibrada pelos atributos reais do
rematador e do guarda-redes), a probabilidade de golo em jogo corrido ficou com limites mais
apertados (0,015–0,26/0,32 em vez de 0,02–0,6), o impacto da inferioridade numérica foi suavizado,
e os penáltis/livres diretos ganharam probabilidade decrescente por repetição no mesmo jogo (evita
séries artificiais). Adotada esta versão, mantendo intactas todas as outras adições desta
conversa (simulação, bola alta, picadinha, cartões, cor efetiva do relato, etc., todas
confirmadas presentes).

**Bug do "golo de recarga sem cor"**: confirmado — as frases de recarga nunca mencionavam o nome
da equipa, só o do marcador, e o sistema que colore o cartão de relato deteta a equipa por
procurar o nome dela no texto. Corrigido, acrescentando `${teamName(ctx,attackerSide)}` a todas
as frases de recarga.

Validado: média de golos por jogo confirmada realista em confrontos diretos (Benfica vs. Porto:
5,97; Benfica vs. Barcelos: 4,80 — antes 13,9 e 14,6); confirmado que todo o golo de recarga
menciona agora a equipa (cartão de relato colorido corretamente). Época completa via cliques
reais sem erros, 23/23 diagnósticos.

## Fluxo do dia de jogo, contexto na convocatória, e relatório pré-jogo elaborado

**Pedido do utilizador**: o menu pós-jogo deve ser sempre o Resumo; a convocatória e a
escalação têm de dizer o adversário e a competição; o dia de jogo não deve entrar logo no jogo
(o botão "Continuar" deve mudar para ir para o jogo); o relatório pré-jogo tem de ser mais
elaborado (competição, classificação do adversário, golos marcados/sofridos, estatísticas); e a
contagem regressiva na "Data Atual" tem de considerar também os jogos da Taça, dizendo sempre a
que competição se refere.

**Menu pós-jogo**: os 5 pontos onde um jogo pode terminar (liga, Taça, playoff, liguilha e final
de apuramento da 2ª Divisão) passam a chamar sempre `setView("clube")`, em vez de voltar ao
ecrã onde o utilizador estava antes de entrar no jogo.

**Dia de jogo já não entra logo no jogo**: novo `state.matchDayReady` — todos os 5 pontos de
entrada passam a só marcar "pronto a começar" em vez de abrirem a convocatória de imediato. O
botão "Continuar" muda de texto para "▶ Ir para o Jogo" (`updateContinuarBtnLabel`, chamada
sempre que a data é atualizada) e só abre a convocatória no clique seguinte.

**Contexto na convocatória/escalação**: nova `matchModalContextText()`, reaproveitando
`currentMatchContextLabel()` (já usada no cabeçalho do jogo ao vivo) — mostra sempre "Recebes/
Visitas [adversário] — [competição e jornada/fase]".

**Contagem regressiva considera a Taça**: `renderHubDate()` recolhe agora os dois candidatos
conhecidos com antecedência (jornada da liga e eliminatória da Taça do utilizador) e escolhe o
mais próximo, nomeando sempre a competição certa.

**Relatório pré-jogo muito mais elaborado**: `generatePreGameReport` ganhou dois parâmetros
(texto da competição, id da competição para efeitos de classificação) e passou a incluir:
competição e jornada/fase; local (casa/fora); classificação do adversário e distância à tua
posição (só em ligas — a Taça é eliminação direta, sem tabela); forma recente (últimos 5
resultados); golos marcados/sofridos por jogo esta época; disciplina acumulada (amarelos, azuis,
vermelhos); resultado do último confronto direto entre as duas equipas; e desfalques do
adversário por suspensão (o jogo não tem sistema de lesões persistentes, por isso fica-se pelas
suspensões).

Validado: confirmado o mecanismo `matchDayReady` completo (botão muda de texto, convocatória não
abre sozinha, abre no clique seguinte); confirmado o contexto na convocatória; confirmado o
relatório elaborado tanto para a liga (com classificação) como para a Taça (sem classificação,
com a fase certa); confirmado o menu pós-jogo sempre no Resumo mesmo vindo de outro ecrã. Época
completa via cliques reais sem regressões, 23/23 diagnósticos.

## Classificação do adversário no relatório pré-jogo: dois bugs corrigidos

**Reportado pelo utilizador** (com captura de ecrã): na Jornada 1, o relatório mostrava
"Classificação do adversário: 9.º lugar, 0 pontos" — sem sentido nenhum, já que nessa altura
todas as equipas estão empatadas a 0 pontos (a "posição" era só a ordem de desempate a parecer
uma classificação real).

**Segundo bug encontrado ao corrigir o primeiro**: mesmo quando a classificação fizesse sentido
mostrar, o código lia `rowOpp.pontos` — um campo que não existe (os pontos ficam em
`rowOpp.stats.Pts`) — por isso mostraria sempre "0 pontos", mesmo a meio da época.

**Correção**: a linha de classificação só aparece agora depois de o adversário já ter pelo menos
3 jogos disputados na competição (`rowOpp.stats.J>=3`), e usa o campo certo para os pontos.

Validado: confirmado que a Jornada 1 já não mostra classificação nenhuma; confirmado, a partir
da Jornada 5, que a classificação aparece com pontos reais (não sempre 0). 23/23 diagnósticos.

## Relatório pré-jogo: todos os campos aparecem sempre (+ assistência/palco em falta)

**Reportado pelo utilizador**: o relatório continuava a parecer simples — faltava pôr toda a
informação combinada.

**Causa**: várias linhas (classificação, forma recente, golos, disciplina, confronto direto,
desfalques, melhor marcador, jogador em forma) só apareciam quando havia dados suficientes —
cedo na carreira (poucos jogos disputados), a maioria ficava omitida, fazendo o relatório
parecer sempre pobre nas primeiras jornadas. Também tinha esquecido de implementar uma das
ideias combinadas: a nota de assistência esperada/palco.

**Correção**: todas as linhas aparecem sempre agora, com texto alternativo enquanto não há dados
suficientes (ex.: "Forma recente do adversário: sem histórico ainda", "Último confronto direto:
sem confrontos anteriores registados"), tal como já acontecia com o sistema mais utilizado.
Acrescentada a linha de assistência esperada, com base na dimensão do clube visitado.

**Bug real encontrado a meio**: `suspensosTxt` estava declarada como `const`, e o código novo
tentava reatribuir-lhe um valor — rebentava a app assim que se chegasse ao dia de jogo. Corrigido
para `let`.

Validado: confirmados os 17 campos do relatório a aparecer sempre na Jornada 1 (sem histórico
nenhum, todos com texto alternativo apropriado); confirmado que, a partir da Jornada 5+, os
mesmos campos mostram dados reais (classificação, forma, golos, disciplina, melhor marcador).
Época completa via cliques reais sem erros, 23/23 diagnósticos.

## Notícias de jornadas de outras competições sem ligação ao clube

**Reportado pelo utilizador** (com captura de ecrã): a jogar com o OC Barcelos (Placard),
apareciam notícias de resultados da CN 3.ª Divisão Sul A/B — competições sem ligação nenhuma ao
clube do utilizador.

**Causa**: as notícias de resultados das outras 6 competições (introduzidas para resolver o bug
de "nenhuma jornada gerava notícia") eram geradas para todas elas, sem verificar se tinham
alguma ligação ao clube do utilizador.

**Correção**: só gera notícia de resultados para outra competição se for lá que joga a própria
equipa B do utilizador (ex.: a jogar com o Barcelos, só a CN 2.ª Divisão Norte, onde joga o
Barcelos B, gera notícia — a 3.ª Divisão, sem ligação nenhuma, deixa de aparecer).

Validado: confirmado, a jogar com o OC Barcelos, que só aparecem notícias da 2.ª Divisão Norte
(onde joga o Barcelos B), nunca da 3.ª Divisão. Época completa via cliques reais sem regressões,
23/23 diagnósticos.

## Cor da posse de bola, separador Táticas só com a minha equipa, e confirmação de saves

**Reportado pelo utilizador** (com captura de ecrã): a barra de posse de bola tinha as cores
trocadas — não usava as cores reais dos clubes, nem respeitava a troca por equipamento
secundário/terciário; o separador Táticas mostrava as duas equipas, quando só devia mostrar a
do utilizador; pediu para aumentar os controlos de sistema/pressão (há mais espaço, sem o
adversário); e pediu confirmação de que os saves continuam a guardar tudo.

**Cor da posse de bola**: confirmei a causa — a barra tinha uma cor fixa por CSS (`#1c67df`,
azul), nunca ligada à equipa real. Corrigido para usar a mesma cor efetiva já usada no marcador
(`effectiveHomeColor` para a casa, respeitando a troca por colisão). **Bug real encontrado a
meio**: ao limpar a cor nos últimos segundos de posse (para os avisos visuais — amarelo/vermelho
— assumirem), usei `style.removeProperty("background")` (a propriedade abreviada), mas isso
deixava `background-color` preso com o valor antigo (uma sub-propriedade que se expande a partir
da abreviada e não se limpa sozinha) — os avisos ficavam sempre presos na cor da equipa. Corrigido
para usar `backgroundColor` especificamente, tanto para definir como para limpar.

**Separador Táticas só com a minha equipa**: removido o painel do adversário (HTML e IDs
`liveOppTeamTitle2`/`pistaListOpp2`/`bancoListOpp2`); a lista de substituições passou a mostrar
sempre o lado correto do próprio utilizador (`ctx.userSide`), mesmo a jogar fora — ao contrário do
painel "Jogadores", que mostra sempre casa/fora, independentemente de quem joga.

**Controlos maiores**: nova classe `.live-tactics-strip-big`, com padding e tamanho de letra bem
maiores nos botões de sistema/mentalidade/pressão, só dentro do separador Táticas.

Validado: confirmado que a cor da barra de posse muda consoante a equipa com a bola, e que os
avisos de "posse a terminar" voltam a funcionar sem ficarem presos na cor da equipa; confirmado
que o separador Táticas mostra sempre a equipa do utilizador (testado especificamente a jogar
fora) e já não tem painel do adversário; **confirmado com um teste completo de guardar e
carregar a meio de uma época** — época, jornada, saldo financeiro, plantel, fase da Taça,
notícias e `matchDayReady` (corretamente reposto a `false`) todos preservados corretamente,
23/23 diagnósticos depois de carregar. Época completa via cliques reais sem regressões.

## Comentário ilegível quando o fundo e o texto ficavam com a mesma cor

**Reportado pelo utilizador** (com captura de ecrã): a jogar com o CD Paço de Arcos, o cartão de
relato aparecia completamente em branco, sem texto visível nenhum.

**Causa**: o CD Paço de Arcos e o adversário (AJ Salesiana) têm as duas o azul como cor
principal — a cor efetiva do Paço de Arcos recuava corretamente para a secundária (branco), mas
a cor do TEXTO usava sempre a mesma secundária do clube diretamente (também branco, no caso do
Paço de Arcos) — fundo branco, texto branco, completamente ilegível.

**Correção**: tanto o cartão de relato como a linha "Último relato" passam a calcular a cor do
texto por contraste automático (preto ou branco, conforme o fundo escolhido) — a mesma lógica
já usada no marcador — nunca mais a cor secundária "crua" do clube, que podia coincidir com o
próprio fundo.

Validado: reproduzido o cenário exato (Paço de Arcos vs. AJ Salesiana) — confirmado fundo branco
com texto escuro, legível; testado exaustivamente com quase 300 pares aleatórios de clubes,
confirmando que fundo e texto nunca ficam iguais em nenhum caso. Época completa via cliques
reais sem regressões, 23/23 diagnósticos.

## Condições de treino agora contam para o apelo do clube

**Pedido do utilizador**: as condições de treino não influenciavam nada o apelo do clube
(`clubAppeal`) — só a reputação, o prestígio da competição, o desempenho recente e a capacidade
financeira contavam. Combinado adicionar um peso próprio (~8%), rebalanceando os restantes
fatores para manter a mesma hierarquia geral.

**Correção**: pesos ajustados de reputação 38%→36%, competição 32%→30%, desempenho 18%→16%,
finanças 12%→10%, com as condições de treino a entrar com 8% (Excelentes=90, Muito boas=70,
Boas=50 — o valor central de referência, tal como os outros fatores por omissão —,
Razoáveis=25, numa escala de 0 a 100).

Validado: confirmada uma diferença de ~5 pontos de apelo entre condições excelentes e razoáveis,
mantendo tudo o resto igual; confirmado que a hierarquia geral se mantém (Sporting/Benfica/Porto
continuam bem acima de um clube pequeno da 2ª Divisão). Época completa via cliques reais sem
regressões, 23/23 diagnósticos.

## Nova tática: jogar sem guarda-redes nos últimos 90 segundos

**Pedido do utilizador**: recurso de desespero real do hóquei em patins — uma equipa a perder
por 1 ou 2 golos, perto do fim, troca o guarda-redes por um jogador de linha extra, ganhando
quase toda a posse (o adversário recua a defender), mas arrisca sofrer golo fácil em contra-ataque.

**Decisões combinadas antes de implementar**: disponível para a IA (decide sozinha) e para o
utilizador (botão no separador Táticas); só nos últimos 90 segundos da parte em curso (nunca no
1º período); nunca com a equipa já em inferioridade numérica (risco a mais em cima doutro); a
IA repõe sozinha assim que sofre golo ou deixa de estar a perder por 1-2.

**Implementado**:
- `podePuxarGuardaRedes`/`pullGoalkeeper`/`restoreGoalkeeper`: tira o guarda-redes da posição,
  entra o melhor jogador de linha do banco; guarda referências exatas do GR e do suplente que
  saíram (**bug real encontrado a testar**: com um guarda-redes suplente já no banco — comum,
  a maioria dos plantéis tem 2 — repor ia buscar "o primeiro GR que encontrasse", podendo repor
  o suplente errado; corrigido guardando a referência exata).
- Reforço de ataque (+18%) enquanto joga sem guarda-redes, em `onRinkStrength`.
- Baliza vazia: em `resolveShot`, um remate que passe pelo crivo do desenquadramento (ainda pode
  sair ao lado, isso não muda) contra uma equipa sem guarda-redes é golo praticamente garantido
  (93%), sem passar pelo cálculo normal de probabilidade.
- `manageGoalkeeperPull`, ligada ao ciclo de decisões da IA em jogo (a par de `manageSideTactics`,
  já existente) — verificada a cada instante do jogo, dada a janela curta (90 segundos).
- Botão "🥅 Tirar/Repor guarda-redes" no separador Táticas, visível só quando faz sentido.

Validado: confirmadas todas as condições de elegibilidade (bloqueado no 1º período, com mais de
90s por jogar, já em inferioridade, ou a perder por 3+); confirmado o bug do guarda-redes
suplente e a correção; confirmada uma taxa de conversão de 73% por remate tentado contra baliza
vazia (a maioria dos restantes são desenquadrados, não relacionados com a baliza vazia);
confirmado que a IA usa esta tática de forma autónoma (28 em 80 jogos simulados); confirmado o
botão manual a funcionar nos dois sentidos e a esconder-se fora das condições. Época completa
via cliques reais sem regressões, 23/23 diagnósticos.

## Separador Playoff mostrava conteúdo da competição errada

**Reportado pelo utilizador**: a jogar com o CD Paço de Arcos (2ª Divisão), sem se ter
classificado para o apuramento mas a acompanhar, o separador Playoff mostrava corretamente o
apuramento. Mas ao mudar a competição apresentada para o Campeonato Placard, o separador
continuava a mostrar os apuramentos da 2ª/3ª Divisão, em vez do playoff do Placard.

**Causa raiz**: `renderPlayoffTab()` (a função do playoff do Placard) acrescentava sempre,
incondicionalmente, os cartões da liguilha de promoção, final da 2ª Divisão, e apuramento da 3ª
Divisão no final — mesmo quando a competição efetivamente vista era mesmo o Placard, onde esse
conteúdo não faz sentido nenhum aparecer (já é mostrado nos sítios certos por
`renderCompetitionView`, quando a competição vista é a 2ª ou 3ª Divisão).

**Causa secundária, mesma família de bug**: três outros pontos chamavam `renderPlayoffTab()`
diretamente sempre que o playoff do Placard avança (arranque do playoff, avanço de cada
jornada, e o refresco geral após carregar/iniciar um jogo) — sobrepondo sempre o separador com
conteúdo do Placard, mesmo que o utilizador estivesse a ver outra competição nesse preciso
momento. Substituídos por `renderCompetitionView()`, que escolhe sempre o conteúdo certo
consoante a competição atualmente selecionada.

Validado: reproduzido o cenário exato reportado (Paço de Arcos, 2ª Divisão Sul) — confirmado que
ver o Placard mostra o playoff correto (1/4 Final, sem menção a apuramento); confirmado que
voltar a alternar entre competições nunca mais mistura conteúdo; confirmado que avançar uma
jornada do playoff do Placard, estando a ver outra competição, já não sobrepõe o separador.
Época completa via cliques reais sem regressões, 23/23 diagnósticos.

## Auditoria de código (8 correções) + Final Four da Taça em campo neutro

Sessão de revisão de código pedida pelo utilizador, seguida do pedido explícito de corrigir tudo
o que fosse encontrado e de implementar a regra do recinto neutro na Final Four da Taça.

**1. Jogadores "fantasma" duplicados no mercado IA-contra-IA** (`04-financas.js`):
`signFreeAgentToTeam` nunca fazia `return true` no caminho de sucesso (só `return false` na
rejeição por crise financeira) — `activeFreeAgentUpgradeForClub` e `recoverInactiveForClub`
liam esse `undefined` como insucesso e corriam lógica de interrupção/rollback mesmo depois de o
jogador já ter sido adicionado ao plantel, chegando a duplicá-lo entre um plantel ativo e
`state.inactivePlayers`. Corrigido com `return true;` explícito. Na mesma função,
`activeFreeAgentUpgradeForClub` chamava `releasePlayerToFreeAgency(club, chosen.weak, ...)` com
os argumentos trocados (a função espera `(playerId, teamId)`, duas strings) — o jogador a
dispensar nunca saía do plantel. Corrigido para `releasePlayerToFreeAgency(chosen.weak.id,
club.id)`, com verificação do resultado.

**2. Escalação incompleta em jogos simulados (não ao vivo) do utilizador** (`06-motor-jogo.js`,
`getLineup`): só se recorria ao preenchimento automático quando nenhum jogador estava marcado
titular — com 1 a 3 titulares marcados (ex.: titular desmarcado sem substituto escolhido), a
equipa jogava o jogo inteiro em inferioridade numérica. Corrigido para completar sempre até 4
jogadores de campo com os melhores disponíveis.

**3. Play Off do Placard podia ser semeado da competição errada** (`07-playoff.js`,
`startPlayoffs`): usava `sortedStandings()` sem argumento, que lê a competição atualmente
*vista* (`state.viewedCompetitionId`), não necessariamente o Placard — a mesma classe de bug já
corrigida para a liguilha Norte/Sul, mas que tinha ficado por corrigir aqui. Corrigido para
`standingsForCompetition(placard.id)`, tal como o resto do ficheiro já fazia.

**4. Modificador tático 3-1/2-2 usava o plantel na ordem de armazenamento, não a escalação
real** (`06-motor-jogo.js`, `systemMatchupModifier`): para o lado adversário já recebia a
escalação efetivamente em jogo, mas para o próprio lado usava sempre os primeiros 4 jogadores de
campo do array `players` (ordem de importação/criação, não a escalação real). Corrigido: a
função passa a aceitar a escalação própria (`ownOutfield`) como argumento, e os dois pontos de
chamada (`teamStrength`, `onRinkStrength`) passam agora a escalação real de ambos os lados.

**5. Objetivo "Taça de Portugal" da Direção avaliado sempre pelo percurso do utilizador**
(`04-financas.js`, `tacaProgressReachedIndex`): não recebia o clube como argumento, pelo que a
avaliação da Direção de qualquer clube da IA lia sempre o (in)sucesso do utilizador na Taça, não
o seu próprio. Corrigido com um parâmetro `teamId` (com omissão segura para o utilizador, para
compatibilidade).

**6. Desenvolvimento/desempenho dos jogadores da 3ª Divisão Sul-A/Sul-B com denominador
errado** (`08-evolucao-jogadores.js`): `developPlayer`/`closeCompletedSeasonPlayerStats` usavam
sempre `state.fixtures.length` (jornadas da competição do utilizador) para qualquer jogador de
qualquer clube — as zonas Sul-A/Sul-B da 3ª Divisão têm 13 equipas (24 jornadas) em vez de 14
(26 jornadas), subestimando a utilização desses jogadores numa carreira fora dessas zonas.
Corrigido com `jornadasCompeticaoDoClube(teamId)`, que lê sempre o calendário da própria
competição do clube.

**7. Relatório pré-jogo do treinador adjunto podia duplicar-se depois de gravar/carregar**
(`09-fluxo-epoca.js` + `11-guardar-carregar.js`): a marca de deduplicação vivia só em memória
(`fixture.__preGameReportDone`) e não sobrevivia à gravação — a mesma família de bug já corrigida
uma vez para o estado do defeso. Corrigido: o campo passa a ser gravado e restaurado em
`serializeCompetitionFixtures`/`deserializeCompetitionFixtures`.

**8. Sorteio dos 32 Avos da Taça podia perder um clube silenciosamente** (`07b-taca-portugal.js`,
`tacaDraw32Avos`): com um número ímpar de clubes sobrantes (impossível com os números fixos
atuais, mas não protegido), o último clube desaparecia do quadro sem jogo nem aviso. Corrigido
com um mecanismo de bye explícito (`state.tacaPortugal.bye32avos`), que garante entrada direta
nos 16 Avos, mais um `console.error` caso este caso alguma vez ocorra.

**Final Four da Taça em campo neutro, sem vantagem de jogar em casa** (pedido explícito,
Artigo 93.º/99.º do RGHP: "os três jogos [da Final Four] realizam-se (...) no mesmo recinto de
jogo — considerado como 'neutro' ou 'neutralizado'"): o motor já assumia isto nos comentários e a
UI já mostrava "Neutro" no calendário para meias-finais e final, mas `HOME_ADV_ATTACK`/
`HOME_ADV_DEFENSE` (`06-motor-jogo.js`) eram sempre aplicados ao lado "casa", nunca desligados.
Novo parâmetro `neutralVenue`, passado por `newMatchState`/`newLiveMatchState`/
`simulateMatchToCompletion`/`startLiveMatchWithLineup` e guardado em `ctx.neutralVenue`,
desativa os dois multiplicadores tanto no cálculo pré-jogo como no cálculo ao vivo por tick.
`isTacaFinalFourFase(fase)` (`07b-taca-portugal.js`) identifica as meias-finais e a final; os
dois pontos onde se resolvem jogos da Taça (`processTacaPortugalForCurrentDate` e o arranque de
um jogo ao vivo/simulado a partir da convocatória) passam-no agora corretamente. As notícias de
sorteio e eliminação da Taça (`tacaPublishUserDrawNews`/`tacaPublishUserOutcomeNews`) foram
atualizadas para dizer "em campo neutro" nestas duas rondas, em vez de "em casa"/"fora".

Validado: as 8 correções foram confirmadas individualmente através dos mesmos ganchos de teste
usados pelos diagnósticos automáticos (`window.__HM2027_TEST__`), num browser real — incluindo
comparação direta antes/depois para cada bug (ex.: escalação com 2 titulares passa a somar 4
jogadores; `signFreeAgentToTeam` passa a devolver `true`; os seeds do Play Off do Placard
continuam corretos mesmo com outra competição selecionada; o objetivo da Taça de um clube da IA
reflete agora o seu próprio percurso; o modificador tático reage à escalação passada; a marca do
relatório pré-jogo sobrevive a um ciclo completo de gravar/carregar). O recinto neutro foi
validado isolando `newMatchState`: com `neutralVenue:true` o ataque/defesa da casa ficam
idênticos aos valores base de `teamStrength` (sem qualquer bónus); com `neutralVenue:false`
mantém-se o multiplicador de sempre (+6%/+3%). Os 48 diagnósticos automáticos (`runDiagnostics`)
foram corridos antes e depois de todas as correções: 37/48 aprovados em ambos os casos, com a
lista de falhas *exatamente* igual (11, todas em Save/Falência/Game Over, reproduzidas de forma
idêntica na versão original, sem qualquer alteração) — confirmando que nenhuma correção
introduziu uma regressão, e deixando claro que essas 11 falhas são pré-existentes e alheias a
esta sessão de correções. As duas simulações de longa duração dos diagnósticos (10 e 20 épocas
seguidas, que exercitam a Taça de Portugal e o Play Off em todas as épocas) continuam a passar
sem erros.

## Investigação das 11 falhas pré-existentes + correção real encontrada

Pedido explícito de reinvestigação das 11 falhas assinaladas como "pré-existentes" na secção
anterior (grupos Save, Falência e Game Over). A investigação anterior tinha corrido
`runDiagnostics()` sem nunca escolher um clube — um estado impossível no jogo real, já que o
botão de diagnóstico só existe dentro do menu do clube (inacessível antes de `chooseClub`), e
`state.userTeamId`/`myTeam()` ficam `null` nesse estado artificial. Repetindo os diagnósticos
depois de escolher um clube (fluxo real), as falhas caem de 11 para 1 — confirmando que 10 das
11 eram um artefacto do guião de teste, nunca reprodutíveis em jogo normal.

A 11.ª falha era real: **"Persistência da calibração: [clube]: calibração ausente"**. Causa raiz:
`ECONOMIC_CALIBRATION.version` (`04-financas.js`) tinha subido de `2` para `3` nalgum momento, e
tanto a calibração ao vivo (`initClubFinance`) como a migração de saves (`11-guardar-carregar.js`)
já tinham sido atualizadas para `3` — mas o próprio diagnóstico, em `12-arranque.js`, continuava
com o número mágico antigo (`?.versao===2`), fazendo-o falhar sempre. Corrigido substituindo os
dois números mágicos (o `2` do diagnóstico e o `3` hardcoded na migração) por referências diretas
a `ECONOMIC_CALIBRATION.version`, para nunca mais poderem divergir.

Validado: 48/48 diagnósticos aprovados depois de escolher um clube (antes: 37/48, com esta 1
falha real); sem clube escolhido continuam a reproduzir-se as mesmas 10 falhas de artefacto de
teste, agora devidamente identificadas como tal (e não mais confundidas com bugs reais do jogo).

## Supertaça António Livramento (nova competição)

Implementação completa, a partir de um roteiro detalhado fornecido pelo utilizador
(`HM2027_Roadmap_Implementacao_Supertaca_Antonio_Livramento.docx`), das 6 fases descritas: base
de calendário, competição em si, apuramento automático dos dois finalistas, história/prémios/
prestígio, integração de fluxo (IA, UI, notícias) e validação/diagnósticos. Novo módulo dedicado
`07c-supertaca.js` (inserido no `manifest.json` a seguir a `07b-taca-portugal.js`).

**Regulamento simulado**: jogo único de pré-época, sempre em campo neutro (sem vantagem de jogar
em casa — tal como a Final Four da Taça, ver secção anterior), entre o campeão nacional do
Campeonato Placard e o vencedor da Taça de Portugal da época anterior. Se o mesmo clube tiver
feito a "dobradinha" (venceu as duas provas), joga em seu lugar o finalista vencido da Taça —
regra de substituição implementada em `computeSupertacaQualification` (07c-supertaca.js).

**Calendário (Fase 1)**: a época deixa de se ancorar num "8 de novembro" fixo (`assignFixtureDatesFor`,
`01-nucleo.js`) e passa a ancorar-se em outubro: duas novas funções,
`getSecondSaturdayOfOctober(year)` e `getPlacardOpeningSunday(year)`, calculam sempre o 2.º sábado
de outubro (data da Supertaça) e o domingo imediatamente a seguir (data da Jornada 1 do
Campeonato Placard) — em vez de um dia fixo do calendário civil, é sempre uma relação entre as
duas datas que se preserva, época após época. `assignFixtureDatesFor` usa agora
`getPlacardOpeningSunday` como data-base; o resto do mecanismo (cadência semanal, folga do Natal)
mantém-se inalterado.

**Emparelhamento e apuramento automático (Fases 2/3)**: `initSupertaca(options)` monta a edição
da época — chamada em `chooseClub()` (1.ª carreira, sem época anterior: usa o par inaugural fixo
do roteiro, Benfica vs. Sporting, com `initialEditionOverride`) e em `finalizeNewSeason()` (todas
as seguintes, a partir do resumo oficial da época que terminou). Esse resumo
(`completedSummary`, capturado em `beginDefeso()`, `08-evolucao-jogadores.js`) ganhou dois campos
novos — `tacaVencedorId`/`tacaFinalistaId`, lidos de `state.tacaPortugal.campeao`/`.runnerUp`
*antes* de `initTacaPortugal()` os reiniciar para a época nova — e o próprio
`state.tacaPortugal` ganhou o campo `runnerUp` (o finalista vencido da final, calculado em
`tacaFinishFaseIfReady`), que não existia até agora. Sem dados suficientes de qualificação (ex.:
save antigo carregado a meio de carreira, sem histórico da época anterior),
`computeSupertacaQualification` devolve `null` e a Supertaça fica simplesmente por disputar
nessa época, em vez de arriscar um sorteio sem suporte no regulamento.

**História, prémios e prestígio (Fase 4)**: `supertacaAwardOutcome` atribui, uma única vez por
edição (protegido por `financasAtribuidas`/`prestigioAtribuido`, tal como `state.financePrizeAwarded`
protege os prémios de fim de época): um troféu (via `awardClubTitle`, o mesmo mecanismo do
Campeonato/Taça/2.ª Divisão — já idempotente por construção, chave competição+época), prestígio
para o vencedor (+1,5, calibrado por simulação entre o valor da Final da 2.ª Divisão, +2, e o
peso da Taça de Portugal dentro de `updateReputations`, +3 — aplicado de imediato, fora dessa
função, porque a Supertaça acontece no arranque da época, não no fecho) e um prémio financeiro a
ambos os finalistas (50.000€ ao vencedor, 20.000€ ao finalista — via `addFinanceMovement`,
categoria "Prémio de competição", tal como `awardSeasonFinances`; valores calibrados por
simulação para ficarem claramente abaixo de vencer o Campeonato ou a Taça, mas acima de uma final
sem promoção associada). Cada edição resolvida é arquivada em `state.supertaca.historico`.

**Integração de fluxo (Fase 5)**: `processSupertacaForCurrentDate` (chamado a partir de
`processPhaseFiveFinalsForCurrentDate`, tal como a Taça de Portugal e as finais da 2.ª Divisão)
resolve o jogo automaticamente (IA vs. IA, com prolongamento/grandes penalidades garantidos —
`isPlayoff:true`) quando nenhum dos dois finalistas é o clube do utilizador, ou abre a
convocatória/escalação interativa quando é. `state.pendingSupertaca` segue exatamente o mesmo
padrão de `state.pendingTacaPortugalFase`: identifica o contexto do jogo ao vivo
(`currentMatchContextLabel`), o campo neutro (`neutralVenue`, sempre `true`) e a decisão forçada
por grandes penalidades (`isPlayoff`, sempre `true`) nas chamadas a
`startLiveMatchWithLineup`/`newLiveMatchState`, e a arrumação pós-jogo em
`finalizeMatchBookkeeping` (`06-motor-jogo.js`). Antevisão e relatório pré-jogo do adjunto
aparecem na véspera, tal como para a liga e a Taça. Nova vista "Supertaça António Livramento" no
seletor de competições (`renderSupertacaStandalone`, `10-estatisticas.js`, seguindo o mesmo
padrão de competição "virtual" já usado pela Taça de Portugal): mostra a edição atual e o
histórico completo de edições anteriores; a Supertaça também passa a aparecer na aba
"Calendário" do próprio clube quando este é um dos dois finalistas.

**Save (versão 38 → 39)**: novo campo `state.supertaca` (`{ historico:[...], jogo:... }`),
gravado/restaurado em `buildSaveObject`/`applySaveObjectUnchecked`, com migração aditiva em
`migrateSaveObject` — um save anterior à versão 39 fica simplesmente com histórico vazio e sem
jogo pendente (a próxima transição de época gera a edição normalmente).

**Validação (Fase 6)**: 4 novos diagnósticos automáticos, grupo "Supertaça"
(`12-arranque.js`) — qualificação (caso normal, dobradinha, ausência de dados), âncoras de
calendário (2.º sábado de outubro/domingo seguinte, verificado em 5 épocas), campo neutro ao
nível do motor de jogo (reaproveitando o mesmo isolamento de `newMatchState` já validado para a
Final Four da Taça) e idempotência da atribuição de prémio/prestígio/título (testada sobre dois
clubes-clone descartáveis, nunca sobre `state.teams` real). Os 48 diagnósticos anteriores +
estes 4 novos somam 52, todos aprovados depois de escolher um clube (37/52 sem clube — as mesmas
10 falhas de artefacto de teste já documentadas acima, nenhuma nova).

Adicionalmente, validado em browser real (Playwright) ao longo de várias épocas consecutivas,
exercitando o próprio fluxo do jogo (não uma reimplementação simplificada): (1) a 1.ª edição
(Benfica vs. Sporting) sorteia-se corretamente ao escolher um clube diferente destes dois, e
resolve-se sozinha (IA vs. IA) mal a data chega, com prémio/prestígio/título atribuídos e sem
duplicação; (2) escolhendo o Sporting como clube do utilizador, a convocatória e a escalação
abrem corretamente identificadas ("Supertaça António Livramento"), o jogo simulado corre em
campo neutro e a arrumação pós-jogo fecha tudo (prémios, `pendingSupertaca`, marcações de
suspensão) exatamente como os restantes fluxos de jogo único (Taça, finais de apuramento); (3)
chamando `initSupertaca` diretamente com um resumo sintético de época, tanto o caso normal
(campeão ≠ vencedor da Taça) como a dobradinha (mesmo clube venceu as duas provas — o adversário
passa corretamente a ser o finalista vencido) emparelham os clubes certos, com as datas corretas
para cada ano; (4) um round-trip completo de gravar/carregar preserva fielmente o histórico de
várias edições, incluindo todos os campos de qualificação e as marcas de idempotência.

## Calibração financeira (04/09/2026)

Sequência ao [diagnóstico e propostas de calibração financeira de
04/09/2026](../HM2027_Propostas_Calibracao_Financeira_2026-09-04.md): os clubes ricos ficavam
muito ricos e os pobres entravam em falência. Medido com a própria ferramenta de calibração do
jogo (`runPhaseThreeCalibrationMatrix`, cenário "base-20"), sem alterar nada: 15,4% dos clubes
saudáveis/em atenção (meta: 60%) e 81,5% de concentração de riqueza nos 4 grandes (meta: ≤62%).
Todas as 6 propostas do diagnóstico foram implementadas.

**P1 — Custo de treino ligado à reputação (`04-financas.js`)**: `divisionOperatingCost`
dependia só da divisão — um clube "Local" no Placard pagava o mesmo custo de treino que o
Benfica, ao contrário do custo de estrutura, que já tinha um desconto por reputação para o mesmo
efeito. Passa a multiplicar também por `Math.sqrt(clubFinancialStructureFactor(team))` — a raiz
quadrada suaviza o efeito face ao custo de estrutura, por ser uma fatia menor do orçamento.

**P2 — Perfis financeiros realinhados (`CLUB_FINANCE_PROFILES`)**: as quotas de sócios do
Benfica/Sporting/FC Porto estavam entre 2,7× e 3× o que a fórmula genérica daria a um clube
"Classe Mundial" (o patrocínio real já estava bem calibrado) — um duplo benefício em cima da já
vantajosa reputação máxima. Baixadas para ~1,3× o valor genérico. Do lado dos clubes com
patrocínio real abaixo do genérico para a sua reputação (Valongo, Sanjoanense, HC Turquel, e em
menor grau o Barcelos), a correção não mexeu na receita (preserva o valor real, incluindo o nome
do patrocinador) — mexeu antes no custo, através de `clubFinancialStructureFactor`.

**`clubFinancialStructureFactor(team)` (nova função, partilhada)**: compara o patrocínio real de
`CLUB_FINANCE_PROFILES` com o que a fórmula genérica daria à mesma reputação, e ajusta o
multiplicador de custo por reputação (`ECONOMIC_CALIBRATION.reputation[...].structure`) à
capacidade financeira REAL do clube — sem alterar a reputação em si, que continua a valer para
tudo o resto (prestígio, IA, exigência desportiva). O teto fica em 1 (nunca sobe acima do
multiplicador normal): só alivia quem está abaixo do genérico, nunca penaliza mais quem já está
acima — essa correção (Benfica/Sporting/FC Porto) fica só do lado da receita (P2). Usado em
`monthlyStructureCost`, `divisionOperatingCost`/`monthlyTrainingCost` (P1) e no custo de
organização de jogo em casa (`financeConfig().homeCost`, extensão de P1 — também só descia com a
divisão, nunca com a reputação, e para um clube pequeno é uma fatia fixa grande do orçamento a
cada jornada).

**P3 — Travão à dívida (`processMonthlyFinances`)**: dois travões. (a) O juro da dívida baixa a
metade enquanto o clube está sob intervenção da direção ou com um plano de recuperação ativo —
antes, o juro continuava ao ritmo normal mesmo durante o próprio plano desenhado para reduzir a
dívida. (b) A amortização automática deixa de depender do saldo em caixa (que, por converter
qualquer saldo negativo em dívida de imediato — comportamento já existente, não alterado —, quase
nunca sobrava margem real para amortizar nada) e passa a usar o excedente operacional do mês
(receita recorrente menos custos fixos, via `financeRecurringIncome`/`financeFixedCosts`, ambas
já existentes): assim que a exploração corrente do clube fica sustentável, começa logo a reduzir
dívida — sem "roubar" dinheiro que ia ser preciso para pagar salários/estrutura no mesmo mês.

**P4 — Política financeira automática para clubes IA (`applyAiFinancialPolicy`, nova função)**:
equivalente automático, só para clubes não controlados pelo utilizador, dos botões "Reduzir
formação"/"Reduzir estrutura" que já existiam em `financeAction` só para o utilizador. Liga os
cortes ao teto já definido (25%/50%) quando o clube está em risco (nível ≥2) e acima do alerta
salarial (`economicPolicy(team).alert`), e desliga-os quando a operação volta a ser saudável —
mesma lógica de toggle que `financeAction` já usa. A administração financeira
(`placeAiClubUnderAdministration`) mantém-se como rede de segurança final, sem alteração.

**P5 — Fundo de solidariedade (`processMatchFinances` + `distributeSolidarityFund`, nova
função)**: 5% da bilheteira em casa dos clubes "Classe Mundial"/"Internacional" fica retida num
fundo comum (`state.fundoSolidariedadeEpoca`, novo campo, migração aditiva no save — não obrigou
a subir a versão), distribuído em partes iguais no fecho de época pelos clubes em estado "risco"
ou "grave" (chamado a partir de `beginDefeso`, logo a seguir a `awardSeasonFinances`). É o único
mecanismo genuinamente redistributivo desta calibração — os restantes corrigem assimetrias na
fórmula, sem mover dinheiro entre clubes.

**P6 — Classificador de calibração corrigido (`calibrationFinancialState`)**: esta função, usada
só dentro do simulador de calibração, olhava apenas para o rácio dívida/receita — como a dívida
fica limitada ao teto da linha de crédito no simulador, um clube podia ter um saldo de -7,4M€ e
continuar classificado "risco" para sempre. Passa a considerar também o saldo (em proporção à
receita anual). Extensão necessária: o próprio simulador (`runCalibrationScenario`) passou a
espelhar, de forma simplificada, o corte automático de despesa da IA (P4) e a administração
financeira que já existe no jogo real — 20 épocas seguidas sem qualquer intervenção nunca
acontece a sério, e sem isto o simulador, ao deixar de estar "cego" (P6), exagerava
artificialmente a gravidade (chegou a apontar 86% de clubes em estado crítico numa iteração
intermédia, só corrigida com este espelho).

**Ajuste de receitas (pedido explícito: "esse é o custo, é necessário ajustar receitas") — depois
revertido**: as 6 propostas por si só deixaram por resolver uma causa mais funda — o piso de
450€/mês por jogador já excedia sozinho o orçamento salarial de um clube "Local" da 3.ª Divisão
com um plantel mínimo viável (12 jogadores × 450€ = 5.400€, acima do orçamento de referência de
~4.620€). Nesta fase, evitou-se tocar no piso salarial e a correção foi do lado da receita:
`DIVISION_FINANCE_MULT["3div"]` subiu de 0,25 para 0,30 e depois para 0,37, e o apoio municipal
genérico (mais baixo no Placard do que na 2ª/3ª Divisão, sem razão aparente) foi unificado nos
6.000€ de base para todas as divisões. Resultado imediato: saudáveis/atenção 82,1%, crítico 0%,
concentração 21,4% — as três metas cumpridas.

Só que esta correção partia de uma premissa errada: tratava o piso de 450€ como um dado fixo do
jogo, quando na realidade **não é um piso realista** — é apenas o valor pago por clubes da 3ª
Divisão a lutar pela subida. A generalidade dos clubes amadores paga entre 200€ e 450€ por
jogador (informação do utilizador, que corrigiu esta premissa). Inflacionar a receita para
compensar um custo artificialmente alto era mascarar o sintoma errado.

**Correção final do custo (`normalizeInitialWageBill`, `04-financas.js`)**: esta função já existia
para comprimir a massa salarial inicial de um plantel para 55–82% do orçamento salarial de
referência (`limiteSalarial`), mas o seu próprio piso interno (`Math.max(450, ...)`) coincidia
sempre com o piso de `generateContract` — a compressão nunca conseguia descer abaixo dos 450€,
por isso 100% dos jogadores da 3ª Divisão (e 91% da 2ª) ficavam presos exatamente nesse valor,
sem qualquer variação. O piso desta função passa a ser específico por divisão: 200€ na 3ª
Divisão, mantendo-se 450€ nas restantes. Com isto, `DIVISION_FINANCE_MULT["3div"]` **volta ao
valor original de 0,25** — deixou de ser preciso inflacionar a receita, porque o custo agora
reflecte a realidade que o motivou.

**Limitação conhecida**: os 55 clubes da 3ª Divisão na base de dados são estruturalmente
idênticos (mesma reputação "Local", mesmo nível de treino) — não há, nos dados atuais, nenhum
sinal que distinga um clube "a lutar pela subida" (que pagaria perto dos 450€) de um clube típico
(mais perto dos 200€). A correção aplicada usa por isso um piso uniforme de 200€ para toda a 3ª
Divisão: os salários resultantes ficam dentro do intervalo realista (200-450€), mas sem a
variação bimodal que a distinção "ambicioso vs. típico" implicaria. Introduzir essa distinção a
sério exigiria um novo campo por clube (ex.: um sinalizador de ambição/orçamento na base de
dados), fora do âmbito desta calibração.

**Resultado final** (`runPhaseThreeCalibrationMatrix`, cenário "base-20", medido depois de
escolher um clube — ver nota de metodologia abaixo), com `DIVISION_FINANCE_MULT["3div"]=0,25` e o
piso de 200€: concentração de riqueza no top 4, de 81,5% para **20,9%** (meta do próprio jogo:
≤62% — cumprida, com larga folga). Estado crítico, de 0% (artefacto do classificador antigo, ver
P6) para **0% real** (meta: ≤15% — cumprida). Clubes saudáveis/em atenção, de 15,4% para **82,1%**
(meta: ≥60% — **cumprida**). As três metas de aceitação que o próprio jogo já definia ficam agora
cumpridas, com a 3ª Divisão a manter-se claramente a mais pobre, como é realista, e sem depender
de uma receita artificialmente inflacionada.

**Nota de metodologia**: `runPhaseThreeCalibrationMatrix` só reflete `normalizeInitialWageBill`
depois de um clube ser escolhido (a normalização corre em `beginDefeso`, não no arranque do
jogo) — correr o diagnóstico antes disso mede massas salariais não normalizadas. Os números acima
foram sempre medidos depois de escolher um clube, tal como o próprio diagnóstico integrado
(`12-arranque.js`, grupo "Calibração económica") já fazia.

**Validação**: os 52 diagnósticos automáticos do jogo continuam todos aprovados depois desta
calibração (incluindo a simulação financeira integral de 20 épocas e a matriz de 20 épocas de
carreira), sem qualquer erro de página. Testado também em browser real, diretamente sobre o jogo
a sério (não uma reimplementação): `applyAiFinancialPolicy` liga os cortes de estrutura/formação
de um clube IA forçado a estado crítico; `processMatchFinances` desvia corretamente 5% da
bilheteira do Benfica para o fundo de solidariedade; `distributeSolidarityFund` credita
corretamente esse fundo ao clube elegível no fecho de época; um round-trip de gravar/carregar
preserva o novo campo do fundo, com migração aditiva confirmada para gravações antigas (sem o
campo, entram com o fundo vazio); e a amostragem direta de salários por divisão confirma a 3ª
Divisão fora do piso de 450€ (ex.: plantel amostrado a 250€/jogador, dentro do intervalo
200-450€), sem qualquer jogador da 2ª/Placard a descer do seu piso próprio. Novas funções
incluídas em `window.__HM2027_TEST__` para permitir esta validação e diagnósticos futuros.

## Elite Cup (04/09/2026)

Nova competição oficial de pré-época (`js/src/07d-elite-cup.js`), implementada a partir do
roteiro fornecido ("Roadmap Elite Cup — Hóquei Manager 2027 v1.1"): eliminação direta a uma mão,
sempre em campo neutro, entre os 8 primeiros classificados do Campeonato Placard da época
anterior. Disputa-se antes da Supertaça António Livramento e da 1.ª jornada do Campeonato
Placard — importância oficial **baixa** (abaixo da Taça de Portugal e da Supertaça), refletida
sobretudo no prémio financeiro e no prestígio, sempre inferiores aos das outras duas provas.

### Calendário e arquitetura

O roteiro pede uma cadência real (segunda-feira anterior aos quartos → sexta-feira quartos →
sábado meias-finais → domingo final), mas o fluxo de pré-época do jogo (`chooseClub`,
`beginDefeso`/`finalizeNewSeason`) é hoje **atemporal**: a janela de mercado fica presa numa
única data de exibição (15 de julho) até o utilizador decidir avançar, sem progressão dia-a-dia.
Alterar essa arquitetura só para a Elite Cup teria um risco de regressão desproporcionado face ao
resto do jogo. Em vez disso, a Elite Cup resolve-se de forma **comprimida**: assim que a edição é
sorteada, todas as eliminatórias que não envolvem o clube do utilizador são simuladas de
imediato (o mesmo mecanismo "while(true)" já usado pela Taça de Portugal para os jogos IA-IA do
dia, ver `processTacaPortugalForCurrentDate`), e o fluxo só pára mesmo quando chega a vez de o
utilizador jogar — através da mesma convocatória interativa usada em qualquer outro jogo
importante do jogo (Taça, Supertaça, liga). As datas de cada fase (sexta/sábado/domingo, ver
`eliteCupFaseDates`) ficam corretamente registadas para histórico e interface, mesmo sem uma
progressão dia-a-dia real por trás delas.

Isto significa que, para a esmagadora maioria das carreiras (o clube escolhido não está entre os
8 qualificados), a Elite Cup é totalmente invisível em termos de interação — resolve-se sozinha
em background, só deixando notícias e histórico — e só pausa a carreira quando o clube do
utilizador está mesmo em jogo.

**Dois pontos de entrada**, espelhando exatamente o padrão já usado por `initTacaPortugal`/
`initSupertaca`:
- `chooseClub()` (`05-ui-navegacao.js`): 1.ª carreira, sem época anterior — usa a classificação
  histórica fixa fornecida ("benfica, sporting, porto, barcelos, braga, valongo, oliveirense,
  sanjoanense"). A pré-época de mercado só abre depois de a Elite Cup terminar
  (`eliteCupPostSequence="preSeasonDefeso"`).
- `finalizeNewSeason()` (`08-evolucao-jogadores.js`): a partir da 2.ª época, usa o top 8 real do
  Campeonato Placard da época anterior (`completedSummary.placardTop8`, capturado em
  `applyPromotionAndRelegation`, `07-playoff.js`, a partir da classificação "congelada" antes de
  subidas/descidas serem aplicadas). A função foi dividida em duas: `finalizeNewSeason` monta a
  nova época (calendários, Taça, Supertaça, Elite Cup, histórico financeiro) e, se a Elite Cup
  ainda não tiver terminado, **devolve o controlo sem completar a transição**; a cauda original
  (arranque efetivo do calendário, "Início da Época", resumo de época) foi extraída para
  `finalizeNewSeasonTail(completedSummary)`, chamada de imediato no caso comum, ou mais tarde por
  `eliteCupRunPostSequence()` assim que a prova terminar.

Correção lateral, descoberta ao implementar isto: `initTacaPortugal()`/`initSupertaca()` já eram
chamadas em `chooseClub()` antes de `state.currentDate` ser definido (ficava a `null` nesse
momento exato) — as primeiras notícias da carreira ficavam datadas de 1 de janeiro de 1970. A
atribuição de `state.currentDate` foi adiantada para antes destas três chamadas.

### Sorteio e objetivos da direção

Pote 1 (lugares 1-4) cruza sempre com pote 2 (lugares 5-8) nos quartos (`eliteCupDrawQuartos`);
meias-finais sorteadas livremente entre os 4 vencedores. Cada um dos 8 qualificados recebe um
objetivo da direção (`eliteCupBoardObjective`, guardado em `edicao.objetivos[clubId]`), calculado
a partir de uma fórmula ponderada (pesos centralizados em `ELITE_CUP_OBJECTIVE_WEIGHTS`, tal como
pede o roteiro — "sem números mágicos espalhados pelo código"):

```
expectationScore = reputationScore*.30 + currentSquadStrength*.25 + recentFormScore*.20
                  + qualificationScore*.10 + squadDepthScore*.10 + availabilityScore*.05
```

Reputação e força de plantel são normalizadas **dentro do universo dos 8 qualificados** (nunca
contra a generalidade do jogo, como o roteiro exige), pontuação que se traduz num de 4 níveis
("Ser competitivo" / "Chegar às meias-finais" / "Chegar à final" / "Vencer a Elite Cup"). Depois
do sorteio, o objetivo pode subir ou descer **exatamente 1 nível** (nunca mais) consoante a força
do adversário dos quartos (`eliteCupApplyDrawAdjustment`), fica bloqueado (`lockedAt`) e é
comunicado por notícia antes do primeiro jogo — sem nunca ser reescrito depois.

Na eliminação (ou conquista do título), `eliteCupEvaluateObjective` compara o nível efetivamente
alcançado com o objetivo, com três proteções explícitas do roteiro: derrota em grandes
penalidades nunca conta como "falhado claramente" (no máximo "falhado por uma fase"); perder
contra um adversário claramente mais forte pesa metade; e uma queda grande de disponibilidade
(lesões/castigos surgidos depois do objetivo ter sido definido) atenua a penalização a metade,
sem nunca reescrever o objetivo histórico. O impacto (pequeno, sempre inferior ao equivalente da
Taça de Portugal ou Supertaça) aplica-se a `team.desempenhoRecente` — o proxy mais próximo de
"moral"/forma que o jogo já tinha antes desta funcionalidade. A Elite Cup nunca pode, isoladamente,
despedir o treinador — não é sequer preciso proteger contra isso: **não existe, em todo o jogo,
nenhum mecanismo de despedimento ligado a resultados desportivos** (só a insolvência financeira
termina uma carreira, via `state.gameOver`).

**Limitação conhecida**: os 8 qualificados são, por definição, os melhores clubes do Placard — a
combinação dos 6 fatores já produz objetivos genuinamente distintos entre eles (testado em
diagnóstico), mas não existe qualquer estado de "ambição" por clube além do que decorre da
reputação/força/forma/qualificação já existentes.

### Prémios e prestígio (sempre inferiores à Supertaça)

Vencedor: 15.000€ + 0,8 pontos de reputação (Supertaça: 50.000€ + 1,5). Finalista: 7.000€.
Meias-finalistas: 2.500€ cada. Título registado via `awardClubTitle` (competitionId
`"elite-cup"`), tal como qualquer outra prova.

### Persistência

`state.eliteCup` (`{historico, edicao}`) e `state.eliteCupPostSequence` são gravados/migrados tal
como `state.tacaPortugal`/`state.supertaca` (migração aditiva, save v39+ — não obrigou a subir a
versão). Nota específica desta prova: como não corre pelo ciclo diário normal, um save feito a
meio da Elite Cup (mesmo com a convocatória do utilizador já aberta) precisa de um gancho
explícito ao carregar — `applySaveObjectUnchecked` deteta uma edição por concluir e volta a
chamar `processEliteCupForCurrentDate()` (adiado um tick, tal como o alerta de Game Over), que
redescobre a eliminatória por jogar e reabre a convocatória exatamente onde tinha ficado.

### Validação

4 novos diagnósticos automáticos (grupo "Elite Cup", total do jogo sobe para 56/56): sorteio dos
quartos cruza sempre os potes (40 sorteios simulados); objetivos distintos entre os 8
qualificados (nunca todos iguais); ajuste do sorteio nunca ultrapassa 1 nível e é idempotente;
proteções da avaliação (grandes penalidades, idempotência). Testado também em browser real,
diretamente sobre o jogo a sério: carreira nova com um clube qualificado (Benfica) — sorteio,
objetivo "Vencer a Elite Cup", convocatória interativa nos quartos/meias/final, avaliação final
"Falhado por uma fase" ao perder a final, prémio de finalista creditado, transição correta para a
pré-época de mercado; carreira nova com um clube não qualificado (Tomar) — prova inteira resolvida
sozinha, sem qualquer interação; transição real de época (`finalizeNewSeason`) com o clube do
utilizador a qualificar-se para a edição seguinte — confirma o adiamento e posterior conclusão da
cauda da transição (`finalizeNewSeasonTail`), incluindo o arranque efetivo do calendário e o
esvaziamento de `pendingSeasonSummary`; e um round-trip de gravar/carregar a meio da prova,
confirmando que a convocatória pendente é corretamente redescoberta ao carregar. Sem qualquer
erro de página em nenhum destes cenários. Novas funções incluídas em `window.__HM2027_TEST__`.

## Correção de 3 bugs reportados — Elite Cup presa no ecrã de jogo, velocidade rápida sem pausa de
## golo, e data desalinhada com o defeso

**Bug 1/3 (mesma causa)**: `finalizeMatchBookkeeping`, no ramo da Elite Cup, só chamava
`setView("clube")` quando `state.pendingEliteCupFase` ficava `null` depois de
`processEliteCupForCurrentDate()` — mas a resolução comprimida da Elite Cup frequentemente
encadeia logo a convocatória da ronda seguinte para o utilizador, ao contrário da Taça de Portugal
(onde isso é raro). Ficava-se preso no ecrã do jogo terminado, sem forma visível de avançar —
sensação de o jogo "começar em cima da Elite Cup" e não dar para chegar ao defeso. Corrigido:
`setView("clube")` passa a ser chamado sempre, independentemente de haver ou não uma próxima
eliminatória pendente.

**Bug adicional relacionado**: `state.currentDate` nunca avançava ao longo da resolução comprimida
da Elite Cup, ficando preso na data de início da carreira mesmo depois de notícias/resultados já
referirem datas posteriores (ex.: a final). `eliteCupRunPostSequence()` passa a avançar
`state.currentDate` até à data da final antes de prosseguir para o defeso/pré-época.

**Bug 2**: mudar a velocidade (`#speedSelect`) durante um jogo ao vivo criava um novo
`setInterval` que não tinha a verificação de `ctx.goalCelebrationUntil` presente no intervalo
original (`startLiveMatchWithLineup`) — ao mudar para "Rápida" a meio de um golo, a pausa/piscar
da celebração deixava de funcionar. Corrigido extraindo uma função partilhada
(`runLiveMatchTimerTick(ctx)`, `06-motor-jogo.js`) usada pelos dois pontos de entrada
(`startLiveMatchWithLineup` e o handler de mudança de velocidade em `09-fluxo-epoca.js`),
eliminando a possibilidade de os dois voltarem a divergir no futuro.

Validado com reprodução real em browser (não só testes automáticos): fluxo completo de jogo ao
vivo (convocatória → escalação → `#watchMatchBtn` → intervalo → substituições → apito final →
`#postMatchModal`) para os dois cenários da Elite Cup (eliminado numa fase, e a avançar de ronda);
mudança de velocidade a meio de um golo confirmada a manter a pausa e o piscar. 56/56 diagnósticos
automáticos, todos os testes de Elite Cup e um jogo normal de smoke-test, sem regressões.

## Sistema de reputação numérico (especificação v1.2, 04/09/2026)

**Contexto**: o sistema anterior representava a reputação de cada clube com uma de quatro
categorias fixas (`"Local"`/`"Nacional"`/`"Internacional"`/`"Classe Mundial"`), com pouca
granularidade — por exemplo, os 55 clubes da 3ª Divisão eram todos exatamente "Local", e 5 clubes
competitivos do Placard (HC Braga, AD Oeiras, Juventude de Viana, Riba d'Ave, Candelária) também
ficavam presos nessa categoria mais baixa, apesar de disputarem o escalão principal. A
especificação substitui isto por uma escala numérica global 0-100, igual para todas as divisões.

**`club.reputacao` passa a ser um inteiro 0-100** (`database/database.json`/`database.js`,
convertido fisicamente — não apenas normalizado em runtime), com os valores explícitos do
documento: os 14 clubes do Placard e os 28 da 2ª Divisão têm valores próprios (secções 15.4/6 do
documento — ex.: FC Porto 97, Benfica/Sporting 96, ..., AD Oeiras 74; CD Póvoa 78, ..., CRPF Lavra
58); os 55 clubes da 3ª Divisão (sem tabela própria no documento) recebem uma pequena variação
determinística entre 40-50 — decisão do utilizador, em vez de um valor único fixo — gerada por
clube a partir do seu id (`hashStringToSeed`/`seededRnd`, já existentes em `01-nucleo.js`), pelo
que o mesmo clube tem sempre o mesmo valor.

**Migração e normalização (`01-nucleo.js`)**: `normalizeClubReputation(value, club)` é o único
ponto de conversão — aceita um número (novo formato, devolvido tal e qual, idempotente), ou
qualquer outra coisa (uma das quatro categorias antigas, string vazia, `null`/`undefined`), caso
em que usa sempre `reputationDefaultForClub(club)` (override explícito por id, senão a omissão por
divisão/aleatório da 3ª Divisão) — nunca a conversão genérica categoria→pontos
(`REPUTATION_POINTS[value]`). Esta ordem é essencial, não cosmética: como a generalidade dos
clubes tinha exatamente `"Local"` gravado, uma conversão direta devolveria sempre 55 e os 42
valores explícitos do documento (e a variação 40-50 da 3ª Divisão) nunca chegariam a aplicar-se.
`11-guardar-carregar.js` chama `normalizeClubReputation` incondicionalmente na migração de
qualquer save, para que uma carreira já em curso antes desta atualização também veja os clubes
subirem (ou descerem) para o valor correto do documento.

**Reputação e finanças sobem juntas** (decisão do utilizador para os 5 clubes do Placard
antes "Local"): em vez de subir só a reputação desportiva e manter as finanças na categoria mais
baixa, os dois sobem em conjunto — mais fiel ao documento, à custa de ter sido necessário
revalidar a calibração financeira já existente para estes clubes (ver abaixo).

**Interpolação contínua (`reputationLerp(rep, points)`, `01-nucleo.js`)** substitui todas as
antigas tabelas categóricas de 4 valores fixos (`{"Local":x,"Nacional":y,...}`) espalhadas pelo
motor — ancorada exatamente nos 4 pontos de reputação legados (55/70/85/95), pelo que qualquer
clube sem reputação explícita nova continua a obter exatamente o mesmo valor de sempre; só os
clubes com reputação explícita entre dois pontos (ex.: um clube de 2ª Divisão a 78) passam a ter
um valor intermédio interpolado, em vez de saltar de categoria para categoria. Convertidos com
esta função: `initFormationQuality` (qualidade de formação), `computeSatisfactionTarget` (bónus de
satisfação), `reputationFactor` (força relativa em jogo), `genericObjetivoDesportivo`,
`genericTacticalIdentity`, `aiRecruitmentMinimumOverall` (piso de qualidade de recrutamento),
`tacaTargetPhaseIndex` (objetivo da Taça de Portugal), `matchAttendance` (fatores de assistência
casa/fora), o fundo de solidariedade (`processMatchFinances`), e — o conjunto mais sensível, por
já ter uma calibração financeira validada em detalhe — **todas** as tabelas financeiras por
reputação em `04-financas.js` (`FINANCE_REPUTATION_ANCHORS`/`financeByReputation`, que substitui
`FINANCE_BY_REPUTATION`; `ECONOMIC_CALIBRATION_REPUTATION_ANCHORS`/
`economicCalibrationReputationFactor`, que substitui `ECONOMIC_CALIBRATION.reputation`).

**Rótulo contextual** (`REPUTATION_BAND_LABELS`/`reputationBandLabel`, secção 3 do documento): 10
bandas descritivas ("Elite mundial", "Potência europeia", ..., "Clube pequeno ou de escalão
inferior"), só para apresentação — nunca usado em decisões de código. Mostrado por baixo do
número de reputação na ficha do clube (`renderClubeView`) e no cartão de escolha de clube ao criar
uma carreira nova (`renderTeamSelect`).

**Diagnóstico corrigido como efeito indireto**: "Planeamento de recrutamento IA" comparava o total
de contratações da época de um clube contra um limiar recalculado a partir da carência *atual* do
plantel — correto para o portão em tempo real (chamado antes de cada contratação), mas incorreto
como auditoria a posteriori, porque a rede de segurança de mínimos
(`ensureRosterMinimumsFromFreeAgents`, sem registo no ledger) continua a preencher o plantel depois
das contratações reais, baixando esse limiar recalculado abaixo do que vigorava durante as
decisões. Isto já era uma imprecisão pré-existente do diagnóstico, mas só começou a acontecer com
alguma frequência agora que a 2ª Divisão deixou de ter finanças uniformes (clubes com carências
iniciais bem mais díspares entre si). Corrigido para validar só o teto absoluto por época (5), não
um limiar dinâmico recalculado depois do facto.

**Base de dados física convertida** (`database/database.json`/`database.js`): os 97 clubes
(14 Placard, 28 2ª Divisão, 55 3ª Divisão) têm agora `reputacao` gravado como número, calculado
com exatamente a mesma lógica de `normalizeClubReputation`/`reputationDefaultForClub` (replicada
em Python para a conversão, incluindo o gerador determinístico da 3ª Divisão byte a byte) — uma
carreira nova lê sempre um valor já numérico e correto, sem depender da normalização em runtime.

**Database Builder atualizado para compatibilidade** (ferramenta externa e independente,
`HM2027_Database_Builder_v1.3.0/builder.js`, usada pelo utilizador para gerar `database.json`/
`database.js` a partir de ficheiros Excel por equipa): corre isolada, sem acesso aos módulos do
jogo, por isso mantém a sua própria cópia de `normalizeClubReputation`/`reputationLerp` — mas
replicando exatamente a mesma lógica, para que os dois programas leiam um `database.json`/`.js` da
mesma forma. `rw()` (peso da reputação do clube nas métricas históricas de jogos/golos de cada
jogador) e o multiplicador `rm` dentro de `potential()` (potencial dos jovens) deixam de ser
tabelas categóricas de 4 valores e passam a `reputationLerp` ancorado exatamente nos mesmos 4
valores antigos (ex.: `rw`: Local .9 / Nacional .98 / Internacional 1.06 / Classe Mundial 1.15).
`currentDivisionModifier` (penalização fixa de -1,35 para todos os clubes da 2ª Divisão) reduzida
para metade (-0,7): antes era o único mecanismo a diferenciar os clubes da 2ª Divisão entre si
(todos "Local"); agora que cada um tem a sua própria reputação (58-79), essa diferenciação já é
captada por `rw()`/`potential()` — manter a penalização inteira penalizaria duas vezes pelo mesmo
motivo. Mantido um resíduo (metade) para o nível competitivo mais fraco que a reputação por si só
não capta.

**Validado**: conversão da base de dados verificada clube a clube (os 42 valores explícitos do
documento batem certo, os 55 da 3ª Divisão caem todos entre 40-50, e `database.json`/`.js`
produzem exatamente os mesmos valores); Builder testado isoladamente em Node (stub de DOM/XLSX)
confirmando `rw`/`potential`/`currentDivisionModifier` numericamente corretos para clubes de
reputação alta, média e baixa; 56/56 diagnósticos automáticos em múltiplas carreiras novas
(Placard antes/depois de subir de "Local", incluindo os 5 casos reputação+finanças-sobem-juntas;
2ª e 3ª Divisão), sem erros de página; confirmado visualmente na ficha do clube e no ecrã de
escolha de clube (número + rótulo de banda corretos); e comparação lado a lado com a versão
anterior (git stash) para isolar e corrigir um falso positivo no diagnóstico de recrutamento,
introduzido indiretamente pela maior variação financeira entre clubes da 2ª Divisão.

## Bug corrigido: clubes presos no ecrã de defeso ao apurarem para a Elite Cup (2ª época em diante)

**Sintoma reportado em jogo**: ao avançar de época, um clube que ficasse apurado para a Elite Cup
(top 8 do Campeonato Placard da época anterior) ficava sem conseguir jogar a sua eliminatória nem
aceder ao Mercado — o jogo parecia simplesmente "preso".

**Causa**: `beginDefeso()` (fim de cada época, 2ª em diante) abre sempre o ecrã/modal de defeso
(`#defesoModal`, mercado de transferências aberto) e só `finalizeNewSeasonTail()` volta a
escondê-lo, quando a época seguinte arranca de facto. Mas se o clube apurou para a Elite Cup e a
edição ainda não estava concluída, `finalizeNewSeason()` (chamado ao clicar em "Avançar para a
nova época") adia essa cauda até a prova terminar — a Elite Cup resolve-se antes, através de
`processEliteCupForCurrentDate()`/`eliteCupRunPostSequence` (ver secção acima) — sem nunca esconder
entretanto o modal de defeso que tinha ficado aberto. Como `#defesoModal` é um modal-overlay de
ecrã inteiro definido no HTML depois de `#convocatoriaModal` (a convocatória do próprio jogo da
Elite Cup), ficava sempre visível por cima de tudo, bloqueando todos os cliques — tanto na
convocatória da eliminatória como na navegação para o Mercado.

Esta situação já tinha sido identificada e corrigida no passado, mas só no fluxo de carregar um
save feito a meio dela (`applySaveObjectUnchecked`, `11-guardar-carregar.js`, comentário
"Correção (Elite Cup)": esconde o modal e agenda `processEliteCupForCurrentDate()` quando deteta
uma edição pendente) — faltava aplicar a mesma correção ao fluxo normal, sem gravar/carregar.
Corrigido em `finalizeNewSeason()` (`08-evolucao-jogadores.js`): esconde-se `#defesoModal` no
mesmo ponto em que se adia a cauda da transição de época para depois da Elite Cup terminar.

**Validado**: os 8 clubes da classificação histórica inicial da Elite Cup, cada um numa carreira
nova independente, chegam corretamente ao ecrã de defeso depois da prova terminar — incluindo o
caminho mais longo (final, 3 jogos); 56/56 diagnósticos automáticos sem erros após a correção.
(A reprodução direta do cenário de 2ª época+ exigiria simular uma época inteira até ao fim; a
causa foi confirmada por leitura de código — o mesmo bloqueio já estava documentado e corrigido no
fluxo de carregamento de save, só em falta no fluxo ao vivo — e a correção replica exatamente essa
lógica já validada.)
